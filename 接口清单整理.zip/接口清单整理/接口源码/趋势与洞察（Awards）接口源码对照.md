# 趋势与洞察（Awards）接口源码对照文档

| 项目 | 内容 |
|---|---|
| 对应接口文档 | `接口文档/04-趋势与洞察（Awards）接口文档.md` |
| 后端源码根目录 | `G:\HRflag\_backend_bms` |
| 涉及工程 | `HRflag.WebApi`（WebAPI） |
| 前端源码目录 | `G:\G-HRflag\Awards` |
| 文档版本 | v1.0 |
| 更新日期 | 2026-11-17 |

---

## 1. 源码定位结论

### 1.1 榜单列表无后端接口（已核实）

前端 `G:\G-HRflag\Awards\Views\Awards\Awards.cshtml` 全文检索无 `$.ajax`、无 `url:`、无 `APIPath` 调用；榜单条目以硬编码 `<li>` 形式直接输出：

| 位置 | 内容 |
|---|---|
| `Awards.cshtml:1-4` | `ViewBag.Title = "HRflag_趋势与洞察"`，指定 `_Layout` |
| `Awards.cshtml:9-18` | 顶部 Banner（静态图片，`javascript:;` 空链接） |
| `Awards.cshtml:22-...` | 榜单条目 `<ul>`，每条含 `the_logo`（封面 + 跳转）、`the_info`（标题、简介、时间、查看详情） |
| `Awards.cshtml` 全文 | 无数据接口，无 `@Model` 绑定 |

因此本模块**没有任何业务数据接口**，只有公共布局（`_Layout.cshtml` + `hpublic.js` + `cookies.js`）引入的 4 个接口。

### 1.2 涉及控制器

| 控制器 | 绝对路径 | RoutePrefix |
|---|---|---|
| AdvertisingController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\AdvertisingController.cs` | `Advertising` |
| UserInfoController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\UserInfoController.cs` | `UserInfo` |

### 1.3 业务层

| 类型 | 文件 | 说明 |
|---|---|---|
| `AdvertisementHelper`（`adshp`） | `DBConnection\Helper\AdvertisementHelper.cs` | 广告位查询与点击记录 |
| `UserHelper`（`uh`） | `DBConnection\Helper\UserHelper.cs:3549` | `GetUserById` 用户资料 |

---

## 2. 接口 ↔ 源码总览

| # | 接口 | 控制器.方法 | 源码位置 | Helper |
|---|---|---|---|---|
| 1 | `WebAPI/Advertising/HomeADUP` | AdvertisingController.HomeADUP | `AdvertisingController.cs:532` | `AdvertisementHelper.HomeADUP`（`:1601`） |
| 2 | `WebAPI/Advertising/IGetTopAD` | AdvertisingController.IGetTopAD | `AdvertisingController.cs:191` | `AdvertisementHelper.IGetTopAD` |
| 3 | `WebAPI/Advertising/IAddTopADClickRecord` | AdvertisingController.IAddTopADClickRecord | `AdvertisingController.cs:201` | `AdvertisementHelper.IAddTopADClickRecord` |
| 4 | `WebAPI/UserInfo/GetUserById` | UserInfoController.GetUserById | `UserInfoController.cs:383` | `UserHelper.GetUserById`（`:3549`） |

---

## 3. 源码摘录

**`Advertising/HomeADUP`** — `AdvertisingController.cs:532`

```csharp
[Route("HomeADUP"), HttpPost]
public IHttpActionResult HomeADUP()
{
    return Ok(adshp.HomeADUP());
}
```

`AdvertisementHelper.cs:1601`：

```csharp
public DataTable HomeADUP()
{
    try
    {
        string sqlstr = string.Format(@"SELECT * FROM GetHomeActivitieADUP WITH(NOLOCK) WHERE IsDelete=0 AND State=1");
        return DBHelper.ExecuteTable(sqlstr);
    }
    catch (Exception ex)
    {
        throw new Exception(ex.Message);
    }
}
```

> 后端已在 SQL 层过滤 `State=1`，前端 `if (this.State === 1)` 的判断属冗余但无害；SQL **未排序**，前端按 `SeqNo` 升序排序是必要的。

**`Advertising/IGetTopAD`** — `AdvertisingController.cs:191`

```csharp
[Route("IGetTopAD"), HttpPost]
public IHttpActionResult IGetTopAD(string userId)
{
    return Ok(adshp.IGetTopAD(userId));
}
```

`AdvertisementHelper.cs:468`：

```csharp
public TopAD IGetTopAD(string strUserId)
{
    string strSql = "SELECT [Id],[Name],[ImagePath],[Interlinkage] FROM [TopAD] WHERE [IsDelete] = 0 AND [State]= 1";
    DataTable dt = DBHelper.ExecuteTable(strSql);
    List<TopAD> topADs = JsonConvert.DeserializeObject<List<TopAD>>(JsonConvert.SerializeObject(dt));
    Random iRad = new Random();
    int rad = iRad.Next(0, topADs.Count());
    IAddTopADViewRecord(topADs[rad].Id);
    return topADs[rad];
}
```

> 三个关键行为：
> 1. 返回的是**单对象**（`TopAD`），不是数组；
> 2. 每次调用都从有效广告中**随机**取一条，并立即写入一条展示记录（`IAddTopADViewRecord`），即"页面加载 = 一次曝光"；
> 3. 若 `TopAD` 表中无 `IsDelete=0 AND State=1` 的数据，`topADs[0]` 会抛 `ArgumentOutOfRangeException` → 接口 500（不是返回 `null`）。

**`Advertising/IAddTopADClickRecord`** — `AdvertisingController.cs:201`

```csharp
[Route("IAddTopADClickRecord"), HttpPost]
public IHttpActionResult IAddTopADClickRecord(string userId, int aDid)
{
    return Ok(adshp.IAddTopADClickRecord(userId, aDid));
}
```

> `aDid` 为 `int`；广告 `Id` 若非数字会导致绑定失败返回 400。

**`UserInfo/GetUserById`** — `UserInfoController.cs:383`

```csharp
[Route("GetUserById"), HttpPost]
public IHttpActionResult GetUserById(string strUserId)
{
    return Ok(uh.GetUserById(strUserId));
}
```

`UserHelper.cs:3549` 返回字段：

```sql
SELECT [UserPhotoUrl], W.[Image], A.[Name], A.[PhoneNumber], A.[Company],
       A.[Department], A.[Position], A.[Email], A.[TradName], A.[CheckStatus],
       W.[Place], W.[Address], W.[WxCode], W.[OpenId], W.[CompanyLogo], W.[Status]
FROM [User] A
LEFT JOIN [UserPhoto] B ON A.[PhoneNumber] = B.[UserPhoneNo]
LEFT JOIN [{Wx库}].[dbo].[HRUserInfo] W ON A.PhoneNumber = W.PhoneNo
WHERE [UserId] = '{strUserId}' AND A.[IsDelete] = '0'
```

> 返回字段远多于接口文档所列的 `Image`、`UserPhotoUrl`；`Image` 来自 `HRUserInfo`（人脉头像），`UserPhotoUrl` 来自 `UserPhoto`（主站上传头像），前端优先取 `Image`。

---

## 4. 静态榜单条目源码结构

`G:\G-HRflag\Awards\Views\Awards\Awards.cshtml` 中每条榜单对应一段固定结构（以"全球上市人力资源服务公司50强"为例）：

```html
<li>
    <div class="the_logo awards_logo">
        <a target="_blank" href="http://global50.hrflag.com/">
            <img src="https://static.hrflag.com/img//global502021.jpg" alt="">
        </a>
    </div>
    <div class="the_info awards_info">
        <a target="_blank" href="http://global50.hrflag.com/">
            <h6>2021全球上市人力资源服务公司50强</h6>
            <p>2020年，历经疫情冲击……</p>
            <div class="infomore">
                <div><span class="iconfont icon-shijian3"></span><span>2021/7</span></div>
            </div>
        </a>
        <div class="infodetail pcshow">
            <a target="_blank" href="http://global50.hrflag.com/">查看详情</a>
        </div>
    </div>
</li>
```

| 展示元素 | 源码字段位置 | 说明 |
|---|---|---|
| 封面 | `<img src>` | 静态图片，部分为 `http://static.hrflag.com/...`（HTTP） |
| 标题 | `<h6>` | 硬编码 |
| 简介 | `<p>` | 硬编码长文本 |
| 时间 | `.infomore span` | 格式 `yyyy/M` |
| 跳转 | 两处 `href` | 均为子站首页 |

> 若后续改为动态渲染，需新增列表接口并按 `接口文档/04-趋势与洞察（Awards）接口文档.md` 第 4.1 节的 5 字段结构返回，同时把 `Awards.cshtml` 的 `<li>` 改为模板循环。

---

## 5. 源码与文档的差异 / 风险

| # | 项 | 说明 | 建议 |
|---|---|---|---|
| 1 | 无榜单接口 | 页面为纯静态，接口文档已如实说明 | 若运营需自主维护榜单，需新增 `Awards/GetAwardsList` 接口 |
| 2 | `HomeADUP` 重复过滤 | 后端已 `State=1`，前端再判断 | 无需修改 |
| 3 | `HomeADUP` 无排序 | SQL 无 `ORDER BY` | 前端排序不可省略 |
| 4 | `IGetTopAD` 空表即异常 | 无有效广告时 `topADs[0]` 抛 `ArgumentOutOfRangeException` → 500；且每次调用写一条曝光记录 | 前端 `hpublic.js` 无 `error` 回调，广告位静默空白；建议后端补空表判断 |
| 5 | SQL 字符串拼接 | `HomeADUP` 为静态 SQL（安全）；`GetUserById` 用 `'{strUserId}'` 拼接 | `strUserId` 取自 Cookie，存在注入面，建议参数化 |
| 6 | 图片协议混用 | 榜单封面大量使用 `http://static.hrflag.com/...` | HTTPS 页面下会告警，建议统一 `https://` |

---

## 6. 待补源码

本模块无未定位接口。唯一需注意：`GetHomeActivitieADUP` 是数据库视图/存储过程名（非代码文件），字段以该视图定义为准；如需精确字段清单，需在数据库中执行 `sp_helptext 'GetHomeActivitieADUP'` 或查看视图定义。
