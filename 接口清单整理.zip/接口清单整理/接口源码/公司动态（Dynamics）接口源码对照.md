# 公司动态（Dynamics）接口源码对照文档

| 项目 | 内容 |
|---|---|
| 对应接口文档 | `接口文档/05-公司动态（Dynamics）接口文档.md` |
| 后端源码根目录 | `G:\HRflag\_backend_bms` |
| 涉及工程 | `HRflag.WebApi`（WebAPI） |
| 涉及前端 | `G:\G-HRflag\Dynamics` |
| 文档版本 | v1.0 |
| 更新日期 | 2026-11-17 |

---

## 1. 源码定位说明

### 1.1 控制器

| 控制器 | 绝对路径 | RoutePrefix |
|---|---|---|
| NewsController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\NewsController.cs` | `News` |
| AdvertisingController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\AdvertisingController.cs` | `Advertising` |
| UserInfoController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\UserInfoController.cs` | `UserInfo` |

### 1.2 业务层与模型

| 类型 | 文件 | 说明 |
|---|---|---|
| `NewsHelper`（`nh`） | `DBConnection\Helper\NewsHelper.cs` | `GetIssueNews`（`:265`） |
| `AdvertisementHelper`（`adshp`） | `DBConnection\Helper\AdvertisementHelper.cs` | 广告位 |
| `UserHelper`（`uh`） | `DBConnection\Helper\UserHelper.cs` | `GetUserById`（`:3549`） |
| `JsonResult<T>` | `HRflag.Model\Common\JsonResult.cs` | 统一分页返回包装 |
| `CapTrueValueOutput` | `HRflag.Model\Output\CapTrueValueOutput.cs` | 资讯列表元素 |
| `NewsOutput` | `HRflag.Model\Output\NewsOutput.cs` | 资讯基类（含 `PageView`） |

---

## 2. 接口 ↔ 源码总览

| # | 接口 | 控制器.方法 | 源码位置 | 依赖 |
|---|---|---|---|---|
| 1 | `WebAPI/News/GetIssueNews` | NewsController.GetIssueNews | `NewsController.cs:58` | `NewsHelper.GetIssueNews`（`NewsHelper.cs:265`） |
| 2 | `WebAPI/Advertising/HomeADUP` | AdvertisingController.HomeADUP | `AdvertisingController.cs:532` | `AdvertisementHelper.HomeADUP`（`:1601`） |
| 3 | `WebAPI/Advertising/IGetTopAD` | AdvertisingController.IGetTopAD | `AdvertisingController.cs:191` | `AdvertisementHelper.IGetTopAD` |
| 4 | `WebAPI/Advertising/IAddTopADClickRecord` | AdvertisingController.IAddTopADClickRecord | `AdvertisingController.cs:201` | `AdvertisementHelper.IAddTopADClickRecord` |
| 5 | `WebAPI/UserInfo/GetUserById` | UserInfoController.GetUserById | `UserInfoController.cs:383` | `UserHelper.GetUserById`（`:3549`） |

> 第 2~5 项为公共布局接口，与趋势与洞察模块完全相同，详见 `接口源码/04-趋势与洞察（Awards）接口源码对照.md` 第 3 节。

---

## 3. 核心接口源码

### 3.1 控制器

**`News/GetIssueNews`** — `HRflag.WebApi\Controllers\NewsController.cs:58`

```csharp
[Route("GetIssueNews"), HttpPost]
public IHttpActionResult GetIssueNews(string title, string typename, int page, int limit)
{
    //return Ok(newsBLL.GetIssueNews(title, typename, page, limit));
    return Ok(nh.GetIssueNews(title, typename, page, limit));
}
```

> 四个参数均从 QueryString 绑定（非 `[FromBody]`），与前端字符串拼接调用一致；`page`、`limit` 为 `int`，不传会绑定为 0。

### 3.2 业务层

**`NewsHelper.GetIssueNews`** — `DBConnection\Helper\NewsHelper.cs:265`

```csharp
public JsonResult<CapTrueValueOutput> GetIssueNews(string strTitle, string strTypeName, int Ipage, int limit)
{
    string strBuild = string.Empty;
    string fenye = string.Empty;
    if (!string.IsNullOrEmpty(strTitle))
    {
        strBuild += " AND A.[Title] LIKE '%" + strTitle + "%'";
        fenye += " AND C.[Title] LIKE '%" + strTitle + "%'";
    }
    if (!string.IsNullOrEmpty(strTypeName))
    {
        strBuild += " AND [TypeName]  LIKE '%" + strTypeName + "%'";
        fenye += " AND TypeName LIKE '%" + strTypeName + "%'";
    }
    string strSql = string.Format(@"SELECT TOP {0} C.[TypeName] AS [NTId],[SmallImage],Title,[BMainBody],[PubName],RowNumber,
        C.[IsDelete],[PageView],[ImagePath] AS Image, [NId],[Title],C.[CreateTime] FROM
        (SELECT ROW_NUMBER() OVER (ORDER BY A.[CreateTime] DESC) AS RowNumber, ... 
        FROM [CapTrueValue] A left JOIN [NewsType] B ON A.[NTId] = B.[NTId]
        WHERE A.[IsDelete] = '0' AND [CheckStatus]='2' {2}
        ) C
        WHERE RowNumber >= 1+{0}*({1}-1)", limit, Ipage, strBuild);
    ...
}
```

关键实现要点：

| 项 | 实现 |
|---|---|
| 数据表 | `[CapTrueValue]`（资讯主表）+ `[NewsType]`（栏目表） |
| 栏目过滤 | `[TypeName] LIKE '%{typename}%'`，因此传 `公司动态` 会匹配包含该词的栏目 |
| 标题过滤 | `A.[Title] LIKE '%{title}%'` |
| 只返回已审核 | `[CheckStatus] = '2'`（审核通过） |
| 只返回未删除 | `A.[IsDelete] = '0'` |
| 排序 | `ROW_NUMBER() OVER (ORDER BY A.[CreateTime] DESC)`，即发布时间倒序 |
| 分页 | `TOP {limit}` + `RowNumber >= 1 + limit*(page-1)` |
| 总数 | 单独 `COUNT(*)`，同样带 `IsDelete`、`CheckStatus`、标题/栏目条件 |
| 封面兜底 | `SmallImage` 为空时：先取 `ImagePath`，再查 `ImageBase` 表的 base64 图并落盘生成缩略图 |

### 3.3 返回包装

`HRflag.Model\Common\JsonResult.cs`：

```csharp
public class JsonResult<T>
{
    [JsonProperty("code")]     public int Code { get; set; }
    [JsonProperty("msg")]      public string Message { get; set; }
    [JsonProperty("count")]    public int Count { get; set; }
    [JsonProperty("data")]     public List<T> Data { get; set; }
    [JsonProperty("table")]    public T Table { get; set; }
    [JsonProperty("PayLook")]  public bool PayLook { get; set; }
    ...
}
```

> `count`、`data` 的**小写**由 `[JsonProperty]` 显式指定，因此与前端 `data.count` / `data.data` 的读取方式吻合。`code`、`msg` 未赋值时分别为 `0`、`null`，前端不应据此判断成功与否。

### 3.4 列表元素实际返回字段

`GetIssueNews` 中仅对以下 8 个属性赋值（`NewsHelper.cs:328-339`），其余模型字段均为默认值：

```csharp
CapTrueValueOutput capTrueOutput = new CapTrueValueOutput
{
    NId = item["NId"].ToString(),
    Title = item["Title"].ToString(),
    NTId = item["NTId"].ToString(),
    SmallImage = item["SmallImage"].ToString(),
    Image = item["Image"].ToString(),
    PubName = item["PubName"].ToString(),
    PageView = Convert.ToInt32(item["PageView"]) + 9341,
    CreateTime = Convert.ToDateTime(item["CreateTime"])
};
```

| 字段 | 类型 | 说明 |
|---|---|---|
| NId | string | 资讯主键 |
| Title | string | 标题 |
| NTId | string | 栏目名（SQL 中 `[TypeName] AS [NTId]`） |
| SmallImage | string | 封面图（可能由 base64 落盘生成） |
| Image | string | 原图路径（`[ImagePath] AS Image`） |
| PubName | string | 发布方 |
| PageView | int | 浏览量 —— **源码为「库中值 + 9341」** |
| CreateTime | datetime | 发布时间 |

> `CapTrueValueOutput` 继承 `NewsOutput`（含 `MainBody`、`BMainBody`、`NSource`、`CityName`、`LikeCount`、`IsLike` 等）与 `Commonfield`（`UpdateTime`、`IsDelete` 等），但这些字段在本接口中**不会被赋值**，序列化后为 `null`/`0`，前端不应依赖。

---

## 4. 源码与接口文档的差异 / 风险

| # | 项 | 接口文档 | 源码实际 | 影响 |
|---|---|---|---|---|
| 1 | 浏览量 | `PageView` 为真实浏览量 | `Convert.ToInt32(item["PageView"]) + 9341` | 列表展示值比数据库真实值固定多 9341，属人为放大，数据对账时需扣除 |
| 2 | 栏目匹配 | `typename` 精确匹配栏目 | `LIKE '%typename%'` | 传 `动态` 会同时命中"公司动态""行业动态"等；传空串则不过滤 |
| 3 | 审核过滤 | 文档未提 | 强制 `CheckStatus='2'` | 待审核/未通过稿件不会出现在列表 |
| 4 | 返回字段 | 文档列 6 个字段 | 实际赋值 8 个（多 `NTId`、`Image`），其余为默认值 | 前端可额外使用 `Image` 作为大图 |
| 5 | `code` / `msg` | 文档未提 | `JsonResult` 固定返回，未赋值时为 `0` / `null` | 不能作为成功标志 |
| 6 | **SQL 注入** | — | `strTitle`、`strTypeName` 直接拼进 SQL（`LIKE '%...%'`） | 前端 `name` 参数来自 URL `?name=`，可被构造注入；**建议改参数化查询** |
| 7 | `page` / `limit` 缺省 | 文档要求必传 | `int` 绑定，缺省为 0 → `TOP 0` 返回空 | 前端必须保证两参数存在且 >0 |

### 4.1 安全提示（优先级高）

`NewsHelper.GetIssueNews` 使用字符串拼接构造 SQL：

```csharp
strBuild += " AND A.[Title] LIKE '%" + strTitle + "%'";
strBuild += " AND [TypeName]  LIKE '%" + strTypeName + "%'";
```

而 `title` 直接来自前端 URL 参数 `?name=`。构造如 `name=' OR 1=1--` 的输入即可改变查询语义。同文件其他方法（如 `GetIssueNewsById`）亦为拼接风格。

建议：

1. 改为 `SqlParameter` 参数化（`LIKE @title`，值传 `%` + title + `%`）；
2. 或至少对 `title`、`typename` 做白名单/转义（去除 `'`、`--`、`;`）；
3. 全库排查同类 `LIKE '%" + xxx + "%'` 写法（`NewsHelper`、`ActivityQueryHelper`、`TwitterHelper` 中均存在）。

---

## 5. 待补源码

本模块 5 个接口均已定位，无缺失。

补充说明：`HomeADUP` 依赖的 `GetHomeActivitieADUP` 为数据库视图，字段以视图定义为准；`SmallImage` 为空时依赖 `ImageBase` 表与 `ImageHelper.SaveCapTrueBase64Img` 落盘逻辑，涉及图片存储路径，如需排查封面缺失问题，应同时检查该表与 OSS 目录。
