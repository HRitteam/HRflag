# 人脉（Network）接口源码对照文档

| 项目 | 内容 |
|---|---|
| 对应接口文档 | `接口文档/01-人脉（Network）接口文档.md` |
| 后端源码根目录 | `G:\HRflag\_backend_bms` |
| 解决方案 | `G:\HRflag\_backend_bms\HRflag.sln` |
| 涉及工程 | `HRflag.WxSp`（WxSpAPI）、`HRflag.WebApi`（WebAPI） |
| 数据访问层 | `WxSpDBCon\DataHelper\*`、`DBConnection\Helper\*` |
| 文档版本 | v1.0 |
| 更新日期 | 2026-11-17 |

---

## 1. 源码定位说明

### 1.1 路由机制

后端为 **ASP.NET Web API 2**，采用特性路由（Attribute Routing），未使用 `WebApiConfig` 中的约定路由。

- 控制器类通过 `[RoutePrefix("Xxx")]` 声明第一段路径；
- 方法通过 `[Route("Yyy"), HttpPost]` 声明第二段路径；
- 最终 URL = `{站点}/Xxx/Yyy`。

因此接口文档中的 `WxSpAPI/Contacts/GetConnectionInfo` 对应 `HRflag.WxSp` 工程中 `RoutePrefix("Contacts")` 控制器下的 `[Route("GetConnectionInfo")]` 方法。

### 1.2 分层结构

```
HTTP 请求
  └─ Controller（HRflag.WxSp / HRflag.WebApi）   仅解析参数、调用 Helper、返回 Ok(...)
       └─ Helper（WxSpDBCon.DataHelper / DBConnection.Helper）
            └─ DBHelper.ExecuteTable / ExecuteNonQuery（拼 SQL 直连数据库）
```

- `HRflag.WxSp` 的 Helper 位于 `WxSpDBCon\DataHelper\`，内部以 `DBHelper.ExecuteTable(strSql, SqlParameter[])` 直接执行 SQL，无独立 DAL 层。
- `HRflag.WebApi` 的 Helper 位于 `DBConnection\Helper\`，同为 SQL 直连风格。
- 控制器本身几乎不含业务逻辑，**改接口行为应直接看 Helper 方法**。

### 1.3 控制器绝对路径

| 工程 | 控制器 | 绝对路径 |
|---|---|---|
| HRflag.WxSp | ContactsController | `G:\HRflag\_backend_bms\HRflag.WxSp\Controllers\ContactsController.cs` |
| HRflag.WxSp | ApplyController | `G:\HRflag\_backend_bms\HRflag.WxSp\Controllers\ApplyController.cs` |
| HRflag.WxSp | UserController | `G:\HRflag\_backend_bms\HRflag.WxSp\Controllers\UserController.cs` |
| HRflag.WebApi | ActiveMeetingController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\ActiveMeetingController.cs` |
| HRflag.WebApi | ActivityController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\ActivityController.cs` |
| HRflag.WebApi | FileMgrController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\FileMgrController.cs` |
| HRflag.WebApi | TwitterController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\TwitterController.cs` |
| HRflag.WebApi | AdvertisingController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\AdvertisingController.cs` |

> 注意：`WxSpAPI/UserInfo/*` 并不存在 `UserInfoController`，而是 `HRflag.WxSp\Controllers\UserController` 上标注了 `[RoutePrefix("UserInfo")]`。同理 `HRflag.WebApi` 中另有一个 `UserInfoController`（`[RoutePrefix("UserInfo")]`，服务于 `WebAPI/UserInfo/*`），两者**不是同一个类**，排查时勿混淆。

### 1.4 Helper 类位置

| Helper 类 | 文件 | 服务的接口组 |
|---|---|---|
| `ContactsHelper` | `WxSpDBCon\DataHelper\ContactsHelper.cs` | `Contacts/*` |
| `ApplyHelper` | `WxSpDBCon\DataHelper\ApplyHelper.cs` | `Apply/*` |
| `UserHelper`（WxSp） | `WxSpDBCon\DataHelper\UserHelper.cs` | `UserInfo/Get*User`、`GetRecordCount`、`GetCountAllorAdd` |
| `UserActionHelper` | `WxSpDBCon\DataHelper\UserActionHelper.cs` | `Contacts/AddUserAction(s)`、`UserInfo/GetHRUser*`、`CompanyBusinessPersonalVideo` |
| `ActiveMeetingHelper` | `DBConnection\Helper\ActiveMeetingHelper.cs` | `ActiveMeeting/*` |
| `ActivityQueryHelper` | `ActivityDBCon\DataHelper\ActivityQueryHelper.cs` | `Activity/GetHotActivityDetail` |
| `FileHelper` | `DBConnection\Helper\FileHelper.cs` | `FileMgr/GetHighForceFileld` |
| `TwitterHelper` | `DBConnection\Helper\TwitterHelper.cs` | `Twitter/*` |
| `AdvertisementHelper` | `DBConnection\Helper\AdvertisementHelper.cs` | `Advertising/*` |

---

## 2. 接口 ↔ 源码总览

| # | 接口 | 控制器.方法 | 源码位置 | Helper 方法 |
|---|---|---|---|---|
| 1 | `WxSpAPI/Contacts/GetUserInfoByPhone` | ContactsController.GetUserInfoByPhone | `HRflag.WxSp\Controllers\ContactsController.cs:201` | `ContactsHelper.GetUserInfoByPhone` |
| 2 | `WxSpAPI/Contacts/GetUserInfoByid` | ContactsController.GetUserInfoByid | `ContactsController.cs:211` | `ContactsHelper.GetUserInfoByid` |
| 3 | `WxSpAPI/Contacts/GetContacts` | ContactsController.GetContacts | `ContactsController.cs:132` | `ContactsHelper.GetContacts` |
| 4 | `WxSpAPI/Contacts/GetConnections` | ContactsController.GetConnections | `ContactsController.cs:39` | `ContactsHelper.GetConnections` |
| 5 | `WxSpAPI/Contacts/GetConnectionsCount` | ContactsController.GetConnectionsCount | `ContactsController.cs:75` | `ContactsHelper.GetConnectionsCount` |
| 6 | `WxSpAPI/Contacts/GetConnectionInfo` | ContactsController.GetConnectionInfo | `ContactsController.cs:118` | `ContactsHelper.GetConnectionInfo` |
| 7 | `WxSpAPI/Contacts/AlikeConnections` | ContactsController.AlikeConnections | `ContactsController.cs:99` | `ContactsHelper.AlikeConnections` |
| 8 | `WxSpAPI/Contacts/GetContactsLowerList` | ContactsController.GetContactsLowerList | `ContactsController.cs:176` | `ContactsHelper.GetContactsLowerList` |
| 9 | `WxSpAPI/Contacts/GetContactsLowerCount` | ContactsController.GetContactsLowerCount | `ContactsController.cs:165` | `ContactsHelper.GetContactsLowerCount` |
| 10 | `WxSpAPI/Contacts/AddUserAction` | ContactsController.AddUserAction | `ContactsController.cs:530` | `UserActionHelper.AddUserAction` |
| 11 | `WxSpAPI/Contacts/AddUserActions` | ContactsController.AddUserActions | `ContactsController.cs:563` | `UserActionHelper.AddUserActions` |
| 12 | `WxSpAPI/Apply/UserApplyMax` | ApplyController.UserApplyMax | `HRflag.WxSp\Controllers\ApplyController.cs:132` | `ApplyHelper.UserApplyMax` |
| 13 | `WxSpAPI/Apply/AddUserApply` | ApplyController.AddUserApply | `ApplyController.cs:22` | `ApplyHelper.AddUserApply` |
| 14 | `WxSpAPI/Apply/GetSUserApplyList` | ApplyController.GetSUserApplyList | `ApplyController.cs:58` | `ApplyHelper.GetSUserApplyList` |
| 15 | `WxSpAPI/Apply/GetFUserApplyList` | ApplyController.GetFUserApplyList | `ApplyController.cs:85` | `ApplyHelper.GetFUserApplyList` |
| 16 | `WxSpAPI/Apply/PassUserApply` | ApplyController.PassUserApply | `ApplyController.cs:112` | `ApplyHelper.PassUserApply` |
| 17 | `WxSpAPI/Apply/AdoptUserApply` | ApplyController.AdoptUserApply | `ApplyController.cs:97` | `ApplyHelper.AdoptUserApply` |
| 18 | `WxSpAPI/UserInfo/GetCountAllorAdd` | UserController.GetCountAllorAdd | `HRflag.WxSp\Controllers\UserController.cs:1116` | `UserHelper.GetCountAllorAdd` |
| 19 | `WxSpAPI/UserInfo/GetLookUser` | UserController.GetLookUser | `UserController.cs:1090` | `UserHelper.GetLookUser` |
| 20 | `WxSpAPI/UserInfo/GetUserLook` | UserController.GetUserLook | `UserController.cs:1081` | `UserHelper.GetUserLook` |
| 21 | `WxSpAPI/UserInfo/GetCollectUser` | UserController.GetCollectUser | `UserController.cs:1072` | `UserHelper.GetCollectUser` |
| 22 | `WxSpAPI/UserInfo/GetUserCollect` | UserController.GetUserCollect | `UserController.cs:1063` | `UserHelper.GetUserCollect` |
| 23 | `WxSpAPI/UserInfo/GetlikeUser` | UserController.GetlikeUser | `UserController.cs:1054` | `UserHelper.GetlikeUser` |
| 24 | `WxSpAPI/UserInfo/GetUserlike` | UserController.GetUserlike | `UserController.cs:1045` | `UserHelper.GetUserlike` |
| 25 | `WxSpAPI/UserInfo/GetRecordCount` | UserController.GetRecordCount | `UserController.cs:1105` | `UserHelper.GetRecordCount` |
| 26 | `WxSpAPI/UserInfo/GetHRUserSelfIntroduction` | UserController.GetHRUserSelfIntroduction | `UserController.cs:1370` | `UserActionHelper.GetHRUserSelfIntroduction` |
| 27 | `WxSpAPI/UserInfo/GetHRUserComIntroduction` | UserController.GetHRUserComIntroduction | `UserController.cs:1342` | `UserActionHelper.GetHRUserComIntroduction` |
| 28 | `WxSpAPI/UserInfo/GetHRUserProfessionalWork` | UserController.GetHRUserProfessionalWork | `UserController.cs:1356` | `UserActionHelper.GetHRUserProfessionalWork` |
| 29 | `WxSpAPI/UserInfo/CompanyBusinessPersonalVideo` | UserController.CompanyBusinessPersonalVideo | `UserController.cs:1384` | `UserActionHelper.CompanyBusinessPersonalVideo` |
| 30 | `WebAPI/ActiveMeeting/GetinnerActivemeetingNew` | ActiveMeetingController.GetinnerActivemeetingNew | `HRflag.WebApi\Controllers\ActiveMeetingController.cs:138` | `ActiveMeetingHelper.GetinnerActivemeetingNew` |
| 31 | `WebAPI/ActiveMeeting/GetActivemeeting` | ActiveMeetingController.GetActivemeeting | `ActiveMeetingController.cs:144` | `ActiveMeetingHelper.GetActivemeeting` |
| 32 | `WebAPI/ActiveMeeting/ActiveClickRecord` | ActiveMeetingController.ActiveClickRecord | `ActiveMeetingController.cs:152` | `ActiveMeetingHelper.ActiveClickRecord` |
| 33 | `WebAPI/Activity/GetHotActivityDetail` | ActivityController.GetHotActivityDetail | `HRflag.WebApi\Controllers\ActivityController.cs:3133` | `ActivityQueryHelper.GetHotActivityDetail` |
| 34 | `WebAPI/FileMgr/GetHighForceFileld` | FileMgrController.GetHighForceFileld | `HRflag.WebApi\Controllers\FileMgrController.cs:1081` | `FileHelper.GetHighForceFileld` |
| 35 | `WebAPI/Twitter/GetHrflagTwitter` | TwitterController.GetHrflagTwitter | `HRflag.WebApi\Controllers\TwitterController.cs:62` | `TwitterHelper.GetHrflagTwitter` |
| 36 | `WebAPI/Twitter/AddTwitterLike` | TwitterController.AddTwitterLike | `TwitterController.cs:795` | `TwitterHelper.AddTwitterLike` |
| 37 | `WebAPI/Twitter/ChangeTwitters` | TwitterController.ChangeTwitters | `TwitterController.cs:777` | `TwitterHelper.ChangeTwitters` |
| 38 | `WebAPI/Twitter/AddTwitterView` | TwitterController.AddTwitterView | `TwitterController.cs:760` | `TwitterHelper.AddTwitterView` |
| 39 | `WebAPI/Twitter/GetUserLike` | TwitterController.GetUserLike | `TwitterController.cs:871` | `TwitterHelper.GetUserLike` + `GetWXUserLike` |
| 40 | `WebAPI/Advertising/IGetPersonConnectionAdv` | AdvertisingController.IGetPersonConnectionAdv | `HRflag.WebApi\Controllers\AdvertisingController.cs:1678` | `AdvertisementHelper.IGetPersonConnectionAdv` |
| 41 | `WebAPI/Advertising/IGetFriendApplyForAdv` | AdvertisingController.IGetFriendApplyForAdv | `AdvertisingController.cs:2472` | `AdvertisementHelper.IGetFriendApplyForAdv` |
| 42 | `WebAPI/Advertising/IGetFriendTableAdv` | AdvertisingController.IGetFriendTableAdv | `AdvertisingController.cs:2209` | `AdvertisementHelper.IGetFriendTableAdv` |
| 43 | `WebAPI/Advertising/IGetStrangerADAdv` | AdvertisingController.IGetStrangerADAdv | `AdvertisingController.cs:2604` | `AdvertisementHelper.IGetStrangerADAdv` |
| 44 | `WebAPI/Advertising/IGetTopAD` | AdvertisingController.IGetTopAD | `AdvertisingController.cs:191` | `AdvertisementHelper.IGetTopAD` |
| 45 | `WebAPI/Advertising/Advertising/IAddMeetingUPClickRecord` | AdvertisingController.IAddMeetingUPClickRecord | `AdvertisingController.cs:331` | `AdvertisementHelper.IAddMeetingUPClickRecord` |
| 46 | `WebAPI/Advertising/IAddTopADClickRecord` | AdvertisingController.IAddTopADClickRecord | `AdvertisingController.cs:201` | `AdvertisementHelper.IAddTopADClickRecord` |

> 表中含 `HRflag.WxSp` 前缀的为完整相对路径，其余行与上一行的目录相同（同一文件）。

---

## 3. 源码摘录

### 3.1 账号与名片

**`Contacts/GetUserInfoByPhone`** — `HRflag.WxSp\Controllers\ContactsController.cs:201`

```csharp
[Route("GetUserInfoByPhone"), HttpPost]
public IHttpActionResult GetUserInfoByPhone()
{
    string Phone = HttpContext.Current.Request["Phone"];
    return Ok(ContactsHelper.Instanct.GetUserInfoByPhone(Phone));
}
```

**`Contacts/GetUserInfoByid`** — `ContactsController.cs:211`

```csharp
[Route("GetUserInfoByid"), HttpPost]
public IHttpActionResult GetUserInfoByid()
{
    string OpenId = HttpContext.Current.Request["OpenId"];
    return Ok(ContactsHelper.Instanct.GetUserInfoByid(OpenId));
}
```

**`UserInfo/GetRecordCount`** — `HRflag.WxSp\Controllers\UserController.cs:1105`

```csharp
[Route("GetRecordCount"), HttpPost]
public IHttpActionResult GetRecordCount()
{
    string OpenId = HttpContext.Current.Request["OpenId"];
    return Ok(UserHelper.Instanct.GetRecordCount(OpenId));
}
```

**`UserInfo/GetHRUserSelfIntroduction`** — `UserController.cs:1370`

```csharp
[Route("GetHRUserSelfIntroduction"), HttpPost]
public IHttpActionResult GetHRUserSelfIntroduction(string OpenId)
{
    return Ok(UserActionHelper.Instanct.GetHRUserSelfIntroduction(OpenId));
}
```

**`UserInfo/GetHRUserComIntroduction`** — `UserController.cs:1342`

```csharp
[Route("GetHRUserComIntroduction"), HttpPost]
public IHttpActionResult GetHRUserComIntroduction(string OpenId)
{
    return Ok(UserActionHelper.Instanct.GetHRUserComIntroduction(OpenId));
}
```

**`UserInfo/GetHRUserProfessionalWork`** — `UserController.cs:1356`

```csharp
[Route("GetHRUserProfessionalWork"), HttpPost]
public IHttpActionResult GetHRUserProfessionalWork(string OpenId)
{
    return Ok(UserActionHelper.Instanct.GetHRUserProfessionalWork(OpenId));
}
```

**`UserInfo/CompanyBusinessPersonalVideo`** — `UserController.cs:1384`

```csharp
[Route("CompanyBusinessPersonalVideo"), HttpPost]
public IHttpActionResult CompanyBusinessPersonalVideo(string OpenId)
{
    return Ok(UserActionHelper.Instanct.CompanyBusinessPersonalVideo(OpenId));
}
```

### 3.2 人脉关系与推荐

**`Contacts/GetContacts`** — `ContactsController.cs:132`

```csharp
[Route("GetContacts"), HttpPost]
public IHttpActionResult GetContacts()
{
    string OpenId = HttpContext.Current.Request["OpenId"];
    string Query = HttpContext.Current.Request["Query"];
    int sortType = Convert.ToInt32(HttpContext.Current.Request["sortType"]);
    return Ok(ContactsHelper.Instanct.GetContacts(OpenId, Query, sortType));
}
```

**`Contacts/GetConnections`** — `ContactsController.cs:39`

```csharp
[Route("GetConnections"), HttpPost]
public IHttpActionResult GetConnections()
{
    string OpenId = HttpContext.Current.Request["OpenId"];
    string Query = HttpContext.Current.Request["Query"];
    int classType = Convert.ToInt32(HttpContext.Current.Request["classType"]);
    int Limite = Convert.ToInt32(HttpContext.Current.Request["Limite"]);
    int Page = Convert.ToInt32(HttpContext.Current.Request["Page"]);
    string TradName = HttpContext.Current.Request["TradName"];
    string Department = HttpContext.Current.Request["Department"];
    string Place = HttpContext.Current.Request["Place"];
    return Ok(ContactsHelper.Instanct.GetConnections(OpenId, Query, classType, Limite, Page, TradName, Department, Place));
}
```

**`Contacts/GetConnectionsCount`** — `ContactsController.cs:75`

```csharp
[Route("GetConnectionsCount"), HttpPost]
public IHttpActionResult GetConnectionsCount()
{
    string OpenId = HttpContext.Current.Request["OpenId"];
    string Query = HttpContext.Current.Request["Query"];
    int classType = Convert.ToInt32(HttpContext.Current.Request["classType"]);
    return Ok(ContactsHelper.Instanct.GetConnectionsCount(OpenId, Query, classType));
}
```

**`Contacts/GetConnectionInfo`** — `ContactsController.cs:118`

```csharp
[Route("GetConnectionInfo"), HttpPost]
public IHttpActionResult GetConnectionInfo()
{
    string Phone = HttpContext.Current.Request["Phone"];
    string ClassType = HttpContext.Current.Request["ClassType"];
    string page = HttpContext.Current.Request["page"];
    string limit = HttpContext.Current.Request["limit"];
    return Ok(ContactsHelper.Instanct.GetConnectionInfo(Phone, ClassType, page, limit));
}
```

**`Contacts/AlikeConnections`** — `ContactsController.cs:99`

```csharp
[Route("AlikeConnections"), HttpPost]
public IHttpActionResult AlikeConnections()
{
    string OpenId = HttpContext.Current.Request["OpenId"];
    int Limite = Convert.ToInt32(HttpContext.Current.Request["Limite"]);
    string MyOpenId = HttpContext.Current.Request["MyOpenId"];
    string OpenIds = HttpContext.Current.Request["OpenIdList"];
    string[] OpenIdList = new string[0];
    if (!string.IsNullOrWhiteSpace(OpenIds))
    {
        OpenIdList = OpenIds.Split(',');
    }
    return Ok(ContactsHelper.Instanct.AlikeConnections(OpenId, Limite, MyOpenId, OpenIdList));
}
```

**`Contacts/GetContactsLowerList`** — `ContactsController.cs:176`

```csharp
[Route("GetContactsLowerList"), HttpPost]
public IHttpActionResult GetContactsLowerList()
{
    int limite = Convert.ToInt32(HttpContext.Current.Request["limite"]);
    int page = Convert.ToInt32(HttpContext.Current.Request["page"]);
    string OpenId = HttpContext.Current.Request["OpenId"];
    string OpenIdPass = HttpContext.Current.Request["OpenIdPass"];
    return Ok(ContactsHelper.Instanct.GetContactsLowerList(OpenId, OpenIdPass, limite, page));
}
```

**`Contacts/GetContactsLowerCount`** — `ContactsController.cs:165`

```csharp
[Route("GetContactsLowerCount"), HttpPost]
public IHttpActionResult GetContactsLowerCount()
{
    string OpenId = HttpContext.Current.Request["OpenId"];
    string OpenIdPass = HttpContext.Current.Request["OpenIdPass"];
    return Ok(ContactsHelper.Instanct.GetContactsLowerCount(OpenId, OpenIdPass));
}
```

### 3.3 好友申请

**`Apply/UserApplyMax`** — `HRflag.WxSp\Controllers\ApplyController.cs:132`

```csharp
[Route("UserApplyMax"), HttpPost]
public IHttpActionResult UserApplyMax()
{
    string strOpenId = HttpContext.Current.Request["OpenId"];
    return Ok(ApplyHelper.Instanct.UserApplyMax(strOpenId));
}
```

**`Apply/AddUserApply`** — `ApplyController.cs:22`

```csharp
[Route("AddUserApply"), HttpPost]
public IHttpActionResult AddUserApply()
{
    string SOpenId = HttpContext.Current.Request["SOpenId"];
    string BOpenId = HttpContext.Current.Request["BOpenId"];
    string PhoneNo = HttpContext.Current.Request["PhoneNo"];
    return Ok(ApplyHelper.Instanct.AddUserApply(SOpenId, BOpenId, PhoneNo));
}
```

**`Apply/GetSUserApplyList`** — `ApplyController.cs:58`

```csharp
[Route("GetSUserApplyList"), HttpPost]
public IHttpActionResult GetSUserApplyList()
{
    string strOpenId = HttpContext.Current.Request["OpenId"];
    string SenderPhone = HttpContext.Current.Request["SenderPhone"];
    string Query = HttpContext.Current.Request["Query"];
    return Ok(ApplyHelper.Instanct.GetSUserApplyList(SenderPhone, strOpenId, Query));
}
```

**`Apply/GetFUserApplyList`** — `ApplyController.cs:85`

```csharp
[Route("GetFUserApplyList"), HttpPost]
public IHttpActionResult GetFUserApplyList()
{
    string strOpenId = HttpContext.Current.Request["OpenId"];
    string Query = HttpContext.Current.Request["Query"];
    return Ok(ApplyHelper.Instanct.GetFUserApplyList(strOpenId, Query));
}
```

**`Apply/PassUserApply`** — `ApplyController.cs:112`

```csharp
[Route("PassUserApply"), HttpPost]
public IHttpActionResult PassUserApply()
{
    int aid = int.Parse(HttpContext.Current.Request["AId"]);
    return Ok(ApplyHelper.Instanct.PassUserApply(aid));
}
```

**`Apply/AdoptUserApply`** — `ApplyController.cs:97`

```csharp
[Route("AdoptUserApply"), HttpPost]
public IHttpActionResult AdoptUserApply()
{
    string aid = HttpContext.Current.Request["AId"];
    string OpenId = HttpContext.Current.Request["OpenId"];
    string OpenIdPass = HttpContext.Current.Request["OpenIdPass"];
    string IPAddress = HttpContext.Current.Request["IPAddress"];
    string IPAttach = HttpContext.Current.Request["IPAttach"];
    return Ok(ApplyHelper.Instanct.AdoptUserApply(aid, OpenId, OpenIdPass, IPAddress, IPAttach));
}
```

### 3.4 访客 / 收藏 / 点赞记录

**`UserInfo/GetCountAllorAdd`** — `UserController.cs:1116`

```csharp
[Route("GetCountAllorAdd"), HttpPost]
public IHttpActionResult GetCountAllorAdd()
{
    string OpenId = HttpContext.Current.Request["OpenId"];
    string UserType = HttpContext.Current.Request["UserType"];
    string Type = HttpContext.Current.Request["Type"];
    return Ok(UserHelper.Instanct.GetCountAllorAdd(OpenId, int.Parse(UserType), int.Parse(Type)));
}
```

**`UserInfo/GetLookUser` / `GetUserLook` / `GetCollectUser` / `GetUserCollect` / `GetlikeUser` / `GetUserlike`** — `UserController.cs:1090 / 1081 / 1072 / 1063 / 1054 / 1045`

```csharp
[Route("GetLookUser"), HttpPost]
public IHttpActionResult GetLookUser()
{
    string OpenId = HttpContext.Current.Request["OpenId"];
    string OpenIdPass = HttpContext.Current.Request["OpenIdPass"];
    int limit = int.Parse(HttpContext.Current.Request["limit"]);
    int page = int.Parse(HttpContext.Current.Request["page"]);
    return Ok(UserHelper.Instanct.GetLookUser(OpenId, OpenIdPass, limit, page));
}
```

> 其余 5 个方法代码完全同构，仅 `Helper` 方法名不同（`GetUserLook` / `GetCollectUser` / `GetUserCollect` / `GetlikeUser` / `GetUserlike`），参数与解析方式一致。

### 3.5 互动行为

**`Contacts/AddUserAction`** — `ContactsController.cs:530`

```csharp
[Route("AddUserAction"), HttpPost]
public IHttpActionResult AddUserAction()
{
    string OpenId = HttpContext.Current.Request["OpenId"];
    int KindId = Convert.ToInt32(HttpContext.Current.Request["KindId"]);
    int ContentId = Convert.ToInt32(HttpContext.Current.Request["ContentId"]);
    string Remarks = HttpContext.Current.Request["Remarks"];
    UserActionHelper.Instanct.AddUserAction(OpenId, KindId, ContentId, Remarks);
    return Ok();
}
```

> 该方法**丢弃了 Helper 的返回值**，固定返回空体 `Ok()`。接口文档中"返回 1 表示成功"只适用于 `AddUserActions`，前端不要依赖 `AddUserAction` 的返回值。

**`Contacts/AddUserActions`** — `ContactsController.cs:563`

```csharp
[Route("AddUserActions"), HttpPost]
public IHttpActionResult AddUserActions()
{
    string OpenId = HttpContext.Current.Request["OpenId"];
    int KindId = Convert.ToInt32(HttpContext.Current.Request["KindId"]);
    int ContentId = Convert.ToInt32(HttpContext.Current.Request["ContentId"]);
    string Remarks = HttpContext.Current.Request["Remarks"];
    return Ok(UserActionHelper.Instanct.AddUserActions(OpenId, KindId, ContentId, Remarks));
}
```

### 3.6 会议活动与报告位

**`ActiveMeeting/GetinnerActivemeetingNew`** — `HRflag.WebApi\Controllers\ActiveMeetingController.cs:138`

```csharp
[Route("GetinnerActivemeetingNew"), HttpPost]
public IHttpActionResult GetinnerActivemeetingNew(int limit = 10, int page = 1)
{
    return Ok(am.GetinnerActivemeetingNew(limit, page));
}
```

> 支持 `limit`、`page` 查询参数（默认 10 / 1），前端未传时取默认值。

**`ActiveMeeting/GetActivemeeting`** — `ActiveMeetingController.cs:144`

```csharp
[Route("GetActivemeeting"), HttpPost]
public IHttpActionResult GetActivemeeting()
{
    return Ok(am.GetActivemeeting());
}
```

**`ActiveMeeting/ActiveClickRecord`** — `ActiveMeetingController.cs:152`

```csharp
[Route("ActiveClickRecord"), HttpPost]
public IHttpActionResult ActiveClickRecord(string userId, int aDid)
{
    return Ok(am.ActiveClickRecord(userId, aDid));
}
```

**`Activity/GetHotActivityDetail`** — `HRflag.WebApi\Controllers\ActivityController.cs:3133`

```csharp
[Route("GetHotActivityDetail"), HttpPost]
public IHttpActionResult GetHotActivityDetail(int count, string ScenceID = "")
{
    return Ok(ActivityQueryHelper.Instanct.GetHotActivityDetail(count, ScenceID));
}
```

**`FileMgr/GetHighForceFileld`** — `HRflag.WebApi\Controllers\FileMgrController.cs:1081`

```csharp
[Route("GetHighForceFileld"), HttpPost]
public IHttpActionResult GetHighForceFileld(int Switch, int limit = 9)
{
    return Ok(fh.GetHighForceFileld(Switch, limit));
}
```

> 源码语义（`DBConnection\Helper\FileHelper.cs:3760`）：`Switch=3` 取**当天**下载量 TOP N，`Switch=1` 取**近 7 天**下载量 TOP N；`limit` 默认 9。人脉首页传 `Switch=3` 且未传 `limit`，因此实际返回 9 条。接口文档中"推荐位开关/类型 固定 3"表述不准确，应为"统计区间"。

### 3.7 快讯

**`Twitter/GetHrflagTwitter`** — `HRflag.WebApi\Controllers\TwitterController.cs:62`

```csharp
[Route("GetHrflagTwitter"), HttpPost]
public IHttpActionResult GetHrflagTwitter()
{
    string UserId = HttpContext.Current.Request["UserId"];
    int top = int.Parse(HttpContext.Current.Request["top"]);
    return Ok(TwitterHelper.Instanct.GetHrflagTwitter(UserId, top));
}
```

**`Twitter/AddTwitterLike`** — `TwitterController.cs:795`

```csharp
[Route("AddTwitterLike"), HttpPost]
public IHttpActionResult AddTwitterLike()
{
    string strGuid = HttpContext.Current.Request["Guid"];
    string strUserId = HttpContext.Current.Request["UserId"];
    return Ok(TwitterHelper.Instanct.AddTwitterLike(strGuid, strUserId));
}
```

**`Twitter/ChangeTwitters`** — `TwitterController.cs:777`

```csharp
[Route("ChangeTwitters"), HttpPost]
public IHttpActionResult ChangeTwitters()
{
    string UserId = HttpContext.Current.Request["UserId"];
    string strGuid = HttpContext.Current.Request["Guid"];
    int limit = int.Parse(HttpContext.Current.Request["limit"]);
    return Ok(TwitterHelper.Instanct.ChangeTwitters(UserId, strGuid, limit));
}
```

**`Twitter/AddTwitterView`** — `TwitterController.cs:760`

```csharp
[Route("AddTwitterView"), HttpPost]
public IHttpActionResult AddTwitterView([FromBody] TwitterQuery query)
{
    return Ok(TwitterHelper.Instanct.AddTwitterView(query));
}
```

> 本模块唯一使用 `[FromBody]` 的接口，参数类型为 `TwitterQuery`（`TwitterHelper.cs:3243`，含 `Object`、`PubName`、`ClassId`、`IsAdvertising`、`IsDelete`）。前端以 jQuery 默认表单提交 `data: { Object: guid }` 时，由 Web API 2 内置的 `JQueryMvcFormUrlEncodedFormatter` 按表单键名填充，**无需设置 `contentType: application/json`**；若改为 JSON 提交，则键名大小写必须与模型属性一致。

**`Twitter/GetUserLike`** — `TwitterController.cs:871`

```csharp
[Route("GetUserLike"), HttpPost]
public IHttpActionResult GetUserLike()
{
    string Guid = HttpContext.Current.Request["Guid"];
    return Ok(TwitterHelper.Instanct.GetUserLike(Guid) + TwitterHelper.Instanct.GetWXUserLike(Guid));
}
```

> 返回值是**两处点赞数之和**（站内 + 小程序），排查点赞数不一致时看这里。

### 3.8 广告位与埋点

**`Advertising/IGetPersonConnectionAdv`** — `HRflag.WebApi\Controllers\AdvertisingController.cs:1678`

```csharp
[Route("IGetPersonConnectionAdv"), HttpPost]
public IHttpActionResult IGetPersonConnectionAdv()
{
    return Ok(adshp.IGetPersonConnectionAdv());
}
```

**`Advertising/IGetFriendApplyForAdv`** — `AdvertisingController.cs:2472`

```csharp
[Route("IGetFriendApplyForAdv"), HttpPost]
public IHttpActionResult IGetFriendApplyForAdv()
{
    return Ok(adshp.IGetFriendApplyForAdv());
}
```

**`Advertising/IGetFriendTableAdv`** — `AdvertisingController.cs:2209`

```csharp
[Route("IGetFriendTableAdv"), HttpPost]
public IHttpActionResult IGetFriendTableAdv()
{
    return Ok(adshp.IGetFriendTableAdv());
}
```

**`Advertising/IGetStrangerADAdv`** — `AdvertisingController.cs:2604`

```csharp
[Route("IGetStrangerADAdv"), HttpPost]
public IHttpActionResult IGetStrangerADAdv()
{
    return Ok(adshp.IGetStrangerADAdv());
}
```

**`Advertising/IGetTopAD`** — `AdvertisingController.cs:191`

```csharp
[Route("IGetTopAD"), HttpPost]
public IHttpActionResult IGetTopAD(string userId)
{
    return Ok(adshp.IGetTopAD(userId));
}
```

**`Advertising/Advertising/IAddMeetingUPClickRecord`** — `AdvertisingController.cs:331`

```csharp
[Route("IAddMeetingUPClickRecord"), HttpPost]
public IHttpActionResult IAddMeetingUPClickRecord(string userId, int aDid)
{
    return Ok(adshp.IAddMeetingUPClickRecord(userId, aDid));
}
```

**`Advertising/IAddTopADClickRecord`** — `AdvertisingController.cs:201`

```csharp
[Route("IAddTopADClickRecord"), HttpPost]
public IHttpActionResult IAddTopADClickRecord(string userId, int aDid)
{
    return Ok(adshp.IAddTopADClickRecord(userId, aDid));
}
```

> **重要发现**：该方法的源码为 `[RoutePrefix("Advertising")]` + `[Route("IAddMeetingUPClickRecord")]`（`AdvertisingController.cs:330`），即后端真实路径只有 **一段** `Advertising`：
>
> - 后端真实可达：`POST /WebAPI/Advertising/IAddMeetingUPClickRecord`
> - 前端实际调用：`POST /WebAPI/Advertising/Advertising/IAddMeetingUPClickRecord`（多一段）
>
> 前端多写的一段 `Advertising` 在 Web API 特性路由下不匹配任何模板，该请求**大概率 404**，只是该方法 `success` 回调为空，前端从未感知，因此埋点可能一直未生效。联调时需修正前端 URL 或后端补一条 `[Route("Advertising/IAddMeetingUPClickRecord")]`。

---

## 4. 源码与接口文档的差异清单

联调与排障时以下差异需以**源码**为准：

| 接口 | 接口文档 | 源码实际 | 影响 |
|---|---|---|---|
| `Contacts/GetConnections` | `OpenId`、`Query`、`classType`、`page`、`Limite` | 另支持 `TradName`、`Department`、`Place` 三个筛选参数 | 可扩展按行业/部门/城市筛选，前端未使用 |
| `Contacts/GetConnectionsCount` | `Query`、`sortType` | 实际读取 `classType`，**不读 `sortType`** | 文档中"sortType 固定传 0"无效，改传 `classType` |
| `Contacts/GetConnectionInfo` | `ClassType` 为 int | 源码按 **string** 接收后由 Helper 转换 | 传 `"0"`/`"1"` 均可，但不能传空 |
| `Apply/AddUserApply` | `SOpenId`、`BOpenId` | 另支持 `PhoneNo` | 可选补充申请人手机号 |
| `Apply/GetSUserApplyList` | `OpenId` | 另支持 `SenderPhone`、`Query` | 支持按申请人与关键词筛选 |
| `Apply/GetFUserApplyList` | `OpenId` | 另支持 `Query` | 支持已发申请内搜索 |
| `Apply/AdoptUserApply` | `AId`、`OpenId`、`OpenIdPass` | 另支持 `IPAddress`、`IPAttach` | 建议一并传，便于风控记录 |
| `Contacts/AddUserAction` | 返回 `1` 表示成功 | 固定返回 `Ok()`（空体） | 前端不可依赖返回值判断 |
| `FileMgr/GetHighForceFileld` | `Switch` 为"推荐位类型"，固定 3 | `Switch=3` 取当天下载榜、`Switch=1` 取近 7 天下载榜；`limit` 默认 9 | 人脉首页实际返回 9 条（非 3 条） |
| `ActiveMeeting/GetinnerActivemeetingNew` | 无参数 | 支持 `limit`、`page` | 需要时可直接分页 |
| `Advertising/Advertising/IAddMeetingUPClickRecord` | 路径含两段 `Advertising` | 后端仅 `Advertising/IAddMeetingUPClickRecord` | 前端多写一段，请求应为 404，埋点失效 |

---

## 5. 已确认问题

1. **`Advertising/Advertising/IAddMeetingUPClickRecord` 路径错误**：`AdvertisingController` 为 `[RoutePrefix("Advertising")]`，方法特性为 `[Route("IAddMeetingUPClickRecord"), HttpPost]`（`AdvertisingController.cs:330`），后端可达路径只有 `POST /WebAPI/Advertising/IAddMeetingUPClickRecord`。前端多拼的一段 `Advertising` 无法匹配任何路由，请求应为 404；由于该方法 `success` 回调为空，前端无感知，广告点击埋点实际未落库。修复方式二选一：前端改为单段路径，或后端补 `[Route("Advertising/IAddMeetingUPClickRecord")]` 兼容。
2. **`GetHighForceFileld` 的 `Switch` 是统计区间而非推荐位**：`FileHelper.cs:3760` 中 `case 3` 用当天 `DownRecord` 统计、`case 1` 用 `DATEADD(DAY,-7,GETDATE())` 近 7 天统计，均按 `SUMCOUNT DESC` 排序。接口文档中的"推荐位类型"应按此修正。
3. **`ContactsHelper.Instanct`** 为单例属性写法（`Instanct` 而非 `Instance`），属历史拼写，非笔误，不要"修正"。
