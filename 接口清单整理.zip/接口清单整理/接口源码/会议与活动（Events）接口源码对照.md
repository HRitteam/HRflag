# 会议与活动（Events）接口源码对照文档

| 项目 | 内容 |
|---|---|
| 对应接口文档 | `接口文档/03-会议与活动（Events）接口文档.md` |
| 后端源码根目录 | `G:\HRflag\_backend_bms` |
| 涉及工程 | `HRflag.WebApi`（WebAPI）、`HRflag.WxSp`（WxSpAPI） |
| 涉及模型 | `HRflag.ActivityModel`、`HRflag.Model`、`HRflag.EF` |
| 文档版本 | v1.0 |
| 更新日期 | 2026-11-17 |

---

## 1. 源码定位说明

### 1.1 工程与控制器

活动模块接口集中在 `HRflag.WebApi`，另有 4 个接口在 `HRflag.WxSp`。

| 控制器 | 绝对路径 | RoutePrefix | 服务接口 |
|---|---|---|---|
| ActivityController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\ActivityController.cs` | `Activity` | 活动详情、场次、报名、订单、支付、渠道、直播、隐私 |
| ActivityUserController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\ActivityUserController.cs` | `ActivityUser` | 分类、类型字典 |
| NewFormController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\NewFormController.cs` | `NewForm` | 报名提交、用户资料、主办方表单 |
| FormController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\FormController.cs` | `Form` | 验证码 |
| FormOrderController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\FormOrderController.cs` | `FormOrder` | 订单、支付状态 |
| SystemController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\SystemController.cs` | `System` | 登录用户信息 |
| OnlineSpoorController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\OnlineSpoorController.cs` | `OnlineSpoor` | 线上留资 |
| DepartmenController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\DepartmenController.cs` | `Departmen` | 部门、行业字典 |
| ImageFileController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\ImageFileController.cs` | `ImageFile` | 二维码 |
| PhoneInController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\PhoneInController.cs` | `PhoneInCont` | 手机号归属地 |
| ProjectController（WxSp） | `G:\HRflag\_backend_bms\HRflag.WxSp\Controllers\ProjectController.cs` | `ProjectList` | 隐私模板 |
| ActivityShareController（WxSp） | `G:\HRflag\_backend_bms\HRflag.WxSp\Controllers\ActivityShareController.cs` | `ActivitiesShare` | 分享有礼 |
| MicroLessonController（WxSp） | `G:\HRflag\_backend_bms\HRflag.WxSp\Controllers\MicroLessonController.cs` | `MicroLesson` | 订单号 |
| UserController（WxSp） | `G:\HRflag\_backend_bms\HRflag.WxSp\Controllers\UserController.cs` | `UserInfo` | 扫码绑定 |

> **注意重复实现**：`HRflag.ActivityWebApi\Controllers\ActivityController.cs` 中也有一套同名方法（`AddCustomerInfo`、`SchoolPosition`、`GetCustomerByNo` 等），但该方法库仅 11.5KB，属早期/精简版本。线上 `form.hrflag.com/WebAPI/*` 由 `HRflag.WebApi` 提供，**排查请以 `HRflag.WebApi` 为准**。

### 1.2 业务层位置

| 类型 | 文件 | 服务接口 |
|---|---|---|
| `ActivityHelper` | `ActivityDBCon\DataHelper\ActivityHelper.cs` | 活动详情、报名提交、学校字典 |
| `ActivityQueryHelper` | `ActivityDBCon\DataHelper\ActivityQueryHelper.cs` | 列表、场次、订单查询、隐私 |
| `ActivityCommon` | `ActivityDBCon` | 重复报名校验 |
| `ActivityConfigHelper` | `ActivityDBCon` | 分类/类型字典 |
| `ActivitySourceHelper` | `ActivityDBCon` | 渠道来源 |
| `PayHelper` | `DBConnection\Helper\PayHelper.cs` | 支付回写 |
| `NewFormHelper` | `DBConnection\Helper\NewFormHelper.cs` | 报名、用户、表单 |
| `FormOrderHelper` | `DBConnection\Helper\FormOrderHelper.cs` | 订单 |
| `OnlineHelper` | `DBConnection\Helper\OnlineHelper.cs` | 线上留资 |

---

## 2. 接口 ↔ 源码总览

### 2.1 列表与筛选

| 接口 | 源码位置 | 方法签名 |
|---|---|---|
| `ActivityUser/GetAllCategory` | `ActivityUserController.cs:161` | `GetAllCategory()` |
| `ActivityUser/GetCategory` | `ActivityUserController.cs:175` | `GetCategory(string CategoryName)` |
| `ActivityUser/GetAllActivityType` | `ActivityUserController.cs:136` | `GetAllActivityType()` |
| `Activity/GetActivityListTwo` | `ActivityController.cs:3217` | `GetActivityListTwo([FromBody] ActivityListCommon)` |

### 2.2 详情与场次

| 接口 | 源码位置 | 方法签名 |
|---|---|---|
| `Activity/GetHRflagActivityByIdNewShow` | `ActivityController.cs:214` | `(string ActivityId="", string SceneId="", int IsShow=0, int IsShow2=0, string unfold="")` |
| `Activity/GetHRflagActivityByIdNew` | `ActivityController.cs:192` | `(string ActivityId="", string SceneId="", int IsShow=0, int IsShow2=0)` |
| `Activity/GetActivityById` | `ActivityController.cs:154` | `(string ActivityId="", string SceneId="")` |
| `Activity/GetSceneInfoNew` | `ActivityController.cs:3153` | `(string SceneID, string phone)` |
| `Activity/IfUserIsApply` | `ActivityController.cs:3174` | `(string sceneId, string phone)` |
| `Activity/ComPrivacy` | `ActivityController.cs:3928` | `(string ActivityId)` |
| `Activity/MenuComPrivacyShow` | `ActivityController.cs:3934` | `(string ActivityIds)` |
| `Activity/GetActivityInfoMap` | `ActivityController.cs:291` | `(string SceneId="")` |
| `Activity/GetHotActivityDetail` | `ActivityController.cs:3133` | `(int count, string ScenceID="")` |
| `Activity/GetNewActivityDetail` | `ActivityController.cs:3143` | `(int count, string ScenceId="")` |
| `Activity/GetActivityName` | `ActivityController.cs:1819` | `GetActivityName()` |
| `Activity/GetOrderNo` | `ActivityController.cs:1450` | `GetOrderNo()` |
| `ProjectList/DataIdToTemplate` | `HRflag.WxSp\Controllers\ProjectController.cs:680` | `(int type, string dataId)` |
| `ActivitiesShare/WxSelectActivityShare` | `HRflag.WxSp\Controllers\ActivityShareController.cs:108` | `WxSelectActivityShare()` |

### 2.3 报名与用户信息

| 接口 | 源码位置 | 方法签名 |
|---|---|---|
| `Form/GetVF` | `FormController.cs:30` | `GetVF([FromBody] string txtPhoneNum)`（路由 `GetVf`） |
| `Form/CheckVFCode` | `FormController.cs:86` | `CheckVFCode([FromBody] MsgVerifyCode MsgVF)` |
| `NewForm/GetUser` | `NewFormController.cs:585` | `(string phone)` |
| `System/GetUserInfo` | `SystemController.cs:42` | `GetUserInfo([FromBody] UserLoginInput input)` |
| `NewForm/UpdateUserByPhone` | `NewFormController.cs:621` | `([FromBody] CustomerInfo)` |
| `NewForm/AddCustomerAllInfo` | `NewFormController.cs:405` | `([FromBody] CustomerInfo)` |
| `NewForm/AddCustomerInfoTwo` | `NewFormController.cs:333` | `([FromBody] CustomerInfo)` |
| `Activity/AddCustomerInfo` | `ActivityController.cs:506` | `([FromBody] SellTicketsInfo, int IfGoEmail=-1)` |
| `Activity/AddYLCustomerInfo` | `ActivityController.cs:632` | `([FromBody] SellTicketsInfo, int IfGoEmail=-1)` |
| `Activity/CheckUserRegist` | `ActivityController.cs:591` | `CheckUserRegist()` |
| `Activity/CheckUserOrder` | `ActivityController.cs:637` | **方法名为 `CheckUserRegist`**，`([FromBody] SellTicketsInfo)` |
| `Activity/CheckUserDifOrder` | `ActivityController.cs:642` | `([FromBody] SellTicketsInfo)` |
| `Activity/GetCustomerByNo` | `ActivityController.cs:1588` | `(string OrderNo)` |
| `NewForm/CheckCustomSignIn` | `NewFormController.cs:700` | `(string ActivityId, string SceneId, string PhoneNo)` |
| `NewForm/IsFormSignUp` | `NewFormController.cs:285` | `IsFormSignUp()`（读 `Phone`、`FormId`） |
| `OnlineSpoor/GetCustomerInfo` | `OnlineSpoorController.cs:20` | `(string SceneId, string PhoneNo, int Status=0)` |
| `OnlineSpoor/AddOnlineSpoor` | `OnlineSpoorController.cs:15` | `([FromBody] CustomerOnlineSpoor)` |
| `Departmen/GetAllDepart` | `DepartmenController.cs:15` | `GetAllDepart()` |
| `Departmen/GetAllTradeInfo` | `DepartmenController.cs:20` | `GetAllTradeInfo()` |
| `Activity/SchoolDepartmentn` | `ActivityController.cs:359` | `SchoolDepartmentn()` |
| `Activity/SchoolCompany` | `ActivityController.cs:370` | `SchoolCompany()` |
| `Activity/SchoolPosition` | `ActivityController.cs:347` | `SchoolPosition()` |
| `Activity/Schoolindustry` | `ActivityController.cs:381` | `Schoolindustry()` |
| `PhoneInCont/GetPhoneIn` | `PhoneInController.cs:18` | `GetPhoneIn()`（读 `Phone`） |
| `ImageFile/AddQRinfo` | `ImageFileController.cs:29` | `(string url, string nid)` |
| `UserInfo/SelectPhoneScan` | `HRflag.WxSp\Controllers\UserController.cs:1129` | `SelectPhoneScan()` |

### 2.4 支付与订单

| 接口 | 源码位置 | 方法签名 |
|---|---|---|
| `FormOrder/IfFormIsBuy` | `FormOrderController.cs:137` | `(string activityId)` |
| `FormOrder/GetTakeDeliveryInfo` | `FormOrderController.cs:59` | `(string phone)` |
| `FormOrder/AddFormOrderInfo` | `FormOrderController.cs:268` | `([FromBody] FormOrderInfo info)` |
| `FormOrder/IfIsNoPayment` | `FormOrderController.cs:445` | `(string activityId, string phone)` |
| `FormOrder/UpdatePayTime` | `FormOrderController.cs:313` | `(string order)` |
| `MicroLesson/GetOrderNo` | `HRflag.WxSp\Controllers\MicroLessonController.cs:1887` | `GetOrderNo()`，`[HttpGet]` |
| `NewForm/BulkUpdatesFormOrderNew` | `NewFormController.cs:59` | `(string OrderNo)` |
| `Activity/GetCustomOrder` | `ActivityController.cs:3116` | `(string OrderNo)` |
| `Activity/RecordAliPay` | `ActivityController.cs:3323` | `(string OrderNo)` → `PayHelper.AliPayRecord` |
| `Activity/RecordWxPay` | `ActivityController.cs:3317` | `(string OrderNo)` → `PayHelper.WxPayRecord` |

### 2.5 渠道与直播

| 接口 | 源码位置 | 方法签名 |
|---|---|---|
| `Activity/GetHRSceneALive` | `ActivityController.cs:3894` | `(string SceneId)` |
| `Activity/GetSpecialIdByScenceId` | `ActivityController.cs:3444` | `GetSpecialIdByScenceId()`（读 `ScenceId`） |
| `Activity/GetSourceIdBySpecialId` | `ActivityController.cs:3454` | `GetSourceIdBySpecialId()`（读 `ScenceId`、`SpecialId`） |
| `Activity/AddustomerSoure` | `ActivityController.cs:3413` | `AddustomerSoure()`（读 `OrderNo`、`SourceId`、`SpecialId`） |
| `Activity/AddSourceView` | `ActivityController.cs:3422` | `AddSourceView()`（读 `SourceId`、`UserCode`、`IpAddress`、`IpAttach`） |

### 2.6 主办方表单

| 接口 | 源码位置 | 方法签名 |
|---|---|---|
| `NewForm/GetActivityById` | `NewFormController.cs:563` | `(string ActivityID)` |
| `NewForm/GetSceInfoById` | `NewFormController.cs:690` | `(string ActivityId, int CheckStatus=0)` |
| `NewForm/GetActivityName` | `NewFormController.cs:579` | `(string id)` |
| `NewForm/UpdateActivityStatus` | `NewFormController.cs:451` | `(DateTime dtNowDate, string strActivityId)` |

---

## 3. 关键源码摘录

**`Activity/GetActivityListTwo`** — `ActivityController.cs:3217`

```csharp
[Route("GetActivityListTwo"), HttpPost]
public IHttpActionResult GetActivityListTwo([FromBody] ActivityListCommon activityListCommon)
{
    return Ok(ActivityQueryHelper.Instanct.GetActivityListTwo(activityListCommon));
}
```

**`Activity/GetHRflagActivityByIdNewShow`** — `ActivityController.cs:214`

```csharp
[Route("GetHRflagActivityByIdNewShow"), HttpPost]
public IHttpActionResult GetHRflagActivityByIdNewShow(string ActivityId = "", string SceneId = "", int IsShow = 0, int IsShow2 = 0, string unfold = "")
{
    return Ok(ActivityHelper.Instanct.GetHRflagActivityByIdNewShow(ActivityId, SceneId, IsShow, IsShow2, unfold));
}
```

**`Activity/GetSceneInfoNew` / `IfUserIsApply`** — `ActivityController.cs:3153 / 3174`

```csharp
[Route("GetSceneInfoNew"), HttpPost]
public IHttpActionResult GetSceneInfoNew(string SceneID, string phone)
{
    return Ok(ActivityQueryHelper.Instanct.GetSceneInfoNew(SceneID, phone));
}

[Route("IfUserIsApply"), HttpPost]
public IHttpActionResult IfUserIsApply(string sceneId, string phone)
{
    return Ok(ActivityQueryHelper.Instanct.IfUserIsApply(sceneId, phone));
}
```

**`Activity/AddCustomerInfo`** — `ActivityController.cs:506`

```csharp
[Route("AddCustomerInfo"), HttpPost]
public IHttpActionResult AddCustomerInfo([FromBody] SellTicketsInfo sellTicketsInfo, int IfGoEmail = -1)
{
    // 调用调整后的方法获取IP地址
    string clientIpAddress = GetClientIpAddress();

    sellTicketsInfo.IPAttach = clientIpAddress;
    sellTicketsInfo.IPAddress = NewFormHelper.Instanct.GetIpLocation(clientIpAddress);
    // ...（后续 ModelState 校验代码已整体注释）
}
```

> **关键行为**：控制器会用服务端取到的 IP 与归属地**覆盖**前端传入的 `IPAddress`、`IPAttach`；同时 `ModelState.IsValid` 校验段整体被注释，`SellTicketsInfo` 上的 `[Required]` 实际不生效，前端必须自行校验。

**`Activity/CheckUserRegist`（重复报名校验）** — `ActivityController.cs:591`

```csharp
[Route("CheckUserRegist"), HttpPost]
public IHttpActionResult CheckUserRegist()
{
    string PhoneNo = HttpContext.Current.Request["PhoneNo"];
    string SceneId = HttpContext.Current.Request["SceneId"];
    SellTicketsInfo model = new SellTicketsInfo();
    model.PhoneNo = PhoneNo;
    model.SceneId = SceneId;
    return Ok(ActivityCommon.Instanct.CheckUserRegist(model));
}
```

> 只读取 `PhoneNo`、`SceneId` 两个字段，传 `ActivityId` 无效。

**`Activity/CheckUserOrder`（方法名是 `CheckUserRegist` 重载）** — `ActivityController.cs:637`

```csharp
[Route("CheckUserOrder"), HttpPost]
public IHttpActionResult CheckUserRegist([FromBody] SellTicketsInfo sellTicketsInfo)
{
    return Ok(ActivityHelper.Instanct.CheckUserOrder(sellTicketsInfo));
}
```

> 同一控制器内两个 `CheckUserRegist` 方法，靠 `[Route]` 区分（`CheckUserRegist` / `CheckUserOrder`），是合法的重载写法；按方法名检索源码时会出现两处，注意看 `[Route]`。

**`Activity/GetCustomOrder` / `GetCustomerByNo`** — `ActivityController.cs:3116 / 1588`

```csharp
[Route("GetCustomOrder"), HttpPost]
public IHttpActionResult GetCustomOrder(string OrderNo)
{
    return Ok(ActivityQueryHelper.Instanct.GetCustomOrder(OrderNo));
}

[Route("GetCustomerByNo"), HttpPost]
public IHttpActionResult GetCustomerByNo(string OrderNo)
{
    return Ok(ActivityQueryHelper.Instanct.GetCustomerByNo(OrderNo));
}
```

**`Activity/RecordAliPay` / `RecordWxPay`** — `ActivityController.cs:3323 / 3317`

```csharp
[Route("RecordWxPay"), HttpPost]
public IHttpActionResult RecordWxPay(string OrderNo)
{
    return Ok(PayHelper.Instanct.WxPayRecord(OrderNo));
}

[Route("RecordAliPay"), HttpPost]
public IHttpActionResult RecordAliPay(string OrderNo)
{
    return Ok(PayHelper.Instanct.AliPayRecord(OrderNo));
}
```

**`Activity/AddustomerSoure` / `AddSourceView`** — `ActivityController.cs:3413 / 3422`

```csharp
[Route("AddustomerSoure"), HttpPost]
public IHttpActionResult AddustomerSoure()
{
    string strOrderNo = HttpContext.Current.Request["OrderNo"];
    string strSourceId = HttpContext.Current.Request["SourceId"];
    string strSpecialId = HttpContext.Current.Request["SpecialId"];
    return Ok(ActivitySourceHelper.Instanct.AddustomerSource(strOrderNo, strSourceId, strSpecialId));
}

[Route("AddSourceView"), HttpPost]
public IHttpActionResult AddSourceView()
{
    string strSourceId = HttpContext.Current.Request["SourceId"];
    string strUserCode = HttpContext.Current.Request["UserCode"];
    string strIPAddress = HttpContext.Current.Request["IpAddress"];
    string strIPAttach = HttpContext.Current.Request["IpAttach"];

    return Ok(ActivitySourceHelper.Instanct.AddSourceView(strSourceId, strUserCode, strIPAddress, strIPAttach));
}
```

> 方法名 `AddustomerSoure`（少一个 `c`、少一个 `s`）是历史拼写，路由、方法名、前端调用三者保持一致，**不可单方面改正**。

**`Activity/GetSpecialIdByScenceId` / `GetSourceIdBySpecialId`** — `ActivityController.cs:3444 / 3454`

```csharp
[Route("GetSpecialIdByScenceId"), HttpPost]
public IHttpActionResult GetSpecialIdByScenceId()
{
    string strScenceId = HttpContext.Current.Request["ScenceId"];
    return Ok(ActivitySourceHelper.Instanct.GetSpecialIdByScenceId(strScenceId));
}

[Route("GetSourceIdBySpecialId"), HttpPost]
public IHttpActionResult GetSourceIdBySpecialId()
{
    string strScenceId = HttpContext.Current.Request["ScenceId"];
    string strSpecialId = HttpContext.Current.Request["SpecialId"];
    return Ok(ActivitySourceHelper.Instanct.GetSourceIdBySpecialId(strScenceId, strSpecialId));
}
```

**`Activity/ComPrivacy` / `MenuComPrivacyShow`** — `ActivityController.cs:3928 / 3934`

```csharp
[Route("ComPrivacy"), HttpPost]
public IHttpActionResult ComPrivacy(string ActivityId)
{
    return Ok(ActivityQueryHelper.Instanct.ComPrivacy(ActivityId));
}

[Route("MenuComPrivacyShow"), HttpPost]
public IHttpActionResult MenuComPrivacyShow(string ActivityIds)
{
    return Ok(ActivityQueryHelper.Instanct.MenuComPrivacyShow(ActivityIds));
}
```

**`NewForm/AddCustomerAllInfo` / `AddCustomerInfoTwo`** — `NewFormController.cs:405 / 333`

```csharp
[Route("AddCustomerInfoTwo"), HttpPost]
public IHttpActionResult AddCustomerInfoTwo([FromBody] CustomerInfo customerInfo)
{
    // 调用调整后的方法获取IP地址
    string clientIpAddress = GetClientIpAddress();

    customerInfo.IPAttac = clientIpAddress;
    customerInfo.IPAddress = NewFormHelper.Instanct.GetIpLocation(clientIpAddress);
    return Ok(NewFormHelper.Instanct.AddCustomerInfoTwo(customerInfo));
}
```

> 同样由服务端覆盖 IP 字段；注意属性名是 **`IPAttac`**（少一个 `h`），前端 `StartNewForm.js` 也传 `IPAttac`，两端一致但拼写错误。

**`FormOrder/AddFormOrderInfo`** — `FormOrderController.cs:268`

```csharp
[Route("AddFormOrderInfo"), HttpPost]
public IHttpActionResult AddFormOrderInfo([FromBody] FormOrderInfo info)
{
    try
    {
        // 调用调整后的方法获取IP地址
        string clientIpAddress = GetClientIpAddress();

        info.IP = clientIpAddress;
        info.IPAddress =GetIpLocation(clientIpAddress);

        return Ok(FormOrderHelper.Instanct.AddFormOrderInfo(info));
    }
    catch (Exception e)
    {
        LogHelper.Info("生成订单(AddFormOrderInfo)：" + e.Message);
        throw;
    }
}
```

**`MicroLesson/GetOrderNo`** — `HRflag.WxSp\Controllers\MicroLessonController.cs:1887`

```csharp
[Route("GetOrderNo"), HttpGet]
public IHttpActionResult GetOrderNo()
{
    try
    {
        return Ok(MicroLessonHelper.Instanct.GetOrderNo());
    }
    catch (Exception e)
    {
        LogHelper.Info("获取订单号(GetOrderNo)：" + e.Message);
        throw;
    }
}
```

> 全模块唯一显式 `[HttpGet]` 的接口。

---

## 4. 请求模型字段（源码为准）

### 4.1 `ActivityListCommon`（`Activity/GetActivityListTwo`）

`G:\HRflag\_backend_bms\HRflag.ActivityModel\Common\ActivityListCommon.cs`

| 字段 | 类型 | 说明 |
|---|---|---|
| PhoneNo | string | 手机号（文档未列） |
| Top | int | 置顶/条数（文档未列） |
| Type | string | 活动类型名称 |
| ActivityStatus | int | 0 全部 / 1 报名中 / 2 报名结束 / 3 已结束 |
| ActivityTitle | string | 标题关键词 |
| Page | int | 页码 |
| Limit | int | 每页条数 |
| ActivityCategory | string | 一级分类 |
| ActivityCateChild | string | 二级分类 |
| IsVipActivity | int | 是否 VIP 活动（文档未列） |
| Desc | int | 排序：1 最新发布 |
| CityId | string | 城市 ID（文档未列） |
| IsDirectly | string | 是否直辖市：1 否 / 2 是（文档未列） |

### 4.2 `SellTicketsInfo`（`Activity/AddCustomerInfo`、`AddYLCustomerInfo`、`CheckUserOrder`、`CheckUserDifOrder`）

`G:\HRflag\_backend_bms\HRflag.ActivityModel\ActivityModel\SellTicketsInfo.cs`

| 字段 | 类型 | 校验 | 说明 |
|---|---|---|---|
| PhoneNo | string | Required + `^1\d{10}$` | 手机号 |
| Name | string | Required | 姓名 |
| Company | string | Required | 公司 |
| TradName | string | Required | 行业 |
| Position | string | Required | 职位 |
| Department | string | Required | 部门 |
| Email | string | Required + 邮箱正则 | 邮箱 |
| ActivityId | string | - | 活动 ID |
| SceneId | string | - | 场次 ID |
| TicketId | string | - | 票种 ID |
| PurchaseNum | int? | - | 购买张数 |
| Status | int? | - | 状态 |
| OrderNo / OrderID | string | - | 订单号 / 票号 |
| PhoneNoIn | string | - | 归属地 |
| Comefrom | string | - | 来源渠道文案 |
| Remarks | string | - | 备注 |
| IPAddress / IPAttach | string | - | 由服务端覆盖 |
| JsonStr | string | - | 自定义字段 JSON |
| Scale | string | - | 规格 |
| IDNumber | string | - | 身份证号 |
| PlaceCity | string | - | 所在城市 |
| StaffNumber | string | - | 员工人数 |
| AssemblyRoom | string | - | 分会场 |

> 尽管模型标了 `[Required]`，但 `AddCustomerInfo` 中 `ModelState.IsValid` 分支被注释，**校验不会执行**；字段缺失只会在 Helper 里产生空值或异常。

### 4.3 `CustomerInfo`（`NewForm/AddCustomerAllInfo`、`AddCustomerInfoTwo`、`UpdateUserByPhone`）

`G:\HRflag\_backend_bms\HRflag.Model\Input\NewForm.cs:62`

`PhoneNo`、`Name`、`ActivityId`、`SceneId`、`Company`、`Industry`、`Position`、`Department`、`Email`、`Comefrom`、`PhoneIn`、`City`、`CompanySize`、`ProjectName`、`TrackName`、`ReferenceName`、`JsonStr`、`CompanyId`、`Source`、`IPAddress`、`IPAttac`、`Remarks`、`CheckStatus`。

### 4.4 `MsgVerifyCode`（`Form/CheckVFCode`）

`G:\HRflag\_backend_bms\HRflag.EF\MsgVerifyCode.cs:15`

| 字段 | 类型 | 说明 |
|---|---|---|
| PhoneNumber | string | 手机号 |
| MsgCode | string | 验证码 |
| MsgId | string | 消息 ID（可不传） |

---

## 5. 源码与接口文档 / 前端的差异

### 5.1 HTTP 方法核对（已逐条核对，结论：一致）

本模块前后端方法约定**没有不一致**。逐条核对结果：

| 接口 | 后端 | 前端调用方式 |
|---|---|---|
| `Departmen/GetAllDepart`、`GetAllTradeInfo` | `[HttpPost]` | `type: "POST"`（`codetail.js:1197`、`Form.js:2526`、`StartNewForm.js:1795`） |
| `PhoneInCont/GetPhoneIn` | `[HttpPost]` | `type: "POST"`（`codetail.js:2653`、`Form.js:2509`） |
| `FormOrder/IfFormIsBuy`、`GetTakeDeliveryInfo`、`AddFormOrderInfo`、`IfIsNoPayment`、`UpdatePayTime` | `[HttpPost]` | `method: "POST"`（`StartNewForm.js:1976 / 2060 / 2102 / 2148 / 2179`） |
| `MicroLesson/GetOrderNo` | `[HttpGet]` | `method: 'GET'`（`StartNewForm.js:2090`） |

> **排查提示**：这些调用把 `type`/`method` 写在 `url` **之后**，且有的用 `method:` 而非 `type:`。用脚本按 `url` 向前回溯查找 `type:` 时极易误判为 GET。核对请求方法请以 `url` 前后 4 行完整上下文为准。

### 5.2 参数与行为差异

| 接口 | 接口文档 | 源码实际 | 影响 |
|---|---|---|---|
| `Activity/GetHRflagActivityByIdNewShow` | 仅 `SceneId`、`unfold` | 支持 `ActivityId`、`IsShow`、`IsShow2` | 可按活动 ID 或展示开关查询 |
| `Activity/CheckUserRegist` | `SceneId`、`PhoneNo` | 仅读这两个字段，其余忽略 | 传 `ActivityId` 无效 |
| `Activity/GetHRflagActivityByIdNew` | `SceneId` | 支持 `ActivityId`、`IsShow`、`IsShow2` | 参数更宽 |
| `Activity/AddCustomerInfo` | 前端传 `IPAddress` | 服务端检测 IP 后**覆盖** | 前端传 IP 无意义 |
| `NewForm/AddCustomerInfoTwo` | 前端传 `IPAddress` / `IPAttac` | 服务端覆盖 `IPAttac`、`IPAddress` | 同上 |
| `FormOrder/AddFormOrderInfo` | 前端传 `IP`、`IPAddress` | 服务端覆盖 | 同上 |
| `Activity/GetPhoneIn` | `Phone` | `Request["Phone"].ToString()`，无判空 | 不传 `Phone` 直接 `NullReferenceException` |
| `Activity/AddCustomerInfo` | 无 `IfGoEmail` | 支持 `IfGoEmail`（默认 -1） | 可控制是否发邮件 |
| `Activity/GetActivityName` | — | 另有 `Activity/GetActivityName()` 与 `NewForm/GetActivityName(id)` 两套 | 前端用 `NewForm` 版本 |
| `Activity/GetOrderNo` | 前端用 `MicroLesson/GetOrderNo` | `Activity/GetOrderNo` 亦存在（`ActivityController.cs:1450`） | 两套订单号生成，注意一致性 |

### 5.3 命名与拼写（保持原样，勿"修正"）

| 名称 | 说明 |
|---|---|
| `AddustomerSoure` | Activity 与 NewForm 两个控制器各有一份，拼写均缺字 |
| `IPAttac` | `CustomerInfo` 属性名少一个 `h`，前端与后端一致 |
| `ScenceId` / `SceneId` / `ScenId` | 同一业务概念三种拼写，分布在源码与前端 |
| `GetVf` | `Form/GetVF` 的路由模板为小写 `f`，靠路由忽略大小写才能命中 |
| `CheckUserRegist` | `CheckUserOrder` 的 C# 方法名仍是 `CheckUserRegist` |

### 5.4 待确认

1. **`HRflag.ActivityWebApi` 是否仍在部署**：该工程内含同名 `ActivityController`（`AddCustomerInfo`、`GetCustomerNo`、`School*` 等），与 `HRflag.WebApi` 版本行为不同。若 `form.hrflag.com/WebAPI` 实际指向该工程，第 2 节的源码位置需整体切换，建议以站点 `bin` 目录下的程序集名称确认。
2. **`GetClientIpAddress()` 的实现**：位于 `ActivityController` 与 `NewFormController` 中的私有方法，取值依赖 `X-Forwarded-For` 或 `REMOTE_ADDR`；本次未展开，涉及风控与来源统计时需单独核对。
3. **`PayHelper.WxPayRecord` / `AliPayRecord`** 内部是否做了幂等（重复回调只记一次），需在 `DBConnection\Helper\PayHelper.cs` 中确认；当前仅确认控制器未做幂等判断。
