# 社区（Twitter）接口源码对照文档

| 项目 | 内容 |
|---|---|
| 对应接口文档 | `接口文档/02-社区（Twitter）接口文档.md` |
| 后端源码根目录 | `G:\HRflag\_backend_bms` |
| 涉及工程 | `HRflag.WxSp`（WxSpAPI）、`HRflag.WebApi`（WebAPI、WebAPIAliPlay） |
| 涉及模型 | `HRflag.WxModel\WxModel\ListOfPostsRequest.cs` 等 |
| 文档版本 | v1.0 |
| 更新日期 | 2026-11-17 |

---

## 1. 源码定位说明

### 1.1 路由机制

同人脉模块：ASP.NET Web API 2 特性路由，`[RoutePrefix]` + `[Route]` 两段拼接。

- `WebApiConfig.cs` 中仅 `config.MapHttpAttributeRoutes()` + 一条兜底路由，无自定义模型绑定器、无自定义 MediaTypeFormatter（详见 1.4）。
- `HRflag.WebApi` 额外注册了全局异常过滤器 `ApiHandleErrorAttribute` 与自定义 `JsonContentNegotiator`，因此**所有响应强制 JSON**。

### 1.2 控制器绝对路径

| 工程 | 控制器 | 绝对路径 |
|---|---|---|
| HRflag.WxSp | CommunityController | `G:\HRflag\_backend_bms\HRflag.WxSp\Controllers\CommunityController.cs` |
| HRflag.WxSp | DecryptionController | `G:\HRflag\_backend_bms\HRflag.WxSp\Controllers\DecryptionController.cs` |
| HRflag.WxSp | UserController（`UserInfo`） | `G:\HRflag\_backend_bms\HRflag.WxSp\Controllers\UserController.cs` |
| HRflag.WxSp | QuestionController | `G:\HRflag\_backend_bms\HRflag.WxSp\Controllers\QuestionController.cs` |
| HRflag.WebApi | NewFormController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\NewFormController.cs` |
| HRflag.WebApi | SystemController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\SystemController.cs` |
| HRflag.WebApi | FormController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\FormController.cs` |
| HRflag.WebApi | TwitterController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\TwitterController.cs` |
| HRflag.WebApi | NewsController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\NewsController.cs` |
| HRflag.WebApi | AdvertisingController | `G:\HRflag\_backend_bms\HRflag.WebApi\Controllers\AdvertisingController.cs` |

### 1.3 Helper 与业务层位置

| 类型 | 文件 | 服务接口 |
|---|---|---|
| `CommunityHelper` | `WxSpDBCon\DataHelper\CommunityHelper.cs` | `Community/*` 全部 |
| `Decryption` | `WxSpDBCon` 下 `Decryption` 类 | `Decryption/CreateWxActivity` |
| `UserHelper`（WxSp） | `WxSpDBCon\DataHelper\UserHelper.cs` | `UserInfo/InsertWxLoginId`、`SelectUserLoginInfo` |
| `UserActionHelper` | `WxSpDBCon\DataHelper\UserActionHelper.cs` | `UserInfo/SelUserAction` |
| `QusetionHelper` | `WxSpDBCon\DataHelper\QusetionHelper.cs` | `Question/AddTwitterViews` |
| `NewFormHelper` | `DBConnection\Helper\NewFormHelper.cs` | `NewForm/GetUser` |
| `LoginBLL` | `HRflag.BLL` | `System/checkIsRegister`、`DocShareLogin` |
| `formBll` | `HRflag.BLL` | `Form/GetVf` |
| `TwitterHelper` | `DBConnection\Helper\TwitterHelper.cs` | `Twitter/*` |
| `NewsHelper`（`nh`） | `DBConnection\Helper\NewsHelper.cs` | `News/GetHotNews` |
| `AdvertisementHelper`（`adshp`） | `DBConnection\Helper\AdvertisementHelper.cs` | `Advertising/*` |

### 1.4 关于 `[FromBody]` 与前端表单提交（重要）

`CommunityController` 的多个方法使用 `[FromBody] 复杂类型`，而前端 jQuery 默认以 `application/x-www-form-urlencoded` 提交。这能正常工作，依赖 **Web API 2 内置的 `JQueryMvcFormUrlEncodedFormatter`**（无需前端设置 `contentType: application/json`）：

| 接口 | 绑定方式 | 表单提交是否可用 |
|---|---|---|
| `Community/ListOfPosts` | `[FromBody] ListOfPostsRequest` | 可用（复杂类型，Formatter 按表单键值填充） |
| `Community/PostLikeOrUnLike` | `[FromBody] PostLikeOrUnLikeRequest` | 可用 |
| `Community/FollowOrUnfollow` | `[FromBody] FollowOrUnfollowRequest` | 可用 |
| `System/DocShareLogin` | `[FromBody] UserLoginInput` | 可用 |
| `Twitter/GetTwitterByid`、`AddTwitterView` | `[FromBody] TwitterQuery` | 可用 |
| **`Form/GetVF`** | `[FromBody] string` | **不可用**（裸字符串无法由表单键值填充） |
| **`System/checkIsRegister`** | `[FromBody] string` | **不可用** |

> 前端实际发送的是 `data: { "": phone }`，序列化后 body 为 `=13800000000`。`[FromBody] string` 期望 body 直接是字符串（如 `text/plain` 或 JSON 字符串），与空键名表单不匹配，参数极可能为 `null`。详见第 4 节。

---

## 2. 接口 ↔ 源码总览

| # | 接口 | 控制器.方法 | 源码位置 | 依赖 |
|---|---|---|---|---|
| 1 | `WxSpAPI/Decryption/CreateWxActivity` | DecryptionController.CreateWxActivity | `HRflag.WxSp\Controllers\DecryptionController.cs:173` | `Decryption.CreateWxPicture` |
| 2 | `WxSpAPI/UserInfo/InsertWxLoginId` | UserController.InsertWxLoginId | `HRflag.WxSp\Controllers\UserController.cs:1423` | `UserHelper.InsertWxLoginId` |
| 3 | `WxSpAPI/UserInfo/SelectUserLoginInfo` | UserController.SelectUserLoginInfo | `UserController.cs:1435` | `UserHelper.SelectUserLoginInfo` |
| 4 | `WebAPI/NewForm/GetUser` | NewFormController.GetUser | `HRflag.WebApi\Controllers\NewFormController.cs:585` | `NewFormHelper.GetUser` |
| 5 | `WebAPI/System/checkIsRegister` | SystemController.checkIsRegister | `HRflag.WebApi\Controllers\SystemController.cs:49` | `LoginBLL.checkIsRegister` |
| 6 | `WebAPI/Form/GetVF` | FormController.GetVF（路由 `GetVf`） | `HRflag.WebApi\Controllers\FormController.cs:30` | `formBll.SendVF` |
| 7 | `WebAPI/System/DocShareLogin` | SystemController.DocShareLogin | `SystemController.cs:35` | `LoginBLL.DocShareLogin` |
| 8 | `WxSpAPI/Community/ListOfPosts` | CommunityController.ListOfPosts | `HRflag.WxSp\Controllers\CommunityController.cs:68` | `CommunityHelper.ListOfPosts` |
| 9 | `WxSpAPI/Community/GetMainConmmentTable` | CommunityController.GetMainConmmentTable | `CommunityController.cs:265` | `CommunityHelper.GetMainConmmentTable` |
| 10 | `WxSpAPI/Community/PostCheckState` | CommunityController.PostCheckState | `CommunityController.cs:342` | `CommunityHelper.PostCheckState` |
| 11 | `WxSpAPI/Community/PostView` | CommunityController.PostView | `CommunityController.cs:152` | `CommunityHelper.PostView` |
| 12 | `WxSpAPI/Community/AddPostShortId` | CommunityController.AddPostShortId | `CommunityController.cs:376` | `CommunityHelper.AddPostShortId` |
| 13 | `WxSpAPI/Community/IsNotLoggedPostLike` | CommunityController.IsNotLoggedPostLike | `CommunityController.cs:421` | `CommunityHelper.IsNotLoggedPostLike` |
| 14 | `WxSpAPI/Community/PostLikeOrUnLike` | CommunityController.PostLikeOrUnLike | `CommunityController.cs:113` | `CommunityHelper.PostLikeOrUnLike` |
| 15 | `WxSpAPI/Community/FollowOrUnfollow` | CommunityController.FollowOrUnfollow | `CommunityController.cs:102` | `CommunityHelper.FollowOrUnfollow` |
| 16 | `WebAPI/Twitter/GetTwitterClass` | TwitterController.GetTwitterClass | `HRflag.WebApi\Controllers\TwitterController.cs:720` | `TwitterHelper.GetTwitterClass` |
| 17 | `WebAPI/Twitter/GetHrflagHighTwitter` | TwitterController.GetHrflagHighTwitter | `TwitterController.cs:771` | `TwitterHelper.GetHrflagHighTwitter` |
| 18 | `WebAPI/News/GetHotNews` | NewsController.GetHotNews | `HRflag.WebApi\Controllers\NewsController.cs:170` | `NewsHelper.GetHotNews` |
| 19 | `WebAPI/FileMgr/GetHighForceFileld` | FileMgrController.GetHighForceFileld | `HRflag.WebApi\Controllers\FileMgrController.cs:1081` | `FileHelper.GetHighForceFileld` |
| 20 | `WebAPI/Activity/GetHotActivityDetail` | ActivityController.GetHotActivityDetail | `HRflag.WebApi\Controllers\ActivityController.cs:3133` | `ActivityQueryHelper.GetHotActivityDetail` |
| 21 | `WebAPI/ActiveMeeting/GetinnerActivemeetingNew` | ActiveMeetingController.GetinnerActivemeetingNew | `HRflag.WebApi\Controllers\ActiveMeetingController.cs:138` | `ActiveMeetingHelper` |
| 22 | `WebAPI/ActiveMeeting/ActiveClickRecord` | ActiveMeetingController.ActiveClickRecord | `ActiveMeetingController.cs:152` | `ActiveMeetingHelper` |
| 23 | `WebAPIAliPlay/AliVideo/GetVideoByAliVid` | — | **本仓库未找到** | 见第 5 节 |
| 24 | `WebAPI/Twitter/GetHRflagTwitterInfo` | TwitterController.GetHRflagTwitterInfo | `TwitterController.cs:738` | `TwitterHelper.GetHRflagTwitterInfo` |
| 25 | `WebAPI/Twitter/GetTwitterByid` | TwitterController.GetTwitterByid | `TwitterController.cs:732` | `TwitterHelper.GetTwitterByid` |
| 26 | `WebAPI/Twitter/GetUserLike` | TwitterController.GetUserLike | `TwitterController.cs:871` | `TwitterHelper.GetUserLike` + `GetWXUserLike` |
| 27 | `WebAPI/Twitter/AddTwitterShare` | TwitterController.AddTwitterShare | `TwitterController.cs:787` | `TwitterHelper.AddTwitterShare` |
| 28 | `WebAPI/Twitter/GetUserShares` | TwitterController.GetUserShares | `TwitterController.cs:865` | `TwitterHelper.GetUserShares` |
| 29 | `WebAPI/Twitter/AddTwitterView` | TwitterController.AddTwitterView | `TwitterController.cs:760` | `TwitterHelper.AddTwitterView` |
| 30 | `WxSpAPI/Question/AddTwitterViews` | QuestionController.AddTwitterViews | `HRflag.WxSp\Controllers\QuestionController.cs:566` | `QusetionHelper.AddTwitterViews` |
| 31 | `WebAPI/Advertising/IGetTwitterAD` | AdvertisingController.IGetTwitterAD | `HRflag.WebApi\Controllers\AdvertisingController.cs:1392` | `AdvertisementHelper` |
| 32 | `WebAPI/Advertising/IGetTwitterADS` | AdvertisingController.IGetTwitterADS | `AdvertisingController.cs:1402` | `AdvertisementHelper` |
| 33 | `WebAPI/Advertising/IGetTwitterAdv` | AdvertisingController.IGetTwitterAdv | `AdvertisingController.cs:1811` | `AdvertisementHelper` |
| 34 | `WebAPI/Advertising/IAddTwitterADClickRecord` | AdvertisingController.IAddTwitterADClickRecord | `AdvertisingController.cs:1412` | `AdvertisementHelper` |
| 35 | `WebAPI/Advertising/IAddNewsDetailADClickRecord` | AdvertisingController.IAddNewsDetailADClickRecord | `AdvertisingController.cs:1135` | `AdvertisementHelper` |
| 36 | `WebAPI/Advertising/Advertising/IAddMeetingUPClickRecord` | AdvertisingController.IAddMeetingUPClickRecord | `AdvertisingController.cs:331` | 路径有问题，见第 4 节 |
| 37 | `WxSpAPI/Contacts/GetUserInfoByPhone` | ContactsController.GetUserInfoByPhone | `HRflag.WxSp\Controllers\ContactsController.cs:201` | `ContactsHelper` |
| 38 | `WxSpAPI/Contacts/GetConnectionInfo` | ContactsController.GetConnectionInfo | `ContactsController.cs:118` | `ContactsHelper` |
| 39 | `WxSpAPI/Contacts/AlikeConnections` | ContactsController.AlikeConnections | `ContactsController.cs:99` | `ContactsHelper` |
| 40 | `WxSpAPI/Apply/UserApplyMax` | ApplyController.UserApplyMax | `HRflag.WxSp\Controllers\ApplyController.cs:132` | `ApplyHelper` |
| 41 | `WxSpAPI/Apply/AddUserApply` | ApplyController.AddUserApply | `ApplyController.cs:22` | `ApplyHelper` |
| 42 | `WxSpAPI/Contacts/AddUserAction` | ContactsController.AddUserAction | `ContactsController.cs:530` | `UserActionHelper` |
| 43 | `WxSpAPI/UserInfo/SelUserAction` | UserController.SelUserAction | `HRflag.WxSp\Controllers\UserController.cs:1168` | `UserActionHelper` |

---

## 3. 源码摘录

### 3.1 登录与访客身份

**`Decryption/CreateWxActivity`** — `HRflag.WxSp\Controllers\DecryptionController.cs:173`

```csharp
[Route("CreateWxActivity"), HttpPost]
public IHttpActionResult CreateWxActivity()
{
    string StrDes = HttpContext.Current.Request["StrDes"];//要传参数
    string page = HttpContext.Current.Request["page"];//页面路径
    string width = HttpContext.Current.Request["width"];//图片宽高
    string picPath = HttpContext.Current.Request["picPath"];//保存位置
    return Ok(Decryption.Instanct.CreateWxPicture(StrDes, page, width, picPath));
}
```

**`UserInfo/InsertWxLoginId`** — `HRflag.WxSp\Controllers\UserController.cs:1423`

```csharp
[Route("InsertWxLoginId"), HttpPost]
public IHttpActionResult InsertWxLoginId()
{
    string HRId = HttpContext.Current.Request["HRId"];
    string Type = HttpContext.Current.Request["Type"];
    return Ok(UserHelper.Instanct.InsertWxLoginId(HRId, Type));
}
```

**`UserInfo/SelectUserLoginInfo`** — `UserController.cs:1435`

```csharp
[Route("SelectUserLoginInfo"), HttpPost]
public IHttpActionResult SelectUserLoginInfo()
{
    string HRId = HttpContext.Current.Request["HRId"];
    string Type = HttpContext.Current.Request["Type"];
    return Ok(UserHelper.Instanct.SelectUserLoginInfo(HRId, Type));
}
```

**`NewForm/GetUser`** — `HRflag.WebApi\Controllers\NewFormController.cs:585`

```csharp
[Route("GetUser"), HttpPost]
public IHttpActionResult GetUser(string phone)
{
    return Ok(NewFormHelper.Instanct.GetUser(phone));
}
```

**`System/checkIsRegister`** — `HRflag.WebApi\Controllers\SystemController.cs:49`

```csharp
[Route("checkIsRegister"), HttpPost]
public IHttpActionResult checkIsRegister([FromBody] string txtPhoneNum)
{
    int type = Convert.ToInt32(HttpContext.Current.Request["type"]);
    return Ok(LoginBLL.checkIsRegister(txtPhoneNum, type));
}
```

> 同一方法里既用 `[FromBody]` 取手机号、又用 `Request["type"]` 取表单值，两种取值方式混用；`Convert.ToInt32(null)` 会抛异常，`type` 必须传。

**`Form/GetVF`** — `HRflag.WebApi\Controllers\FormController.cs:30`

```csharp
[Route("GetVf"), HttpPost]          // 注意：路由写的是 GetVf（小写 f）
public IHttpActionResult GetVF([FromBody] string txtPhoneNum)
{
    formBll.SendVF(txtPhoneNum);
    return Ok();
}
```

**`System/DocShareLogin`** — `SystemController.cs:35`

```csharp
[Route("DocShareLogin"), HttpPost]
public IHttpActionResult DocShareLogin([FromBody] UserLoginInput input)
{
    return Ok(LoginBLL.DocShareLogin(input));
}
```

### 3.2 帖子列表与详情

**`Community/ListOfPosts`** — `HRflag.WxSp\Controllers\CommunityController.cs:68`

```csharp
[Route("ListOfPosts"), HttpPost]
public IHttpActionResult ListOfPosts([FromBody] ListOfPostsRequest request)
{
    return Ok(_dal.ListOfPosts(request));
}
```

请求模型 `HRflag.WxModel\WxModel\ListOfPostsRequest.cs`：

```csharp
public class ListOfPostsRequest
{
    public string Infographic { get; set; }   // 是否信息图 0/1
    public string Content { get; set; }       // 内容（搜索词）
    public string Phone { get; set; }         // 当前人手机号
    public int Page { get; set; }             // 第几页
    public int Limit { get; set; }            // 页大小
    public string Id { get; set; }            // 帖子Id（详情页排除当前帖）
    public int Type { get; set; }             // 1 推荐 2 人脉好友 3 我的关注
}
```

> 除文档中列出的 6 个参数外，模型还支持 `Infographic`（信息图筛选），前端未使用。

**`Community/GetMainConmmentTable`** — `CommunityController.cs:265`

```csharp
[Route("GetMainConmmentTable"), HttpPost]
public IHttpActionResult GetMainConmmentTable(Guid id, string phone, int page, int limit)
{
    return Ok(_dal.GetMainConmmentTable(id, phone, page, limit));
}
```

> `id` 为 **`Guid`** 类型，传入非 GUID 字符串会直接返回 400（模型绑定失败），这与前端 `guId.indexOf('-') == -1` 时跳首页的判断一致。

**`Community/PostCheckState`** — `CommunityController.cs:342`

```csharp
[Route("PostCheckState"), HttpPost]
public IHttpActionResult PostCheckState(string id)
{
    return Ok(_dal.PostCheckState(id));
}
```

**`Community/PostView`** — `CommunityController.cs:152`

```csharp
[Route("PostView"), HttpPost]
public IHttpActionResult PostView(string id, string phone, string openId)
{
    return Ok(_dal.PostView(id, phone, openId));
}
```

**`Community/AddPostShortId`** — `CommunityController.cs:376`

```csharp
[Route("AddPostShortId"), HttpPost]
public IHttpActionResult AddPostShortId(string postId)
{
    return Ok(_dal.AddPostShortId(postId));
}
```

**`Community/IsNotLoggedPostLike`** — `CommunityController.cs:421`

```csharp
[Route("IsNotLoggedPostLike"), HttpPost]
public IHttpActionResult IsNotLoggedPostLike(string postId, int type)
{
    return Ok(_dal.IsNotLoggedPostLike(postId, type));
}
```

**`Community/PostLikeOrUnLike`** — `CommunityController.cs:113`

```csharp
[Route("PostLikeOrUnLike"), HttpPost]
public IHttpActionResult PostLikeOrUnLike([FromBody] PostLikeOrUnLikeRequest request)
{
    return Ok(_dal.PostLikeOrUnLike(request));
}
```

**`Community/FollowOrUnfollow`** — `CommunityController.cs:102`

```csharp
[Route("FollowOrUnfollow"), HttpPost]
public IHttpActionResult FollowOrUnfollow([FromBody] FollowOrUnfollowRequest request)
{
    return Ok(_dal.FollowOrUnfollow(request));
}
```

> 文档中的 `FollowPhone`、`FollowingPhone`、`IpAddress`、`IPLocation` 四个字段必须与 `FollowOrUnfollowRequest` 的属性名**大小写完全一致**，否则 Formatter 填充不到。

### 3.3 分类与侧栏内容

**`Twitter/GetTwitterClass`** — `HRflag.WebApi\Controllers\TwitterController.cs:720`

```csharp
[Route("GetTwitterClass"), HttpPost]
public IHttpActionResult GetTwitterClass()
{
    return Ok(TwitterHelper.Instanct.GetTwitterClass());
}
```

**`Twitter/GetHrflagHighTwitter`** — `TwitterController.cs:771`

```csharp
[Route("GetHrflagHighTwitter"), HttpPost]
public IHttpActionResult GetHrflagHighTwitter()
{
    int limit = int.Parse(HttpContext.Current.Request["limit"]);
    return Ok(TwitterHelper.Instanct.GetHrflagHighTwitter(limit));
}
```

> **问题**：`limit` 无默认值且直接 `int.Parse`。前端 `GetNewestNews()` 调用时**未传任何参数**，`Request["limit"]` 为 `null`，`int.Parse(null)` 抛 `ArgumentNullException`，请求返回 500，侧栏"最新快讯"区域实际可能一直为空。详见第 4 节。

**`News/GetHotNews`** — `HRflag.WebApi\Controllers\NewsController.cs:170`

```csharp
[Route("GetHotNews"), HttpPost]
public IHttpActionResult GetHotNews(int count, string nId)
{
    //return Ok(newsBLL.GetHotNews(nId));
    return Ok(nh.GetHotNews(count,nId));
}
```

**`Activity/GetHotActivityDetail`**、**`FileMgr/GetHighForceFileld`**、**`ActiveMeeting/GetinnerActivemeetingNew`**、**`ActiveMeeting/ActiveClickRecord`** 的源码与人脉模块完全一致，见 `接口源码/01-人脉（Network）接口源码对照.md` 第 3.6 节，此处不重复。

### 3.4 帖子与快讯互动

**`Twitter/GetHRflagTwitterInfo`** — `TwitterController.cs:738`

```csharp
[Route("GetHRflagTwitterInfo"), HttpPost]
public IHttpActionResult GetHRflagTwitterInfo()
{
    string UserId = HttpContext.Current.Request["UserId"];
    int limit = int.Parse(HttpContext.Current.Request["limit"]);
    int page = int.Parse(HttpContext.Current.Request["page"]);
    string Type = HttpContext.Current.Request["Type"];
    string Sort = HttpContext.Current.Request["Sort"];
    string Content = HttpContext.Current.Request["Content"];
    return Ok(TwitterHelper.Instanct.GetHRflagTwitterInfo(UserId, limit, page, Type, Sort, Content));
}
```

> 支持 `Type`、`Sort`、`Content` 三个可选筛选；`limit`、`page` 必传且必须可转 int（前端传 0 可用）。

**`Twitter/GetTwitterByid`** — `TwitterController.cs:732`

```csharp
[Route("GetTwitterByid"), HttpPost]
public IHttpActionResult GetTwitterByid([FromBody] TwitterQuery query)
{
    string UserId = HttpContext.Current.Request["UserId"];
    return Ok(TwitterHelper.Instanct.GetTwitterByid(UserId, query));
}
```

**`Twitter/AddTwitterView`** — `TwitterController.cs:760`

```csharp
[Route("AddTwitterView"), HttpPost]
public IHttpActionResult AddTwitterView([FromBody] TwitterQuery query)
{
    return Ok(TwitterHelper.Instanct.AddTwitterView(query));
}
```

**`Twitter/GetUserLike`** — `TwitterController.cs:871`

```csharp
[Route("GetUserLike"), HttpPost]
public IHttpActionResult GetUserLike()
{
    string Guid = HttpContext.Current.Request["Guid"];
    return Ok(TwitterHelper.Instanct.GetUserLike(Guid) + TwitterHelper.Instanct.GetWXUserLike(Guid));
}
```

> 返回值为 `GetUserLike`（站内）与 `GetWXUserLike`（小程序，`TwitterHelper.cs:3229`）之和。

**`Twitter/AddTwitterShare`** — `TwitterController.cs:787`

```csharp
[Route("AddTwitterShare"), HttpPost]
public IHttpActionResult AddTwitterShare()
{
    string strGuid = HttpContext.Current.Request["Guid"];
    string strUserId = HttpContext.Current.Request["UserId"];
    return Ok(TwitterHelper.Instanct.AddTwitterShare(strGuid, strUserId));
}
```

**`Twitter/GetUserShares`** — `TwitterController.cs:865`

```csharp
[Route("GetUserShares"), HttpPost]
public IHttpActionResult GetUserShares()
{
    string Guid = HttpContext.Current.Request["Guid"];
    return Ok(TwitterHelper.Instanct.GetUserShares(Guid));
}
```

**`Question/AddTwitterViews`** — `HRflag.WxSp\Controllers\QuestionController.cs:566`

```csharp
[Route("AddTwitterViews"), HttpPost]
public IHttpActionResult AddTwitterViews()
{
    string PhoneNo = HttpContext.Current.Request["PhoneNo"];
    string OpenId = HttpContext.Current.Request["OpenId"];
    string TwitterId = HttpContext.Current.Request["TwitterId"];
    return Ok(QusetionHelper.Instanct.AddTwitterViews(TwitterId, PhoneNo, OpenId));
}
```

> 注意实参顺序为 `(TwitterId, PhoneNo, OpenId)`，与形参声明顺序不同，改代码时勿按声明顺序对照。

### 3.5 广告位

**`Advertising/IGetTwitterAD`** — `HRflag.WebApi\Controllers\AdvertisingController.cs:1392`

```csharp
[Route("IGetTwitterAD"), HttpPost]
public IHttpActionResult IGetTwitterAD()
{
    return Ok(adshp.IGetTwitterAD());
}
```

**`Advertising/IGetTwitterADS`** — `AdvertisingController.cs:1402`

```csharp
[Route("IGetTwitterADS"), HttpPost]
public IHttpActionResult IGetTwitterADS()
{
    return Ok(adshp.IGetTwitterADS());
}
```

**`Advertising/IGetTwitterAdv`** — `AdvertisingController.cs:1811`

```csharp
[Route("IGetTwitterAdv"), HttpPost]
public IHttpActionResult IGetTwitterAdv()
{
    return Ok(adshp.IGetTwitterAdv());
}
```

**`Advertising/IAddTwitterADClickRecord`** — `AdvertisingController.cs:1412`

```csharp
[Route("IAddTwitterADClickRecord"), HttpPost]
public IHttpActionResult IAddTwitterADClickRecord(int aDid, string userId = "")
{
    return Ok(adshp.IAddTwitterADClickRecord(aDid, userId));
}
```

> `userId` 有默认值 `""`，可省略；`aDid` 为 `int`，必须可转数字。

**`Advertising/IAddNewsDetailADClickRecord`** — `AdvertisingController.cs:1135`

```csharp
[Route("IAddNewsDetailADClickRecord"), HttpPost]
public IHttpActionResult IAddNewsDetailADClickRecord(string userId, int aDid)
{
    return Ok(adshp.IAddNewsDetailADClickRecord(userId, aDid));
}
```

### 3.6 人脉能力复用

> 以下接口源码与人脉模块一致，仅列位置，代码见 `接口源码/01-人脉（Network）接口源码对照.md`。

| 接口 | 源码位置 |
|---|---|
| `Contacts/GetUserInfoByPhone` | `HRflag.WxSp\Controllers\ContactsController.cs:201` |
| `Contacts/GetConnectionInfo` | `ContactsController.cs:118` |
| `Contacts/AlikeConnections` | `ContactsController.cs:99` |
| `Apply/UserApplyMax` | `HRflag.WxSp\Controllers\ApplyController.cs:132` |
| `Apply/AddUserApply` | `ApplyController.cs:22` |
| `Contacts/AddUserAction` | `ContactsController.cs:530` |
| `UserInfo/SelUserAction` | `HRflag.WxSp\Controllers\UserController.cs:1168` |

**`UserInfo/SelUserAction`** 参数解析：

```csharp
[Route("SelUserAction"), HttpPost]
public IHttpActionResult SelUserAction()
{
    string OpenId = HttpContext.Current.Request["OpenId"];
    int KindId = Convert.ToInt32(HttpContext.Current.Request["KindId"]);
    int ContentId = Convert.ToInt32(HttpContext.Current.Request["ContentId"]);
    string Remarks = HttpContext.Current.Request["Remarks"];
    return Ok(UserActionHelper.Instanct.SelUserAction(OpenId, KindId, ContentId, Remarks));
}
```

---

## 4. 源码与接口文档的差异 / 源码缺陷

| # | 接口 | 现象 | 源码依据 | 影响与建议 |
|---|---|---|---|---|
| 1 | `Twitter/GetHrflagHighTwitter` | 前端不传参，后端 `int.Parse(Request["limit"])` | `TwitterController.cs:771-775` | `limit` 为 `null` → `ArgumentNullException` → 500，侧栏"最新快讯"取不到数据。建议后端改为 `int limit = 10; int.TryParse(Request["limit"], out limit);` |
| 2 | `Form/GetVF` | 路由名与实际请求不一致（`GetVf` vs `GetVF`） | `FormController.cs:30` | Web API 路由匹配**忽略大小写**，当前可访问；但若后续启用严格匹配或迁移路由将失效，建议统一为 `GetVF` |
| 3 | `Form/GetVF` | `[FromBody] string` + 前端空键名表单 | `FormController.cs:31` | 参数极可能为 `null`，短信验证码无法发送。建议改为 `Request["PhoneNumber"]` 或 `[FromBody] PhoneInput` |
| 4 | `System/checkIsRegister` | 同上；且 `Convert.ToInt32(Request["type"])` 未容错 | `SystemController.cs:49-52` → `LoginDAL.cs:246` | 若手机号绑定为 `null`，DAL 中 `PhoneNumber.Contains(null)` 查不到任何记录 → 恒返回 `false` → 前端提示"该手机号暂无注册"，短信登录被卡死；不传 `type` 还会抛异常 |
| 5 | `Community/GetMainConmmentTable` | `id` 为 `Guid` | `CommunityController.cs:265` | 非 GUID 直接 400，前端需保证 `guid` 来自 `ListOfPosts` 返回的 `Id` |
| 6 | `Community/ListOfPosts` | 模型含 `Infographic` 字段 | `ListOfPostsRequest.cs:17` | 文档未列出，可按 0/1 过滤信息图帖子 |
| 7 | `Twitter/GetHRflagTwitterInfo` | `limit`/`page` 强制 `int.Parse` | `TwitterController.cs:742-743` | 不传即 500，前端必须传（当前传 0） |
| 8 | `Advertising/Advertising/IAddMeetingUPClickRecord` | 前端多一段 `Advertising` | `AdvertisingController.cs:330` | 后端仅 `Advertising/IAddMeetingUPClickRecord`，详见人脉文档第 5 节 |
| 9 | `WebAPIAliPlay/AliVideo/GetVideoByAliVid` | 源码不在本仓库 | 全库检索无 `GetVideoByAliVid` | 该接口部署在独立项目（`WebAPIAliPlay`），需另找仓库；前端取 `CoverURL` 的逻辑无法在本仓库验证 |

---

## 5. 待补源码

1. **`WebAPIAliPlay/AliVideo/GetVideoByAliVid`**：`G:\HRflag\_backend_bms` 全量检索（含 `bin`、`obj` 排除）无此方法，`HRflag.WebApi`、`HRflag.ActivityWebApi`、`HRflag.WxSp` 三个 Web 项目均无 `AliVideoController`。该接口应由独立部署的 `WebAPIAliPlay` 站点提供，建议补充该仓库路径后再补文档。
2. **`Community` 的小程序端接口**（`PostDetails`、`AddMainComment`、`PublishPost` 等）已存在于 `CommunityController`，但 PC 端未使用，本模块文档未覆盖；若需小程序联调，可按同一模式补充。
