# 公司动态（Dynamics）模块接口文档

| 项目 | 内容 |
|---|---|
| 模块名称 | 公司动态（Dynamics） |
| 前端站点 | https://dynamics.hrflag.com/ |
| 源码目录 | `G:\G-HRflag\Dynamics` |
| 接口域名 | `https://form.hrflag.com/WebAPI/` |
| 文档版本 | v1.0 |
| 更新日期 | 2026-11-17 |
| 适用对象 | 前端开发、后端开发、联调测试 |

---

## 1. 模块概述

公司动态模块以列表形式展示 HRflag 发布的公司动态类资讯（企业动态、人事任命、业务发布等），支持按标题检索、按栏目过滤、分页浏览，点击条目跳转至新闻详情页。

### 1.1 页面与接口映射

| 页面 | 路由 | 主要功能 | 主要接口 |
|---|---|---|---|
| 公司动态列表 | `/Dynamics/Dynamics` | 动态列表、分页、标题检索 | 3.1 |
| 新闻详情 | `http://news.hrflag.com/News/newsdetail?nid={NId}` | 正文页（属新闻模块） | 本模块不调用 |
| 页面公共框架 | `Views/Shared/_Layout.cshtml` | 合作方 Logo 墙、顶部广告、登录头像 | 3.2、3.3、3.4、3.5 |

### 1.2 接口清单速览

| 序号 | 接口 | 方法 | 路径 | 用途 | 触发时机 |
|---|---|---|---|---|---|
| 1 | 栏目资讯列表 | POST | `WebAPI/News/GetIssueNews` | 公司动态列表数据 | 页面加载、翻页、搜索 |
| 2 | 合作方 Logo 墙 | POST | `WebAPI/Advertising/HomeADUP` | 顶部合作方入口 | 页面加载 |
| 3 | 顶部通栏广告 | POST | `WebAPI/Advertising/IGetTopAD` | 顶部广告图 | 页面加载 |
| 4 | 顶部广告点击埋点 | POST | `WebAPI/Advertising/IAddTopADClickRecord` | 广告点击统计 | 点击广告图 |
| 5 | 登录用户头像 | POST | `WebAPI/UserInfo/GetUserById` | 顶部用户头像 | 已登录时页面加载 |

---

## 2. 通用约定

### 2.1 环境与基础地址

| 环境 | WebAPI |
|---|---|
| 生产 | `https://form.hrflag.com/WebAPI/` |
| 测试 | `http://demo.hrflag.com/WebAPI/` |

> 前端常量见 `Scripts/Common/js/config.js`：`APIPath`、`NewsPath`（`http://news.hrflag.com/News/`）、`FilePath`（`https://hrflagfile.oss-cn-hangzhou.aliyuncs.com/`）。

### 2.2 请求规范

- 全部为 **POST**；`GetIssueNews` 的参数通过 **QueryString** 传递（前端直接字符串拼接）。
- 参数编码：`application/x-www-form-urlencoded; charset=UTF-8`；中文参数需 `encodeURI`。
- 响应：`application/json; charset=utf-8`，无统一 `code`/`msg` 包裹。

### 2.3 分页与时间展示约定

| 项 | 约定 |
|---|---|
| `page` | 页码，从 1 开始 |
| `limit` | 每页条数，本模块固定 15 |
| 总页数 | `Math.ceil(count / limit)` |
| 时间展示 | 距当前 < 7 天显示相对时间（`x天前`/`x小时前`/`x分钟前`/`x秒前`），≥ 7 天显示 `yyyy/MM/dd HH:mm:ss` |
| 浏览量 | 千分位格式化，如 `12,345` |

### 2.4 图片地址约定

| 场景 | 规则 |
|---|---|
| 列表封面 `SmallImage` | `FilePath + SmallImage`；为空时使用默认图 `FilePath + "news.jpg"` |
| 广告图 `ImagePath` | `FilePath + ImagePath` |
| 用户头像 | `Image` 优先；否则 `FilePath + UserPhotoUrl`；再否则默认头像 |

---

## 3. 接口明细

### 3.1 栏目资讯列表（公司动态）

- **用途**：按栏目与标题关键词分页获取资讯列表；本模块固定 `typename=公司动态`，同一接口也供新闻资讯等其他栏目复用。
- **请求**：`POST https://form.hrflag.com/WebAPI/News/GetIssueNews?title={title}&typename={typename}&page={page}&limit={limit}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| title | string | 否 | 标题关键词，需 `encodeURI`；空串表示不筛选 |
| typename | string | 是 | 栏目名称，本模块固定 `公司动态` |
| page | int | 是 | 页码，从 1 开始 |
| limit | int | 是 | 每页条数，本模块固定 15 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| count | int | 总条数，用于计算总页数 |
| data | array | 资讯列表 |
| data[].NId | string | 资讯主键，用于拼接详情页地址 |
| data[].Title | string | 标题 |
| data[].SmallImage | string | 封面缩略图相对路径，可为 `null` 或空串 |
| data[].PubName | string | 发布方名称，用于详情页 `msg` 参数与 SEO |
| data[].CreateTime | string | 发布时间，格式 `yyyy-MM-dd HH:mm:ss` |
| data[].PageView | int | 浏览量 |

**请求示例**

```
POST https://form.hrflag.com/WebAPI/News/GetIssueNews?title=&typename=%E5%85%AC%E5%8F%B8%E5%8A%A8%E6%80%81&page=1&limit=15
```

**响应示例**

```json
{
  "count": 128,
  "data": [
    {
      "NId": "n20261116001",
      "Title": "某集团宣布完成 10 亿元 B 轮融资",
      "SmallImage": "UploadImage/News/cover_20261116.jpg",
      "PubName": "HRflag",
      "CreateTime": "2026-11-16 09:30:00",
      "PageView": 12345
    },
    {
      "NId": "n20261115002",
      "Title": "某公司任命新任首席人力资源官",
      "SmallImage": null,
      "PubName": "HRflag",
      "CreateTime": "2026-11-15 17:02:11",
      "PageView": 8021
    }
  ]
}
```

**前端处理要点**

- `data` 为空时列表区显示空态，分页组件隐藏（`pagecount == 0`）。
- 详情链接格式：`NewsPath + "newsdetail?nid=" + NId + "&msg=" + Title + "-" + PubName + "_HRflag"`，`msg` 需做 URL 编码。
- 封面为空时必须回退 `news.jpg`，否则会出现破图。

- **调用位置**：`Scripts/dynamics/js/action.js:13`

---

### 3.2 合作方 Logo 墙

- **用途**：顶部合作方/媒体入口，按 `SeqNo` 升序渲染，仅展示 `State=1`。
- **请求**：`POST https://form.hrflag.com/WebAPI/Advertising/HomeADUP`

**请求参数**：无。

**响应字段**（数组）

| 字段名 | 类型 | 说明 |
|---|---|---|
| Name | string | 合作方名称 |
| ImagePath | string | Logo 相对路径，需拼 `FilePath` |
| InterLinkage | string | 点击跳转链接 |
| State | int | 1 展示 / 其他不展示 |
| SeqNo | int | 排序号，升序 |

**响应示例**

```json
[
  {
    "Name": "某人力资源协会",
    "ImagePath": "UploadImage/Logo/partner1.png",
    "InterLinkage": "https://example.com",
    "State": 1,
    "SeqNo": 1
  }
]
```

- **调用位置**：`Views/Shared/_Layout.cshtml:505`

---

### 3.3 顶部通栏广告

- **用途**：页面顶部通栏广告。
- **请求**：`POST https://form.hrflag.com/WebAPI/Advertising/IGetTopAD?userId={UserId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| userId | string | 否 | 主站用户 ID（Cookie `UserId`），未登录为空串 |

**响应字段**（单对象，无广告时为 `null`）

| 字段名 | 类型 | 说明 |
|---|---|---|
| Id | string | 广告 ID，点击埋点使用 |
| ImagePath | string | 广告图相对路径 |
| Interlinkage | string | 跳转链接 |

**响应示例**

```json
{
  "Id": "ad900",
  "ImagePath": "UploadImage/ActivityImg/top_banner.png",
  "Interlinkage": "https://hrflag.com/"
}
```

> 当前 `hpublic.js` 未对 `null` 做判空，联调时建议补 `if (!data) return;`。

- **调用位置**：`Scripts/Common/js/hpublic.js:64`

---

### 3.4 顶部广告点击埋点

- **用途**：顶部通栏广告点击上报。
- **请求**：`POST https://form.hrflag.com/WebAPI/Advertising/IAddTopADClickRecord?userId={UserId}&aDid={AdId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| userId | string | 否 | 主站用户 ID |
| aDid | string | 是 | 广告 ID |

**响应字段**：无业务数据。

**响应示例**

```json
null
```

- **调用位置**：`Scripts/Common/js/hpublic.js:77`

---

### 3.5 登录用户头像

- **用途**：已登录时获取用户头像。
- **请求**：`POST https://form.hrflag.com/WebAPI/UserInfo/GetUserById?strUserId={UserId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| strUserId | string | 是 | 主站用户 ID（Cookie `UserId`） |

**响应字段**（数组）

| 字段名 | 类型 | 说明 |
|---|---|---|
| Image | string | 头像完整 URL，优先使用 |
| UserPhotoUrl | string | 头像相对路径，`Image` 为空时拼 `FilePath` |

**响应示例**

```json
[
  {
    "Image": "https://hrflagfile.oss-cn-hangzhou.aliyuncs.com/uploadimage/atdportrait/avatar_20240518.jpg",
    "UserPhotoUrl": "uploadimage/atdportrait/avatar_20240518.jpg"
  }
]
```

- **调用位置**：`Scripts/Common/js/cookies.js:41`

---

## 4. 附录

### 4.1 接口总览

| 序号 | 接口 | 方法 | 路径 | 用途 |
|---|---|---|---|---|
| 1 | 栏目资讯列表 | POST | `WebAPI/News/GetIssueNews` | 公司动态列表 |
| 2 | 合作方 Logo 墙 | POST | `WebAPI/Advertising/HomeADUP` | 公共布局 |
| 3 | 顶部通栏广告 | POST | `WebAPI/Advertising/IGetTopAD` | 公共布局 |
| 4 | 顶部广告点击 | POST | `WebAPI/Advertising/IAddTopADClickRecord` | 埋点 |
| 5 | 登录用户头像 | POST | `WebAPI/UserInfo/GetUserById` | 公共布局 |

### 4.2 联调注意事项

1. **占位参数不可省**：`GetIssueNews` 即使不搜索也需传 `title=`（空串），后端按参数存在与否分支，缺参可能导致 400。
2. **中文编码**：`title`、`typename` 必须 `encodeURI`，否则中文栏目名（`公司动态`）会乱码导致查询为空。
3. **`count` 语义**：为总条数而非总页数，前端需自行 `Math.ceil(count / limit)`。
4. **详情跳转跨域**：详情页在 `news.hrflag.com`，与本模块不同域；`msg` 参数用于 SEO 标题，需保留 `-{PubName}_HRflag` 后缀格式。
5. **封面兜底**：`SmallImage` 为 `null` 或 `""` 时统一使用 `news.jpg`。
6. **时间字段**：`CreateTime` 为 `yyyy-MM-dd HH:mm:ss`，前端 `new Date(time.replace(/-/g,"/"))` 兼容 Safari。
7. **分页组件**：移动端（≤768px）显示简化分页（无跳页），桌面端显示跳页；两端共用同一数据源，页码变更后重新请求 3.1。
8. **HTTP/HTTPS 混用**：`NewsPath` 配置为 `http://`，页面为 `https://`，跳转时可能触发混合内容警告，建议统一为 `https`。
