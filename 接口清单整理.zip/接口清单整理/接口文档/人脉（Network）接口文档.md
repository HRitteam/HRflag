# 人脉（Network）模块接口文档

| 项目 | 内容 |
|---|---|
| 模块名称 | 人脉（Network） |
| 前端站点 | https://network.hrflag.com/ |
| 源码目录 | `G:\G-HRflag\Network` |
| 接口域名 | `https://form.hrflag.com/WxSpAPI/`（用户/关系/申请）、`https://form.hrflag.com/WebAPI/`（内容/广告） |
| 文档版本 | v1.0 |
| 更新日期 | 2026-11-17 |
| 适用对象 | 前端开发、后端开发、联调测试 |

---

## 1. 模块概述

人脉模块提供 HRflag 用户的实名名片、人脉关系（同行 / 同城 / 二度人脉）、好友申请、访客记录、收藏与点赞、个人主页展示等能力，并在页面侧栏聚合会议活动、快讯、研究报告与广告位。

### 1.1 页面与接口映射

| 页面 | 路由 | 主要功能 | 主要接口分组 |
|---|---|---|---|
| 人脉首页 | `/Network/Network` | 名片、好友申请数、人脉推荐、快讯、热门活动 | 3.1、3.2、3.3、3.6、3.7、3.8 |
| 好友申请 | `/Network/Apply` | 收到的申请、已发送的申请、同意/忽略 | 3.3、3.4、3.5 |
| 我的好友 | `/Network/Connections` | 好友列表、好友搜索、推荐人脉 | 3.2、3.3、3.5 |
| 搜索人脉 | `/Network/Search?keywords=` | 全站人脉搜索、结果计数 | 3.2、3.3、3.5 |
| 陌生人主页 | `/Network/User?OpenIdPass=` | 名片、介绍、产品服务、视频、点赞、浏览埋点 | 3.1、3.2、3.4、3.5、3.8 |
| 好友主页 | `/Network/Friend?OpenIdPass=` | 名片、共同好友、介绍、点赞 | 3.1、3.2、3.4、3.5、3.8 |
| 谁看过我 | `/Network/Browse` | 访客列表与统计 | 3.4、3.3 |
| 我的收藏 | `/Network/Collection` | 收藏列表与统计 | 3.4、3.3 |
| 谁点赞我 | `/Network/Like` | 点赞列表与统计 | 3.4、3.3 |

---

## 2. 通用约定

### 2.1 环境与基础地址

| 环境 | WxSpAPI | WebAPI |
|---|---|---|
| 生产 | `https://form.hrflag.com/WxSpAPI/` | `https://form.hrflag.com/WebAPI/` |
| 测试 | `http://demo.hrflag.com/WxSpAPI/` | `http://demo.hrflag.com/WebAPI/` |

> 前端常量定义见 `Scripts/Common/js/config.js`：`WXAPIPath`、`APIPath`、`FilePath`。

### 2.2 请求规范

- 除特别标注外，所有接口均为 **POST**。
- 请求体编码：`application/x-www-form-urlencoded; charset=UTF-8`（jQuery `$.ajax` 默认 `data` 对象序列化方式）。
- 少量接口的入参通过 **QueryString** 传递，文档中已在路径内标明。
- 响应体编码：`application/json; charset=utf-8`。
- 所有查询类接口无需鉴权头，身份通过参数 `OpenId` / `Phone` 传递。

### 2.3 身份与登录态

| 标识 | 来源 | 说明 |
|---|---|---|
| `PhoneNumber` | Cookie | 当前登录用户手机号，未登录为空 |
| `UserId` | Cookie | 主站用户 ID（GUID），用于广告点击、活动点击统计，可为空 |
| `OpenId` | 接口 `Contacts/GetUserInfoByPhone` 换取 | 人脉模块内所有用户主键；为空表示未注册/未登录 |

换取流程：`Cookie(PhoneNumber)` → `Contacts/GetUserInfoByPhone` → `OpenId` → 后续接口。

### 2.4 响应结构约定

本模块接口来自两套后端服务，响应结构存在三种形态，联调时需按接口分别处理：

| 形态 | 说明 | 涉及接口 |
|---|---|---|
| 裸数组 | 直接返回 JSON 数组，空结果为 `[]` | 大部分列表接口 |
| `{ "data": [...] }` | 分页列表包裹在 `data` 字段内 | `UserInfo/GetLookUser`、`GetUserLook`、`GetCollectUser`、`GetUserCollect`、`GetlikeUser`、`GetUserlike` |
| 标量 / 对象 | 直接返回数字、布尔或单对象 | `Apply/UserApplyMax`、`Apply/AddUserApply`、`Contacts/GetContactsLowerCount`、`Contacts/AddUserAction(s)` |

- 无统一 `code`/`msg` 外层包裹，业务失败多以空数组、`0`、`false` 表示。
- 列表为空时前端统一展示"暂无××"空态。

### 2.5 分页约定

| 参数 | 说明 |
|---|---|
| `page` | 页码，从 1 开始 |
| `limit` / `limite` | 每页条数；注意两个拼写在不同接口中不统一，按接口文档传参 |

判断"是否还有下一页"的统一做法：返回条数 `< limit` 即视为最后一页。

### 2.6 资源地址拼接

| 字段类型 | 拼接规则 |
|---|---|
| 图片（`Image`、`ImagePath`、`ImageUrl`、`SmallImage`、`SpeakerImage`、`ActivityLogo`） | `FilePath + 相对路径`，`FilePath = https://hrflagfile.oss-cn-hangzhou.aliyuncs.com/` |
| 部分头像字段 | 可能已是完整 URL（如 `https://static.hrflag.com/...`） |
| 空头像 | 返回 `../../files/imgs/tou.png` 或 `null`，前端替换为 `https://static.hrflag.com/img/newflag/newimgs/userpic.png` |

### 2.7 枚举值

| 枚举 | 取值 | 含义 |
|---|---|---|
| `ClassType`（人脉分类） | 0 / 1 / 2 / 3 | 全部推荐 / 同行 / 同城 / 二度人脉 |
| `IsTake`（申请状态） | 0 / 1 / 2 | 未处理 / 已同意 / 已忽略 |
| `IsFriend` | 0 / 1 | 非好友 / 好友 |
| `IsgoSend` | 0 / 1 | 未发送过好友申请 / 已发送待通过 |
| `KindId` / `ContentId`（行为类型） | 1 / 11 | 加好友行为 |
| `KindId` / `ContentId`（行为类型） | 1 / 9 | 点赞行为 |
| `KindId` / `ContentId`（行为类型） | 1 / 2 | 访问主页行为 |
| `UserType`（记录维度） | 0 / 1 | 谁看过我（默认） / 我发出的浏览 |
| `Type`（记录类型） | 0 / 1 / 2 | 浏览 / 点赞 / 收藏 |

---

## 3. 接口明细

### 3.1 账号与名片

#### 3.1.1 手机号换取 OpenId

- **用途**：以登录手机号换取人脉体系用户主键 `OpenId`，是所有后续接口的前置调用。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Contacts/GetUserInfoByPhone`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| Phone | string | 是 | 用户手机号，11 位；未登录时传空字符串 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| OpenId | string | 用户主键；`null` 表示该手机号未注册 |
| IsDelete | int | 1 表示账号已注销/删除，前端按未登录处理 |

**响应示例**

```json
{
  "OpenId": "old0446IdtHqVBWd2V3P7qm1b08w",
  "IsDelete": 0
}
```

- **调用位置**：`network.js:407`、`user.js:62`、`friend.js:48`、`apply.js:44`、`browse.js:41`、`collection.js:41`、`like.js:41`、`search.js:41`、`connections.js:39`

---

#### 3.1.2 获取用户名片

- **用途**：按 `OpenId` 获取用户名片信息，用于陌生人主页、好友主页。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Contacts/GetUserInfoByid`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OpenId | string | 是 | 被访问用户的主键（页面参数 `OpenIdPass`） |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| Name | string | 姓名 |
| Image | string | 头像相对路径或完整 URL |
| Company | string | 公司名称 |
| Position | string | 职位 |
| Place | string | 所在城市 |
| PhoneNo | string | 联系电话 |
| Email | string | 邮箱 |
| CompanyLogo | string | 公司 Logo 地址，可为 `null` |

**响应示例**

```json
{
  "Name": "王睿",
  "Image": "uploadimage/atdportrait/avatar_20240518103012.jpg",
  "Company": "众旗人力资源（上海）有限公司",
  "Position": "HRD",
  "Place": "上海",
  "PhoneNo": "13800000000",
  "Email": "example@hrflag.com",
  "CompanyLogo": "uploadimage/company/logo_20240101.png"
}
```

- **调用位置**：`user.js:159`、`friend.js:146`

---

#### 3.1.3 获取浏览/点赞统计

- **用途**：获取某用户的被浏览次数与点赞次数，用于主页右上角统计。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/UserInfo/GetRecordCount`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OpenId | string | 是 | 被统计用户的主键 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| LookCount | int | 被浏览次数 |
| LikeCount | int | 被点赞次数 |

**响应示例**

```json
{
  "LookCount": 128,
  "LikeCount": 35
}
```

- **调用位置**：`friend.js:91`、`user.js:105`、`network.js:1075`

---

#### 3.1.4 获取个人介绍

- **用途**：读取用户个人介绍富文本块，按顺序渲染段落、图片、视频。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/UserInfo/GetHRUserSelfIntroduction`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OpenId | string | 是 | 用户主键，可用 QueryString 或表单传递 |

**响应字段**（数组，按返回顺序渲染）

| 字段名 | 类型 | 说明 |
|---|---|---|
| Typecontent | string | 块类型：`p` 段落 / `imgs` 图片 / `video` 视频 |
| Comcontent | string | 文本内容（`p` 段落正文、`video` 标题） |
| Src | string | 图片或视频地址（`imgs`/`video` 时有值） |

**响应示例**

```json
[
  { "Typecontent": "p", "Comcontent": "拥有 15 年人力资源全模块管理经验。", "Src": null },
  { "Typecontent": "imgs", "Comcontent": null, "Src": "https://hrflagfile.oss-cn-hangzhou.aliyuncs.com/intro/1.jpg" }
]
```

- **调用位置**：`user.js:408`、`friend.js:317`

---

#### 3.1.5 获取公司介绍

- **用途**：读取用户所属公司的介绍内容块。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/UserInfo/GetHRUserComIntroduction`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OpenId | string | 是 | 用户主键 |

**响应字段**：同 3.1.4（`Typecontent` / `Comcontent` / `Src`）。

**响应示例**

```json
[
  { "Typecontent": "p", "Comcontent": "众旗人力资源，专注人力资源服务。", "Src": null }
]
```

- **调用位置**：`user.js:434`、`friend.js:343`

---

#### 3.1.6 获取业务介绍 / 产品服务

- **用途**：读取用户填写的业务介绍、产品服务详情。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/UserInfo/GetHRUserProfessionalWork`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OpenId | string | 是 | 用户主键 |

**响应字段**：同 3.1.4（`Typecontent` / `Comcontent` / `Src`）。

**响应示例**

```json
[
  { "Typecontent": "p", "Comcontent": "提供组织诊断、薪酬绩效体系搭建服务。", "Src": null },
  { "Typecontent": "video", "Comcontent": "服务介绍", "Src": "https://hrflagfile.oss-cn-hangzhou.aliyuncs.com/video/1.mp4" }
]
```

- **调用位置**：`user.js:460`、`friend.js:369`

---

#### 3.1.7 获取个人视频

- **用途**：读取用户上传的公司/个人视频列表。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/UserInfo/CompanyBusinessPersonalVideo`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OpenId | string | 是 | 用户主键 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| Comcontent | string | 视频标题 |
| Src | string | 视频播放地址 |

**响应示例**

```json
[
  {
    "Comcontent": "企业宣传片",
    "Src": "https://hrflagfile.oss-cn-hangzhou.aliyuncs.com/video/company.mp4"
  }
]
```

- **调用位置**：`user.js:486`、`friend.js:395`

---

### 3.2 人脉关系与推荐

#### 3.2.1 获取好友列表

- **用途**：获取指定用户的全部好友；同时用于"好友数"统计与好友搜索。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Contacts/GetContacts`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OpenId | string | 是 | 查询目标用户主键 |
| Query | string | 否 | 好友内搜索关键词（姓名/公司/职位），不传或空串表示全部 |
| sortType | string | 否 | 排序方式，取自页面下拉框 `#sort` 的值；不传为默认排序 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| OpenId | string | 好友主键 |
| Name | string | 姓名 |
| Image | string | 头像 |
| Company | string | 公司 |
| Department | string | 部门 |
| Position | string | 职位 |
| CreateTimeT | string | 建立好友关系时间（已格式化，可直接展示） |

**响应示例**

```json
[
  {
    "OpenId": "old0445lxZUTwAK6hNzkxsR0murI",
    "Name": "李昂",
    "Image": "uploadimage/atdportrait/avatar_20240102.jpg",
    "Company": "众旗人力资源（上海）有限公司",
    "Department": "人力资源部",
    "Position": "招聘经理",
    "CreateTimeT": "2026-03-12 10:22"
  }
]
```

- **调用位置**：`connections.js:67`、`connections.js:118`、`friend.js:182`、`user.js:204`、`network.js:1060`

---

#### 3.2.2 全站人脉搜索

- **用途**：按关键词搜索平台内的人脉，支持分页。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Contacts/GetConnections`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OpenId | string | 是 | 当前登录用户主键 |
| Query | string | 是 | 搜索关键词，来自页面参数 `keywords` |
| classType | int | 否 | 人脉分类，固定传 0（全部） |
| page | int | 是 | 页码，从 1 开始 |
| Limite | int | 是 | 每页条数，前端固定 15 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| OpenId | string | 用户主键 |
| Name | string | 姓名 |
| Image | string | 头像 |
| Company | string | 公司 |
| Position | string | 职位 |
| PhoneNo | string | 电话（用于发起好友申请时携带） |
| RowNumber | int | 结果序号 |

**响应示例**

```json
[
  {
    "OpenId": "old0442abc1234567890",
    "Name": "张倩",
    "Image": "uploadimage/atdportrait/avatar_20240308.jpg",
    "Company": "某科技集团",
    "Position": "HRBP",
    "PhoneNo": "13900000001",
    "RowNumber": 1
  }
]
```

- **调用位置**：`search.js:64`

---

#### 3.2.3 搜索结果计数

- **用途**：获取人脉搜索命中总数，用于结果区标题展示。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Contacts/GetConnectionsCount`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OpenId | string | 是 | 当前登录用户主键 |
| Query | string | 是 | 搜索关键词 |
| sortType | int | 否 | 排序方式，固定传 0 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| RowNumber | int | 命中总条数 |

**响应示例**

```json
[{ "RowNumber": 128 }]
```

- **调用位置**：`search.js:108`

---

#### 3.2.4 人脉推荐（同行 / 同城 / 二度 / 全部）

- **用途**：按分类推荐人脉，人脉首页与搜索页的"猜你认识"均使用此接口。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Contacts/GetConnectionInfo`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| Phone | string | 是 | 当前登录用户手机号 |
| ClassType | int | 是 | 0 全部推荐 / 1 同行 / 2 同城 / 3 二度人脉 |
| limit | int | 是 | 每页条数；首页固定 8，猜你认识固定 5 |
| page | int | 是 | 页码，从 1 开始 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| OpenId | string | 用户主键 |
| Name | string | 姓名 |
| Image | string | 头像 |
| Company | string | 公司 |
| Position | string | 职位 |
| PhoneNo | string | 电话 |
| IsgoSend | int | 0 未申请 / 1 已申请待通过 |
| RowNumber | int | 序号，前端用作 DOM 标识 |

**响应示例**

```json
[
  {
    "OpenId": "old0449xyz987654321",
    "Name": "陈默",
    "Image": null,
    "Company": "某制造业集团",
    "Position": "人力资源总监",
    "PhoneNo": "13700000002",
    "IsgoSend": 0,
    "RowNumber": 1
  }
]
```

- **调用位置**：`network.js:477`、`network.js:522`、`network.js:575`、`network.js:670`、`network.js:768`、`network.js:859`、`search.js:265`、`user.js:567`

---

#### 3.2.5 相似人脉推荐

- **用途**：基于共同好友/关系链推荐相似人脉，用于好友页与好友列表页"猜你认识"。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Contacts/AlikeConnections`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OpenId | string | 是 | 当前登录用户主键 |
| MyOpenId | string | 是 | 当前登录用户主键（与 `OpenId` 相同） |
| Limite | int | 是 | 返回条数，前端传 `5 + 已加载轮次`，逐次增大 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| OpenId | string | 推荐用户主键 |
| Name | string | 姓名 |
| Image | string | 头像 |
| Company | string | 公司 |
| Position | string | 职位 |
| PhoneNo | string | 电话 |
| IsgoSend | int | 0 未申请 / 1 已申请 |

**响应示例**

```json
[
  {
    "OpenId": "old0447qqq111222333",
    "Name": "赵敏",
    "Image": "uploadimage/atdportrait/avatar_20240401.jpg",
    "Company": "某互联网公司",
    "Position": "招聘专家",
    "PhoneNo": "13600000003",
    "IsgoSend": 1
  }
]
```

- **调用位置**：`connections.js:202`、`friend.js:494`

---

#### 3.2.6 共同好友列表

- **用途**：分页获取"我"与目标用户的共同好友。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Contacts/GetContactsLowerList`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OpenId | string | 是 | 当前登录用户主键 |
| OpenIdPass | string | 是 | 目标用户主键 |
| page | int | 是 | 页码，从 1 开始 |
| limite | int | 是 | 每页条数，前端固定 15 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| OpenId | string | 共同好友主键 |
| Name | string | 姓名 |
| Image | string | 头像 |
| Company | string | 公司 |
| Position | string | 职位 |

**响应示例**

```json
[
  {
    "OpenId": "old0443ppp777888999",
    "Name": "孙悦",
    "Image": "uploadimage/atdportrait/avatar_20240220.jpg",
    "Company": "某咨询公司",
    "Position": "顾问"
  }
]
```

- **调用位置**：`network.js:1151`、`user.js:245`、`friend.js:224`

---

#### 3.2.7 共同好友数量

- **用途**：获取两个用户之间的共同好友总数。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Contacts/GetContactsLowerCount`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OpenId | string | 是 | 当前登录用户主键 |
| OpenIdPass | string | 是 | 目标用户主键 |

**响应字段**：标量 `int`，共同好友数量；`0` 表示无共同好友。

**响应示例**

```json
12
```

- **调用位置**：`network.js:1096`、`user.js:294`、`friend.js:274`

---

### 3.3 好友申请

#### 3.3.1 查询今日已发送申请数

- **用途**：发送好友申请前校验每日上限（30 次）。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Apply/UserApplyMax`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OpenId | string | 是 | 当前登录用户主键 |

**响应字段**：标量 `int`，今日已发送的申请数；`>= 30` 时前端提示"今日添加好友已达上限"。

**响应示例**

```json
8
```

- **调用位置**：`network.js:975`、`search.js:170`、`user.js:361`、`friend.js:534`

---

#### 3.3.2 发送好友申请

- **用途**：向目标用户发起加好友申请。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Apply/AddUserApply`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| SOpenId | string | 是 | 申请方（当前登录用户）主键 |
| BOpenId | string | 是 | 被申请方主键 |

**响应字段**：标量 `int`，`1` 表示发送成功，`0` 表示失败或已存在申请。

**响应示例**

```json
1
```

> 发送成功且返回 `1` 时，前端立即调用 `Contacts/AddUserAction` 写入一条行为记录（`KindId=1`、`ContentId=11`）。

- **调用位置**：`network.js:984`、`search.js:179`、`user.js:370`、`friend.js:543`、`apply.js:309`

---

#### 3.3.3 收到的申请列表

- **用途**：获取"我收到的"好友申请列表。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Apply/GetSUserApplyList`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OpenId | string | 是 | 当前登录用户主键；未登录时前端传全零 GUID `00000000-0000-0000-0000-000000000000` |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| AId | int/string | 申请记录主键，用于同意/忽略 |
| OpenId | string | 申请方主键 |
| Name | string | 申请方姓名 |
| Image | string | 申请方头像 |
| Company | string | 公司 |
| Position | string | 职位 |
| IsTake | int | 0 未处理 / 1 已同意 / 2 已忽略 |
| CreateTimeNo | string | 申请时间（`yyyy-MM-dd HH:mm:ss`） |

**响应示例**

```json
[
  {
    "AId": 1024,
    "OpenId": "old0441aaa222333444",
    "Name": "周涛",
    "Image": "uploadimage/atdportrait/avatar_20240501.jpg",
    "Company": "某快消集团",
    "Position": "招聘主管",
    "IsTake": 0,
    "CreateTimeNo": "2026-11-16 09:31:20"
  }
]
```

- **调用位置**：`network.js:428`、`apply.js:79`

---

#### 3.3.4 已发送的申请列表

- **用途**：获取"我发出的"好友申请列表。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Apply/GetFUserApplyList`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OpenId | string | 是 | 当前登录用户主键 |

**响应字段**：同 3.3.3，`OpenId` 为被申请方主键。

**响应示例**

```json
[
  {
    "AId": 1025,
    "OpenId": "old0448bbb555666777",
    "Name": "吴敏",
    "Image": null,
    "Company": "某金融集团",
    "Position": "HRM",
    "IsTake": 1,
    "CreateTimeNo": "2026-11-15 18:02:11"
  }
]
```

- **调用位置**：`apply.js:124`

---

#### 3.3.5 忽略申请

- **用途**：将指定申请标记为"已忽略"（`IsTake=2`）。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Apply/PassUserApply`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| AId | int/string | 是 | 申请记录主键 |

**响应字段**：无业务数据，HTTP 200 即视为成功。

**响应示例**

```json
null
```

- **调用位置**：`network.js:1022`、`apply.js:168`

---

#### 3.3.6 同意申请

- **用途**：通过好友申请，建立双向好友关系。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Apply/AdoptUserApply`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| AId | int/string | 是 | 申请记录主键 |
| OpenId | string | 是 | 当前登录用户（被申请方）主键 |
| OpenIdPass | string | 是 | 申请方主键 |

**响应字段**：无业务数据，HTTP 200 即视为成功。

**响应示例**

```json
null
```

- **调用位置**：`network.js:1042`、`apply.js:188`

---

### 3.4 访客 / 收藏 / 点赞记录

#### 3.4.1 记录统计（本周、上周、总计）

- **用途**：获取浏览、点赞、收藏记录的统计值，用于列表页顶部数据卡片。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/UserInfo/GetCountAllorAdd`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OpenId | string | 是 | 当前登录用户主键 |
| UserType | int | 是 | 0 谁看过我 / 1 我收藏了谁 |
| Type | int | 是 | 0 浏览 / 1 点赞 / 2 收藏 |

**响应字段**（数组，取第 1 个元素）

| 字段名 | 类型 | 说明 |
|---|---|---|
| AllCount | int | 累计条数 |
| OneWeeksCount | int | 本周新增 |
| TwoWeeksCount | int | 上周新增 |

**响应示例**

```json
[{ "AllCount": 256, "OneWeeksCount": 18, "TwoWeeksCount": 12 }]
```

- **调用位置**：`browse.js:62`（Type=0）、`like.js:62`（Type=1）、`collection.js:62`（Type=2）

---

#### 3.4.2 谁看过我

- **用途**：分页获取访问过"我"主页的用户列表。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/UserInfo/GetLookUser`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OpenId | string | 是 | 当前登录用户主键 |
| OpenIdPass | string | 否 | 预留参数，前端固定传空串 |
| page | int | 是 | 页码，从 1 开始 |
| limit | int | 是 | 每页条数，前端固定 15 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| data | array | 访客列表 |
| data[].OpenId | string | 访客主键 |
| data[].Name | string | 姓名 |
| data[].Image | string | 头像 |
| data[].Company | string | 公司 |
| data[].Position | string | 职位 |
| data[].PhoneNo | string | 电话 |
| data[].IsFriend | int | 0 非好友 / 1 好友（决定跳转 `User` 或 `Friend` 页） |
| data[].IsgoSend | int | 0 未申请 / 1 已申请（非好友时判断按钮文案） |
| data[].LookTime | string | 最近访问时间 |
| data[].LookCount | int | 累计访问次数 |

**响应示例**

```json
{
  "data": [
    {
      "OpenId": "old0444ccc888999000",
      "Name": "何静",
      "Image": "uploadimage/atdportrait/avatar_20240601.jpg",
      "Company": "某医药集团",
      "Position": "HRBP",
      "PhoneNo": "13500000004",
      "IsFriend": 0,
      "IsgoSend": 1,
      "LookTime": "2026-11-16 14:20:00",
      "LookCount": 3
    }
  ]
}
```

- **调用位置**：`browse.js:88`、`friend.js:69`、`user.js:83`

---

#### 3.4.3 我看过谁

- **用途**：分页获取"我"访问过的用户列表。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/UserInfo/GetUserLook`

**请求参数**：同 3.4.2。

**响应字段**：同 3.4.2。

**响应示例**

```json
{
  "data": [
    {
      "OpenId": "old0440ddd111222333",
      "Name": "刘洋",
      "Image": null,
      "Company": "某汽车集团",
      "Position": "招聘经理",
      "PhoneNo": "13400000005",
      "IsFriend": 1,
      "IsgoSend": 1,
      "LookTime": "2026-11-15 11:05:00",
      "LookCount": 1
    }
  ]
}
```

- **调用位置**：`browse.js:144`

---

#### 3.4.4 谁收藏了我

- **用途**：分页获取收藏了"我"的用户列表。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/UserInfo/GetCollectUser`

**请求参数**：同 3.4.2。

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| data | array | 收藏者列表 |
| data[].OpenId | string | 用户主键 |
| data[].Name | string | 姓名 |
| data[].Image | string | 头像 |
| data[].Company | string | 公司 |
| data[].Position | string | 职位 |
| data[].PhoneNo | string | 电话 |
| data[].IsFriend | int | 0 非好友 / 1 好友 |
| data[].IsgoSend | int | 0 未申请 / 1 已申请 |
| data[].CollectTime | string | 收藏时间 |

**响应示例**

```json
{
  "data": [
    {
      "OpenId": "old0446eee444555666",
      "Name": "郑楠",
      "Image": "uploadimage/atdportrait/avatar_20240701.jpg",
      "Company": "某地产集团",
      "Position": "招聘总监",
      "PhoneNo": "13300000006",
      "IsFriend": 0,
      "IsgoSend": 0,
      "CollectTime": "2026-11-14 16:40:00"
    }
  ]
}
```

- **调用位置**：`collection.js:88`

---

#### 3.4.5 我收藏了谁

- **用途**：分页获取"我"收藏的用户列表。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/UserInfo/GetUserCollect`

**请求参数**：同 3.4.2。

**响应字段**：同 3.4.4。

**响应示例**

```json
{
  "data": [
    {
      "OpenId": "old0445fff777888999",
      "Name": "马超",
      "Image": null,
      "Company": "某物流集团",
      "Position": "HRD",
      "PhoneNo": "13200000007",
      "IsFriend": 1,
      "IsgoSend": 1,
      "CollectTime": "2026-11-10 09:12:00"
    }
  ]
}
```

- **调用位置**：`collection.js:144`

---

#### 3.4.6 谁点赞了我

- **用途**：分页获取点赞了"我"的用户列表。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/UserInfo/GetlikeUser`

**请求参数**：同 3.4.2。

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| data | array | 点赞者列表 |
| data[].OpenId | string | 用户主键 |
| data[].Name | string | 姓名 |
| data[].Image | string | 头像 |
| data[].Company | string | 公司 |
| data[].Position | string | 职位 |
| data[].PhoneNo | string | 电话 |
| data[].IsFriend | int | 0 非好友 / 1 好友 |
| data[].IsgoSend | int | 0 未申请 / 1 已申请 |
| data[].LikeTime | string | 点赞时间 |

**响应示例**

```json
{
  "data": [
    {
      "OpenId": "old0441ggg000111222",
      "Name": "许晴",
      "Image": "uploadimage/atdportrait/avatar_20240801.jpg",
      "Company": "某教育集团",
      "Position": "招聘经理",
      "PhoneNo": "13100000008",
      "IsFriend": 0,
      "IsgoSend": 0,
      "LikeTime": "2026-11-16 10:00:00"
    }
  ]
}
```

- **调用位置**：`like.js:88`

---

#### 3.4.7 我点赞了谁

- **用途**：分页获取"我"点赞过的用户列表。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/UserInfo/GetUserlike`

**请求参数**：同 3.4.2。

**响应字段**：同 3.4.6。

**响应示例**

```json
{
  "data": [
    {
      "OpenId": "old0442hhh333444555",
      "Name": "范琳",
      "Image": null,
      "Company": "某零售集团",
      "Position": "HRVP",
      "PhoneNo": "13000000009",
      "IsFriend": 1,
      "IsgoSend": 1,
      "LikeTime": "2026-11-12 20:30:00"
    }
  ]
}
```

- **调用位置**：`like.js:144`

---

### 3.5 互动行为

#### 3.5.1 写入行为记录

- **用途**：记录"加好友""访问主页"等用户行为，用于推荐与去重判断。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Contacts/AddUserAction`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OpenId | string | 是 | 当前登录用户主键 |
| KindId | int | 是 | 行为大类，固定 1 |
| ContentId | int | 是 | 行为子类：11 加好友 / 2 访问主页 |
| Remarks | string | 是 | 备注，通常传对方手机号或对方 `OpenId` |

**响应字段**：标量 `int`，`1` 表示写入成功。

**响应示例**

```json
1
```

- **调用位置**：`network.js:996`、`search.js:191`、`user.js:382`、`friend.js:555`、`apply.js:322`

---

#### 3.5.2 点赞（行为记录）

- **用途**：对用户主页点赞，写入一条 `KindId=1`、`ContentId=9` 的行为记录。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Contacts/AddUserActions`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OpenId | string | 是 | 当前登录用户主键 |
| KindId | int | 是 | 行为大类，固定 1 |
| ContentId | int | 是 | 行为子类，固定 9（点赞） |
| Remarks | string | 是 | 被点赞用户主键（`OpenIdPass`） |

**响应字段**：标量/布尔，`true`（或非 0）表示点赞成功，`false`（或 0）表示已点过赞。

**响应示例**

```json
true
```

- **调用位置**：`user.js:134`、`friend.js:121`

---

### 3.6 会议活动与报告位

#### 3.6.1 首页推荐会议与活动

- **用途**：获取侧栏"热点会议与活动"列表，含主讲人与场次信息。
- **请求**：`POST https://form.hrflag.com/WebAPI/ActiveMeeting/GetinnerActivemeetingNew`

**请求参数**：无。

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| ActiveId | string | 活动主键 |
| ActiveName | string | 活动名称 |
| SourceUrl | string | 活动详情跳转地址 |
| SpeakerName | string | 演讲嘉宾姓名 |
| SpeakerPosition | string | 嘉宾职位 |
| SpeakerImage | string | 嘉宾头像（相对路径） |
| ActivityLogo | string | 活动 Logo（相对路径） |
| Activetime | array | 场次列表，元素含 `SceneBeginDate`（开始日期）、`CountryName`（城市/国家） |

**响应示例**

```json
[
  {
    "ActiveId": "act20261101",
    "ActiveName": "2026 中国人力资源峰会",
    "SourceUrl": "https://events.hrflag.com/Detail?sceneId=1001&activityId=act20261101",
    "SpeakerName": "李明",
    "SpeakerPosition": "人力资源副总裁",
    "SpeakerImage": "uploadimage/speaker/1.jpg",
    "ActivityLogo": "uploadimage/activity/logo1.png",
    "Activetime": [
      { "SceneBeginDate": "2026-12-05", "CountryName": "上海" },
      { "SceneBeginDate": "2026-12-12", "CountryName": "北京" }
    ]
  }
]
```

- **调用位置**：`apply.js:206`、`browse.js:249`、`collection.js:248`、`connections.js:154`、`friend.js:430`、`like.js:248`、`search.js:217`、`user.js:520`

---

#### 3.6.2 推荐活动（旧版）

- **用途**：按用户返回推荐活动列表，当前页面已改用 3.6.1，保留兼容。
- **请求**：`POST https://form.hrflag.com/WebAPI/ActiveMeeting/GetActivemeeting?userId={UserId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| userId | string | 否 | 主站用户 ID（Cookie `UserId`），可为空 |

**响应字段**：`ActiveId`、`ActiveName`、`SourceUrl`、`Image`、`Activetime`（结构同 3.6.1）。

**响应示例**

```json
[
  {
    "ActiveId": "act20261020",
    "ActiveName": "薪酬绩效实战工作坊",
    "SourceUrl": "https://events.hrflag.com/Detail?activityId=act20261020",
    "Image": "uploadimage/activity/cover.jpg",
    "Activetime": [{ "SceneBeginDate": "2026-12-20", "CountryName": "深圳" }]
  }
]
```

- **调用位置**：`friend.js:463`（`apply.js:207` 中为注释代码）

---

#### 3.6.3 活动点击埋点

- **用途**：记录一次活动位点击，用于广告/活动效果统计。
- **请求**：`POST https://form.hrflag.com/WebAPI/ActiveMeeting/ActiveClickRecord?userId={UserId}&aDid={ActiveId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| userId | string | 否 | 主站用户 ID |
| aDid | string | 是 | 活动 ID（响应中的 `ActiveId`） |

**响应字段**：无业务数据。

**响应示例**

```json
null
```

- **调用位置**：`apply.js:241`、`browse.js:284`、`collection.js:283`、`connections.js:189`、`friend.js:481`、`like.js:283`、`search.js:252`、`user.js:554`

---

#### 3.6.4 热门活动

- **用途**：获取首页"最热活动"榜单（按浏览量倒序）。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/GetHotActivityDetail?count={count}&ScenceID={sceneId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| count | int | 是 | 返回条数，前端固定 7 |
| ScenceID | string | 否 | 场次 ID，为空表示不限定场次 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| SceneId | string | 场次 ID |
| ActivityId | string | 活动 ID |
| ActivityTitle | string | 活动标题 |
| ActivitySponsor | string | 主办方 |
| ImageUrl | string | 封面图（相对路径） |
| ActivityTicketCheck | string | 票务/报名状态文案 |
| PageView | int | 浏览量 |
| Weekness | string | 星期文案 |
| SceneBeginDate | string | 场次开始时间（`yyyy-MM-dd HH:mm:ss`） |
| CityName | string | 城市 |

**响应示例**

```json
[
  {
    "SceneId": "1001",
    "ActivityId": "act20261101",
    "ActivityTitle": "2026 中国人力资源峰会",
    "ActivitySponsor": "HRflag 众旗",
    "ImageUrl": "uploadimage/activity/cover1.jpg",
    "ActivityTicketCheck": "报名中",
    "PageView": 15230,
    "Weekness": "周五",
    "SceneBeginDate": "2026-12-05 09:00:00",
    "CityName": "上海"
  }
]
```

- **调用位置**：`network.js:85`

---

#### 3.6.5 高吸引力研究报告

- **用途**：获取首页右侧"高吸引力报告"推荐列表。
- **请求**：`POST https://form.hrflag.com/WebAPI/FileMgr/GetHighForceFileld?Switch={Switch}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| Switch | int | 是 | 推荐位开关/类型，前端固定 3 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| FileId | string | 报告主键 |
| Name | string | 报告名称 |
| ComName | string | 出品/发布机构 |
| SmallImage | string | 封面缩略图（相对路径），空则用 `report.jpg` |
| ReleaseTime | string | 发布时间 |
| PageViews | int | 预览次数 |
| FilePages | int | 报告页数 |
| Downloads | int | 下载次数 |

**响应示例**

```json
[
  {
    "FileId": "f20260901",
    "Name": "2026 中国人力资源薪酬白皮书",
    "ComName": "HRflag 研究院",
    "SmallImage": "uploadimage/report/cover2026.jpg",
    "ReleaseTime": "2026-09-01",
    "PageViews": 8421,
    "FilePages": 68,
    "Downloads": 1203
  }
]
```

- **调用位置**：`network.js:360`

---

### 3.7 快讯

#### 3.7.1 快讯列表

- **用途**：获取首页"快讯"栏目列表。
- **请求**：`POST https://form.hrflag.com/WebAPI/Twitter/GetHrflagTwitter`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| UserId | string | 否 | 主站用户 ID，用于返回 `IsLike`/`IsShares` 状态，可为空 |
| top | int | 是 | 返回条数，初始 20 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| Guid | string | 快讯主键 |
| TName | string | 标题 |
| BTContent | string | 正文内容（含换行） |
| PageView | int | 浏览量 |
| UserLikeCount | int | 点赞数 |
| IsLike | string | `"TRUE"`/`"FALSE"`，当前用户是否已点赞 |
| UserShares | int | 分享数 |
| IsShares | string | `"TRUE"`/`"FALSE"`，当前用户是否已分享 |
| CreateTime | string | 发布时间（`yyyy-MM-dd HH:mm:ss`） |

**响应示例**

```json
[
  {
    "Guid": "twi-20261116-001",
    "TName": "某集团发布 2027 年人力资源战略",
    "BTContent": "该集团宣布将全面推行技能薪酬体系。",
    "PageView": 3210,
    "UserLikeCount": 42,
    "IsLike": "FALSE",
    "UserShares": 8,
    "IsShares": "FALSE",
    "CreateTime": "2026-11-16 09:00:00"
  }
]
```

> 前端会对每条快讯立即调用 3.7.5 累加浏览量。

- **调用位置**：`network.js:114`

---

#### 3.7.2 换一换（快讯）

- **用途**：翻页获取下一批快讯，排除已展示的 `Guid`。
- **请求**：`POST https://form.hrflag.com/WebAPI/Twitter/ChangeTwitters`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| UserId | string | 否 | 主站用户 ID |
| Guid | string | 是 | 已展示快讯 `Guid` 的逗号分隔串 |
| limit | int | 是 | 本次返回条数，固定 20 |

**响应字段**：同 3.7.1；返回空数组表示已无更多。

**响应示例**

```json
[
  {
    "Guid": "twi-20261116-021",
    "TName": "灵活用工合规指引更新",
    "BTContent": "多地更新灵活用工合规口径。",
    "PageView": 980,
    "UserLikeCount": 5,
    "IsLike": "FALSE",
    "UserShares": 1,
    "IsShares": "FALSE",
    "CreateTime": "2026-11-15 17:20:00"
  }
]
```

- **调用位置**：`network.js:217`

---

#### 3.7.3 快讯点赞

- **用途**：对指定快讯点赞。
- **请求**：`POST https://form.hrflag.com/WebAPI/Twitter/AddTwitterLike`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| Guid | string | 是 | 快讯主键 |
| UserId | string | 否 | 主站用户 ID；为空时后端可能无法记录用户维度 |

**响应字段**：无业务数据；前端点赞后重新调用 3.7.4 获取最新点赞数。

**响应示例**

```json
true
```

- **调用位置**：`network.js:174`

---

#### 3.7.4 查询快讯点赞数

- **用途**：获取单条快讯的最新点赞数，用于点赞后的局部刷新。
- **请求**：`POST https://form.hrflag.com/WebAPI/Twitter/GetUserLike`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| Guid | string | 是 | 快讯主键 |

**响应字段**：标量 `int`，点赞总数。

**响应示例**

```json
43
```

- **调用位置**：`network.js:196`

---

#### 3.7.5 快讯浏览量埋点

- **用途**：快讯渲染时累加一次浏览量。
- **请求**：`POST https://form.hrflag.com/WebAPI/Twitter/AddTwitterView`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| Object | string | 是 | 快讯主键（`Guid`） |

**响应字段**：无业务数据。

**响应示例**

```json
null
```

- **调用位置**：`network.js:283`

---

### 3.8 广告位与点击埋点

> 4 个广告位接口均按位置区分，返回结构一致，均为数组，前端按索引取用（`data[0]`、`data[1]`、`data[2]`）。

#### 3.8.1 人脉首页广告位

- **用途**：人脉首页右侧 3 个广告位。
- **请求**：`POST https://form.hrflag.com/WebAPI/Advertising/IGetPersonConnectionAdv`
- **请求参数**：无（`userId` 未传值）。
- **响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| Id | string | 广告主键，用于点击埋点 |
| ImagePath | string | 图片相对路径，需拼 `FilePath` |
| Interlinkage | string | 跳转链接 |

**响应示例**

```json
[
  { "Id": "ad001", "ImagePath": "UploadImage/ActivityImg/ad1.png", "Interlinkage": "https://events.hrflag.com/" },
  { "Id": "ad002", "ImagePath": "UploadImage/ActivityImg/ad2.png", "Interlinkage": "https://reports.hrflag.com/" },
  { "Id": "ad003", "ImagePath": "UploadImage/ActivityImg/ad3.png", "Interlinkage": "https://video.hrflag.com/" }
]
```

- **调用位置**：`network.js:47`

---

#### 3.8.2 好友申请页广告位

- **用途**：好友申请列表页广告位。
- **请求**：`POST https://form.hrflag.com/WebAPI/Advertising/IGetFriendApplyForAdv?userId={UserId}`
- **请求参数**：`userId`（string，否）主站用户 ID，可为空。
- **响应字段**：同 3.8.1。

**响应示例**

```json
[{ "Id": "ad101", "ImagePath": "UploadImage/ActivityImg/ad101.png", "Interlinkage": "https://hrflag.com/" }]
```

- **调用位置**：`apply.js:363`

---

#### 3.8.3 好友列表页广告位

- **用途**：我的好友页广告位。
- **请求**：`POST https://form.hrflag.com/WebAPI/Advertising/IGetFriendTableAdv?userId={UserId}`
- **请求参数**：`userId`（string，否）主站用户 ID。
- **响应字段**：同 3.8.1。

**响应示例**

```json
[{ "Id": "ad201", "ImagePath": "UploadImage/ActivityImg/ad201.png", "Interlinkage": "https://hrflag.com/" }]
```

- **调用位置**：`connections.js:300`

---

#### 3.8.4 陌生人主页广告位

- **用途**：陌生人主页（`User`）、好友主页（`Friend`）广告位。
- **请求**：`POST https://form.hrflag.com/WebAPI/Advertising/IGetStrangerADAdv?userId={UserId}`
- **请求参数**：`userId`（string，否）主站用户 ID。
- **响应字段**：同 3.8.1。

**响应示例**

```json
[
  { "Id": "ad301", "ImagePath": "UploadImage/ActivityImg/ad301.png", "Interlinkage": "https://hrflag.com/" },
  { "Id": "ad302", "ImagePath": "UploadImage/ActivityImg/ad302.png", "Interlinkage": "https://hrflag.com/" }
]
```

- **调用位置**：`user.js:605`、`friend.js:588`

---

#### 3.8.5 顶部通栏广告

- **用途**：全站顶部通栏广告（公共布局 `hpublic.js`），人脉所有页面均会加载。
- **请求**：`POST https://form.hrflag.com/WebAPI/Advertising/IGetTopAD?userId={UserId}`
- **请求参数**：`userId`（string，否）主站用户 ID。
- **响应字段**：单个对象，字段同 3.8.1。

**响应示例**

```json
{ "Id": "ad900", "ImagePath": "UploadImage/ActivityImg/top.png", "Interlinkage": "https://hrflag.com/" }
```

- **调用位置**：`Scripts/Common/js/hpublic.js:65`

---

#### 3.8.6 广告点击埋点

- **用途**：广告位点击上报，`aDid` 取广告响应中的 `Id`。
- **请求**：`POST https://form.hrflag.com/WebAPI/Advertising/Advertising/IAddMeetingUPClickRecord?userId={UserId}&aDid={AdId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| userId | string | 否 | 主站用户 ID |
| aDid | string | 是 | 广告主键 |

**响应字段**：无业务数据。

**响应示例**

```json
null
```

- **调用位置**：`network.js:62`、`apply.js:377`、`browse.js:284`、`collection.js:283`、`connections.js:314`、`friend.js:602`、`like.js:283`、`search.js:252`、`user.js:619`

---

#### 3.8.7 顶部广告点击埋点

- **用途**：顶部通栏广告点击上报。
- **请求**：`POST https://form.hrflag.com/WebAPI/Advertising/IAddTopADClickRecord?userId={UserId}&aDid={AdId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| userId | string | 否 | 主站用户 ID |
| aDid | string | 是 | 广告主键 |

**响应字段**：无业务数据。

**响应示例**

```json
null
```

- **调用位置**：`Scripts/Common/js/hpublic.js:78`

---

## 4. 附录

### 4.1 接口总览

| 序号 | 接口 | 方法 | 路径 | 用途 |
|---|---|---|---|---|
| 1 | 手机号换 OpenId | POST | `WxSpAPI/Contacts/GetUserInfoByPhone` | 登录态解析 |
| 2 | 用户名片 | POST | `WxSpAPI/Contacts/GetUserInfoByid` | 主页名片 |
| 3 | 浏览/点赞统计 | POST | `WxSpAPI/UserInfo/GetRecordCount` | 主页统计 |
| 4 | 个人介绍 | POST | `WxSpAPI/UserInfo/GetHRUserSelfIntroduction` | 主页介绍 |
| 5 | 公司介绍 | POST | `WxSpAPI/UserInfo/GetHRUserComIntroduction` | 主页介绍 |
| 6 | 业务介绍 | POST | `WxSpAPI/UserInfo/GetHRUserProfessionalWork` | 主页介绍 |
| 7 | 个人视频 | POST | `WxSpAPI/UserInfo/CompanyBusinessPersonalVideo` | 主页视频 |
| 8 | 好友列表 | POST | `WxSpAPI/Contacts/GetContacts` | 好友列表/搜索 |
| 9 | 人脉搜索 | POST | `WxSpAPI/Contacts/GetConnections` | 全站搜索 |
| 10 | 搜索计数 | POST | `WxSpAPI/Contacts/GetConnectionsCount` | 结果计数 |
| 11 | 人脉推荐 | POST | `WxSpAPI/Contacts/GetConnectionInfo` | 同行/同城/二度 |
| 12 | 相似人脉 | POST | `WxSpAPI/Contacts/AlikeConnections` | 猜你认识 |
| 13 | 共同好友列表 | POST | `WxSpAPI/Contacts/GetContactsLowerList` | 共同好友弹层 |
| 14 | 共同好友数 | POST | `WxSpAPI/Contacts/GetContactsLowerCount` | 关系强度 |
| 15 | 今日申请数 | POST | `WxSpAPI/Apply/UserApplyMax` | 上限校验 |
| 16 | 发送申请 | POST | `WxSpAPI/Apply/AddUserApply` | 加好友 |
| 17 | 收到申请列表 | POST | `WxSpAPI/Apply/GetSUserApplyList` | 申请页 |
| 18 | 已发申请列表 | POST | `WxSpAPI/Apply/GetFUserApplyList` | 申请页 |
| 19 | 忽略申请 | POST | `WxSpAPI/Apply/PassUserApply` | 申请处理 |
| 20 | 同意申请 | POST | `WxSpAPI/Apply/AdoptUserApply` | 申请处理 |
| 21 | 记录统计 | POST | `WxSpAPI/UserInfo/GetCountAllorAdd` | 浏览/点赞/收藏统计 |
| 22 | 谁看过我 | POST | `WxSpAPI/UserInfo/GetLookUser` | 访客列表 |
| 23 | 我看过谁 | POST | `WxSpAPI/UserInfo/GetUserLook` | 访客列表 |
| 24 | 谁收藏我 | POST | `WxSpAPI/UserInfo/GetCollectUser` | 收藏列表 |
| 25 | 我收藏谁 | POST | `WxSpAPI/UserInfo/GetUserCollect` | 收藏列表 |
| 26 | 谁点赞我 | POST | `WxSpAPI/UserInfo/GetlikeUser` | 点赞列表 |
| 27 | 我点赞谁 | POST | `WxSpAPI/UserInfo/GetUserlike` | 点赞列表 |
| 28 | 行为记录 | POST | `WxSpAPI/Contacts/AddUserAction` | 加好友/访问记录 |
| 29 | 点赞记录 | POST | `WxSpAPI/Contacts/AddUserActions` | 主页点赞 |
| 30 | 推荐活动 | POST | `WebAPI/ActiveMeeting/GetinnerActivemeetingNew` | 侧栏活动 |
| 31 | 推荐活动（旧） | POST | `WebAPI/ActiveMeeting/GetActivemeeting` | 兼容 |
| 32 | 活动点击埋点 | POST | `WebAPI/ActiveMeeting/ActiveClickRecord` | 活动统计 |
| 33 | 热门活动 | POST | `WebAPI/Activity/GetHotActivityDetail` | 最热活动 |
| 34 | 高吸引力报告 | POST | `WebAPI/FileMgr/GetHighForceFileld` | 报告推荐 |
| 35 | 快讯列表 | POST | `WebAPI/Twitter/GetHrflagTwitter` | 首页快讯 |
| 36 | 快讯换一换 | POST | `WebAPI/Twitter/ChangeTwitters` | 快讯翻页 |
| 37 | 快讯点赞 | POST | `WebAPI/Twitter/AddTwitterLike` | 快讯互动 |
| 38 | 快讯点赞数 | POST | `WebAPI/Twitter/GetUserLike` | 点赞数刷新 |
| 39 | 快讯浏览埋点 | POST | `WebAPI/Twitter/AddTwitterView` | 浏览统计 |
| 40 | 人脉首页广告 | POST | `WebAPI/Advertising/IGetPersonConnectionAdv` | 广告位 |
| 41 | 申请页广告 | POST | `WebAPI/Advertising/IGetFriendApplyForAdv` | 广告位 |
| 42 | 好友页广告 | POST | `WebAPI/Advertising/IGetFriendTableAdv` | 广告位 |
| 43 | 主页广告 | POST | `WebAPI/Advertising/IGetStrangerADAdv` | 广告位 |
| 44 | 顶部通栏广告 | POST | `WebAPI/Advertising/IGetTopAD` | 全站广告 |
| 45 | 广告点击埋点 | POST | `WebAPI/Advertising/Advertising/IAddMeetingUPClickRecord` | 广告统计 |
| 46 | 顶部广告点击 | POST | `WebAPI/Advertising/IAddTopADClickRecord` | 广告统计 |

### 4.2 联调注意事项

1. **登录态前置**：除 3.8 广告位外，几乎所有接口都依赖 `OpenId`，联调时先完成 3.1.1，再串联其他接口。
2. **分页参数拼写不一致**：`GetConnectionInfo`、`GetContactsLowerList`、`GetConnections` 使用 `limit`/`Limite`，`GetContactsLowerList` 使用小写 `limite`，务必按文档传参。
3. **响应包裹不一致**：`UserInfo/Get*User`、`GetUser*` 系列返回 `{ data: [...] }`，其余列表接口返回裸数组，解析时需区分。
4. **空数据表现**：列表接口返回 `[]`；标量接口返回 `0`。前端据此展示空态或"已加载全部"。
5. **重复路径**：广告点击埋点路径为 `Advertising/Advertising/IAddMeetingUPClickRecord`（两级 `Advertising`），并非笔误，需按原样配置。
6. **图片地址**：后端返回相对路径，统一拼 `FilePath`；`Image` 可能返回 `../../files/imgs/tou.png`，需替换为默认头像。
7. **时间字段**：既有 `CreateTime`（`yyyy-MM-dd HH:mm:ss`）也有 `CreateTimeT`（已格式化 `yyyy-MM-dd HH:mm`）与 `CreateTimeNo`，展示逻辑不同，勿混用。
8. **每日上限**：`Apply/UserApplyMax` 返回今日已发送数，前端判定 `< 30` 才允许继续发送。
9. **行为记录联动**：发送好友申请成功后需再调用 `Contacts/AddUserAction`（`ContentId=11`），否则"等待通过"状态无法回显。
