# 趋势与洞察（Awards）模块接口文档

| 项目 | 内容 |
|---|---|
| 模块名称 | 趋势与洞察（Awards，站内亦称"榜单与奖项"） |
| 前端站点 | https://awards.hrflag.com/ |
| 源码目录 | `G:\G-HRflag\Awards` |
| 接口域名 | `https://form.hrflag.com/WebAPI/` |
| 文档版本 | v1.0 |
| 更新日期 | 2026-11-17 |
| 适用对象 | 前端开发、后端开发、联调测试 |

---

## 1. 模块概述

趋势与洞察模块是 HRflag 榜单与奖项的聚合入口页，集中展示"全球上市人力资源服务公司 50 强""极帜奖 Flag Awards""金帜奖""市值榜"等榜单/奖项条目，点击后跳转至各榜单独立子站。

### 1.1 页面结构

| 页面 | 路由 | 内容来源 | 说明 |
|---|---|---|---|
| 趋势与洞察列表 | `/Awards/Awards` | **服务端静态渲染**（`Views/Awards/Awards.cshtml` 内硬编码 `<li>` 条目） | 每条榜单为一个 `<li>`，含封面图、标题、简介、发布时间、跳转链接 |
| 页面公共框架 | `Views/Shared/_Layout.cshtml` | 接口 + 静态 | 顶部合作方 Logo 墙、顶部通栏广告、登录态头像 |
| 榜单详情 | 独立子站（见 4.2） | 各子站自身实现 | 不在本模块范围内 |

> 重要：**本模块没有"榜单列表接口"**。榜单条目的标题、简介、封面、发布时间均直接写在 `Awards.cshtml` 中，由服务端输出 HTML。前端联调时只需处理下方 3.1~3.4 的公共接口。

### 1.2 接口清单速览

| 序号 | 接口 | 方法 | 路径 | 用途 | 触发时机 |
|---|---|---|---|---|---|
| 1 | 合作方 Logo 墙 | POST | `WebAPI/Advertising/HomeADUP` | 顶部合作方入口 | 页面加载 |
| 2 | 顶部通栏广告 | POST | `WebAPI/Advertising/IGetTopAD` | 顶部广告图 | 页面加载 |
| 3 | 顶部广告点击埋点 | POST | `WebAPI/Advertising/IAddTopADClickRecord` | 广告点击统计 | 点击广告图 |
| 4 | 登录用户头像 | POST | `WebAPI/UserInfo/GetUserById` | 顶部用户头像 | 已登录时页面加载 |

---

## 2. 通用约定

### 2.1 环境与基础地址

| 环境 | WebAPI |
|---|---|
| 生产 | `https://form.hrflag.com/WebAPI/` |
| 测试 | `http://demo.hrflag.com/WebAPI/` |

> 前端常量见 `Scripts/Common/js/config.js`：`APIPath`、`FilePath`（`https://hrflagfile.oss-cn-hangzhou.aliyuncs.com/`）。

### 2.2 请求规范

- 全部为 **POST**，参数编码 `application/x-www-form-urlencoded; charset=UTF-8`（部分参数走 QueryString）。
- 响应 `application/json; charset=utf-8`，无统一 `code`/`msg` 包裹。
- 无鉴权头；登录态通过 Cookie `UserId` / `Name` / `PhoneNumber` 判断。

### 2.3 登录态

| Cookie | 说明 |
|---|---|
| `UserId` | 主站用户 ID（GUID），用于头像与广告个性化 |
| `Name` | 用户姓名，存在即视为已登录 |
| `PhoneNumber` | 手机号 |
| `Company` / `Department` / `Position` / `Email` / `TradeName` | 用户资料，登出时一并清除 |

未登录时顶部展示"登录/注册"，点击跳转 `https://hrflag.com/HRflag/login`；已登录点击"个人中心"跳转 `https://hrflag.com/HRflag/userCenter`。

### 2.4 图片地址约定

| 字段 | 拼接规则 |
|---|---|
| `ImagePath`（广告） | `FilePath + ImagePath` |
| `Image`（用户头像） | 可能为完整 URL，直接使用 |
| `UserPhotoUrl`（用户头像相对路径） | `FilePath + UserPhotoUrl` |
| 缺失头像 | 使用 `http://static.hrflag.com/img/newflag/newimgs/userpic.png` |

---

## 3. 接口明细

### 3.1 合作方 Logo 墙

- **用途**：获取页面顶部"合作方/媒体"Logo 列表，按 `SeqNo` 升序渲染，仅展示 `State=1` 的条目。
- **请求**：`POST https://form.hrflag.com/WebAPI/Advertising/HomeADUP`

**请求参数**：无。

**响应字段**（数组）

| 字段名 | 类型 | 说明 |
|---|---|---|
| Name | string | 合作方名称（文案） |
| ImagePath | string | Logo 相对路径，需拼 `FilePath` |
| InterLinkage | string | 点击跳转链接 |
| State | int | 1 展示 / 其他值不展示 |
| SeqNo | int | 排序号，前端按此升序排序 |

**响应示例**

```json
[
  {
    "Name": "某人力资源协会",
    "ImagePath": "UploadImage/Logo/partner1.png",
    "InterLinkage": "https://example.com",
    "State": 1,
    "SeqNo": 1
  },
  {
    "Name": "某商学院",
    "ImagePath": "UploadImage/Logo/partner2.png",
    "InterLinkage": "https://example.com/bschool",
    "State": 1,
    "SeqNo": 2
  }
]
```

**前端处理要点**

- 先按 `SeqNo` 升序排序，再遍历渲染。
- 仅渲染 `State === 1` 的条目。
- Logo 以 `18px × 18px` 展示并加 `grayscale(100%)` 灰度滤镜，鼠标交互由 CSS 控制。

- **调用位置**：`Views/Shared/_Layout.cshtml:497`

---

### 3.2 顶部通栏广告

- **用途**：获取页面顶部通栏广告图与跳转链接。
- **请求**：`POST https://form.hrflag.com/WebAPI/Advertising/IGetTopAD?userId={UserId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| userId | string | 否 | 主站用户 ID（Cookie `UserId`），未登录为空串 |

**响应字段**（单对象，从有效广告中随机返回一条）

| 字段名 | 类型 | 说明 |
|---|---|---|
| Id | string | 广告 ID，点击埋点使用 |
| ImagePath | string | 广告图相对路径，需拼 `FilePath` |
| Interlinkage | string | 点击跳转链接 |

**响应示例**

```json
{
  "Id": "ad900",
  "ImagePath": "UploadImage/ActivityImg/top_banner.png",
  "Interlinkage": "https://hrflag.com/"
}
```

**前端处理要点**：无有效广告时后端会因 `topADs[0]` 越界返回 500（而非 `null`），`hpublic.js` 未写 `error` 回调，表现为广告位静默空白。

- **调用位置**：`Scripts/Common/js/hpublic.js:64`

---

### 3.3 顶部广告点击埋点

- **用途**：记录顶部通栏广告点击，用于广告效果统计。
- **请求**：`POST https://form.hrflag.com/WebAPI/Advertising/IAddTopADClickRecord?userId={UserId}&aDid={AdId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| userId | string | 否 | 主站用户 ID |
| aDid | string | 是 | 广告 ID（3.2 响应中的 `Id`） |

**响应字段**：无业务数据（后端可能返回受影响行数）。

**响应示例**

```json
null
```

**前端处理要点**：埋点为异步上报，不阻塞跳转；失败不提示用户。

- **调用位置**：`Scripts/Common/js/hpublic.js:77`

---

### 3.4 登录用户头像

- **用途**：已登录时获取用户头像，渲染顶部用户区。
- **请求**：`POST https://form.hrflag.com/WebAPI/UserInfo/GetUserById?strUserId={UserId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| strUserId | string | 是 | 主站用户 ID（Cookie `UserId`） |

**响应字段**（数组）

| 字段名 | 类型 | 说明 |
|---|---|---|
| Image | string | 头像完整 URL，优先使用；可为空 |
| UserPhotoUrl | string | 头像相对路径，`Image` 为空时拼 `FilePath` 使用 |

**响应示例**

```json
[
  {
    "Image": "https://hrflagfile.oss-cn-hangzhou.aliyuncs.com/uploadimage/atdportrait/avatar_20240518.jpg",
    "UserPhotoUrl": "uploadimage/atdportrait/avatar_20240518.jpg"
  }
]
```

**前端处理要点**

- 仅在 Cookie `Name` 非空时调用。
- 返回空数组时使用默认头像 `http://static.hrflag.com/img/newflag/newimgs/userpic.png`。
- 取头像优先级：`Image` > `FilePath + UserPhotoUrl` > 默认头像。

- **调用位置**：`Scripts/Common/js/cookies.js:41`

---

## 4. 附录

### 4.1 榜单条目数据结构（当前为静态渲染）

榜单条目当前硬编码在 `Views/Awards/Awards.cshtml`，字段固定为下表 5 项。若后续改造为接口驱动，接口应按此结构返回（可作为前后端约定的字段基线）。

| 字段名 | 类型 | 说明 |
|---|---|---|
| Title | string | 榜单/奖项名称，如"2021全球上市人力资源服务公司50强" |
| Introduce | string | 简介（纯文本或 HTML），列表页截断展示 |
| ImageUrl | string | 封面图地址（当前为完整 URL） |
| PublishDate | string | 发布时间，格式 `yyyy/MM`，如 `2021/7` |
| LinkUrl | string | 详情跳转地址（多为独立子站首页） |

**对应 DOM 结构（供前端改造对照）**

```html
<li>
  <div class="the_logo awards_logo">
    <a target="_blank" href="{LinkUrl}"><img src="{ImageUrl}" alt=""></a>
  </div>
  <div class="the_info awards_info">
    <a target="_blank" href="{LinkUrl}">
      <h6>{Title}</h6>
      <p>{Introduce}</p>
      <div class="infomore">
        <div><span class="iconfont icon-shijian3"></span><span>{PublishDate}</span></div>
      </div>
    </a>
    <div class="infodetail pcshow">
      <a target="_blank" href="{LinkUrl}">查看详情</a>
    </div>
  </div>
</li>
```

### 4.2 榜单子站清单

| 榜单 / 奖项 | 子站地址 |
|---|---|
| 全球上市人力资源服务公司 50 强 | `http://global50.hrflag.com/` |
| 极帜奖 Flag Awards | `http://flagawards.hrflag.com` |
| 全球上市人力资源服务公司市值榜 | `http://cap.hrflag.com/` |
| 金帜奖 HRFLAG AWARDS | `http://golden.hrflag.com` |
| 其他榜单（如 APP 榜等） | 见 `Awards.cshtml` 各条目 `href` |

### 4.3 联调注意事项

1. **无列表接口**：本模块页面主体为静态 HTML，联调无需等待榜单接口；若需求变更为动态渲染，需先按 4.1 定义新接口。
2. **广告空表**：`IGetTopAD` 无有效广告时后端会抛异常（500），前端表现为空白；同时该接口每次调用都会写入一条曝光记录，压测或频繁刷新会放大曝光数。
3. **Logo 墙顺序**：后端返回顺序不保证有序，必须按 `SeqNo` 升序排序后再渲染。
4. **灰度样式**：合作方 Logo 使用 CSS 灰度，不依赖图片本身是否为彩色。
5. **登录态判断**：仅以 Cookie `Name` 是否存在判断登录，不校验 `UserId`；`UserId` 为空时头像接口会返回空数组。
6. **跨域**：接口域名为 `form.hrflag.com`，页面域名为 `awards.hrflag.com`，需后端保持 `Access-Control-Allow-Origin` 配置或同域代理。
7. **HTTP/HTTPS 混用**：`config.js` 中子站地址仍为 `http://`，页面为 `https://`，跳转时浏览器可能提示混合内容，建议统一为 `https`。
