# 会议与活动（Events）模块接口文档

| 项目 | 内容 |
|---|---|
| 模块名称 | 会议与活动（Events） |
| 前端站点 | https://events.hrflag.com/ |
| 源码目录 | `G:\G-HRflag\Events` |
| 接口域名 | `https://form.hrflag.com/WebAPI/`、`https://form.hrflag.com/WxSpAPI/` |
| 文档版本 | v1.0 |
| 更新日期 | 2026-11-17 |
| 适用对象 | 前端开发、后端开发、联调测试 |

---

## 1. 模块概述

会议与活动模块覆盖活动列表检索、活动详情（多场次 / 多票种）、报名表单、报名校验、付费下单与支付回写、直播与分享有礼等完整链路，并提供主办方专用报名表单。

### 1.1 页面与接口映射

| 页面 | 路由 | 主要功能 | 主要接口分组 |
|---|---|---|---|
| 活动列表 | `/Events/Events` | 分类筛选、关键词检索、分页、状态排序 | 3.1 |
| 活动详情 | `/Events/Detail?sceneId={SceneId}&activityId={ActivityId}` | 活动信息、场次切换、票种、报名入口、分享有礼 | 3.2、3.5 |
| 报名表单 | `/Events/Form`、`/Events/StartNewForm?activityId={ActivityId}` | 信息填写、验证码、提交报名、付费下单 | 3.3、3.4 |
| 支付页 | `/Events/Pay`、`/Events/Payment`、`/Events/Weixin` | 订单信息、支付宝/微信支付、支付回写 | 3.4 |

---

## 2. 通用约定

### 2.1 环境与基础地址

| 环境 | WebAPI | WxSpAPI |
|---|---|---|
| 生产 | `https://form.hrflag.com/WebAPI/` | `https://form.hrflag.com/WxSpAPI/` |
| 测试 | `http://demo.hrflag.com/WebAPI/` | `http://demo.hrflag.com/WxSpAPI/` |

> 前端常量见 `Scripts/Common/js/config.js`；活动图片统一为 `FilePath + ImageUrl`，`FilePath = https://hrflagfile.oss-cn-hangzhou.aliyuncs.com/`。

### 2.2 请求规范

- 主体使用 **POST**；`Departmen/*`、`PhoneInCont/*`、`FormOrder/*` 部分接口使用 **GET**（文档中逐条标注）。
- 参数编码：`application/x-www-form-urlencoded; charset=UTF-8`。
- 响应：`application/json; charset=utf-8`，无统一 `code`/`msg` 包裹。
- 无鉴权头；身份依赖 Cookie `PhoneNumber`（手机号）、`UserId`。

### 2.3 关键标识

| 标识 | 说明 |
|---|---|
| `ActivityId` | 活动主键（如 `A202107231558411`） |
| `SceneId` / `ScenceID` | 场次主键（如 `S230912585361919`）；**注意接口中拼写不一致**（`SceneId` / `ScenceID` / `ScenId` / `sceneId`） |
| `TicketId` | 票种主键 |
| `OrderNo` | 订单号 |
| `SourceId` / `SpecialId` | 渠道来源 / 特殊渠道标识 |
| `CompanyId` | 主办方公司主键 |

### 2.4 枚举值

| 枚举 | 取值 | 含义 |
|---|---|---|
| `ActivityStatus` | 0 / 1 / 2 / 3 | 全部 / 报名中 / 报名结束 / 已举办 |
| `EndSignUp` | 0 / 1 | 报名进行中 / 报名结束 |
| `IsClose` | 0 / 1 | 场次正常 / 场次关闭 |
| `IsPass` | 0 / >0 | 无需签到 / 需签到（控制地址展示粒度） |
| `ActivityCheck` | 0 / 1 / 2 | 无需审核 / 需审核 / 需扫码签到 |
| `IsShare` | 0 / 1 | 无分享有礼 / 有分享有礼 |
| `SceneTerm` | 0 / 1 / 2 | 报名即可 / 报名且审核通过 / 报名且到场 |
| `IfUserIsApply` | 0 / 1 / 2 / 3 | 未报名 / 待审核 / 审核通过 / 审核未通过 |
| `PayType` | 0 / 1 / 2 | 免费(未支付) / 微信 / 支付宝 |
| `CustomStatus` | 文本 | `无效票` 时禁止支付 |
| `PayStatus` | 文本 | `已支付` 时禁止重复支付 |

---

## 3. 接口明细

### 3.1 活动列表与筛选

#### 3.1.1 获取活动一级分类

- **用途**：渲染列表页活动分类（如"峰会/论坛/沙龙"）。
- **请求**：`POST https://form.hrflag.com/WebAPI/ActivityUser/GetAllCategory`

**请求参数**：无。

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| DeptId | string | 分类 ID；`All` 表示全部 |
| DeptName | string | 分类名称 |

**响应示例**

```json
[
  { "DeptId": "All", "DeptName": "全部" },
  { "DeptId": "C01", "DeptName": "峰会" },
  { "DeptId": "C02", "DeptName": "沙龙" }
]
```

- **调用位置**：`events.js:54`

---

#### 3.1.2 获取活动子分类

- **用途**：按一级分类获取二级分类。
- **请求**：`POST https://form.hrflag.com/WebAPI/ActivityUser/GetCategory?CategoryName={一级分类名}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| CategoryName | string | 是 | 一级分类名称（`DeptName`） |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| DeptName | string | 子分类名称 |

**响应示例**

```json
[
  { "DeptName": "人力资源峰会" },
  { "DeptName": "薪酬福利论坛" }
]
```

- **调用位置**：`events.js:90`

---

#### 3.1.3 获取活动类型

- **用途**：渲染活动类型筛选项（如"线下/线上/直播"）。
- **请求**：`POST https://form.hrflag.com/WebAPI/ActivityUser/GetAllActivityType`

**请求参数**：无。

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| DeptName | string | 类型名称 |

**响应示例**

```json
[
  { "DeptName": "线下活动" },
  { "DeptName": "线上直播" }
]
```

- **调用位置**：`events.js:115`

---

#### 3.1.4 活动列表

- **用途**：按标题、分类、类型、状态、排序分页查询活动，列表页与总数统计共用。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/GetActivityListTwo`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| ActivityTitle | string | 否 | 活动标题关键词，来自 URL 参数 `name` |
| ActivityCategory | string | 否 | 一级分类名称，来自 URL 参数 `className` |
| ActivityCateChild | string | 否 | 二级分类名称，来自 URL 参数 `categoryName` |
| Type | string | 否 | 活动类型名称，来自 URL 参数 `typename` |
| ActivityStatus | int | 否 | 0 全部 / 1 报名中 / 2 报名结束 / 3 已举办，来自 `state` |
| Desc | int | 否 | 排序：1 最新发布，来自 `sort` |
| Page | int | 是 | 页码，从 1 开始 |
| Limit | int | 是 | 每页条数 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| count | int | 总条数 |
| data | array | 活动列表 |
| data[].SceneId | string | 场次 ID，用于详情页 `sceneId` |
| data[].ActivityId | string | 活动 ID，用于详情页 `activityId` |
| data[].ActivityTitle | string | 活动标题 |
| data[].ActivitySponsor | string | 主办方 |
| data[].ActivityStatus | string | 状态文案（报名中/报名结束/已举办） |
| data[].EndSignUp | int | 1 表示报名已结束 |
| data[].Free | string | `"免费"` 或空 |
| data[].MinTicketPrice / MaxTicketPrice | decimal | 票种价格区间 |
| data[].CityName | string | 城市，`在线` 表示线上 |
| data[].LiveLink | string | 直播地址，可空 |
| data[].ImageUrl | string | 封面图相对路径 |
| data[].PageView | int | 浏览量 |
| data[].PlaceName | string | 站点名称（如"上海"），`在线` 时为空 |
| data[].ActivitySceneInfo | array | 场次摘要列表 |
| data[].ActivitySceneInfo[].CountryName | string | 国家/地区，`线上直播` 表示线上 |
| data[].ActivitySceneInfo[].WhatDay | string | 星期文案 |
| data[].ActivitySceneInfo[].SceneBeginDate | string | 开始时间 |
| data[].ActivitySceneInfo[].SceneEndDate | string | 结束时间 |
| data[].ActivitySceneInfo[].CityName | string | 城市 |
| data[].ActivitySceneInfo[].Address | string | 详细地址 |

**响应示例**

```json
{
  "count": 86,
  "data": [
    {
      "SceneId": "S230912585361919",
      "ActivityId": "A20261101001",
      "ActivityTitle": "2026 中国人力资源峰会",
      "ActivitySponsor": "HRflag 众旗",
      "ActivityStatus": "报名中",
      "EndSignUp": 0,
      "Free": "",
      "MinTicketPrice": 680,
      "MaxTicketPrice": 1280,
      "CityName": "上海",
      "LiveLink": "",
      "ImageUrl": "uploadimage/activity/cover2026.jpg",
      "PageView": 15230,
      "PlaceName": "上海",
      "ActivitySceneInfo": [
        {
          "CountryName": "中国",
          "WhatDay": "周五",
          "SceneBeginDate": "2026-12-05 09:00:00",
          "SceneEndDate": "2026-12-05 17:00:00",
          "CityName": "上海",
          "Address": "上海市静安区某酒店三层宴会厅"
        }
      ]
    }
  ]
}
```

- **调用位置**：`events.js:222`、`events.js:318`

---

### 3.2 活动详情与场次

#### 3.2.1 活动详情（含场次与票种）

- **用途**：详情页主数据源，返回活动基础信息、场次列表与票种列表。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/GetHRflagActivityByIdNewShow?SceneId={SceneId}&unfold={0|1}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| SceneId | string | 是 | 场次 ID（页面参数 `sceneId`） |
| unfold | int | 否 | 0 默认展示首个场次；1 展开全部场次（点击"查看更多场次"时传 1） |

**响应字段**（数组，取 `[0]`）

| 字段名 | 类型 | 说明 |
|---|---|---|
| ActivityId | string | 活动 ID |
| ActivityTitle | string | 活动标题 |
| ActivitySponsor | string | 主办方 |
| ActivityCheck | int | 0 无需审核 / 1 需审核 / 2 需扫码签到 |
| ActivityBright | string | 活动亮点（HTML） |
| MainBody | string | 活动内容（HTML） |
| ImageUrl | string | 封面图相对路径 |
| PageView | int | 浏览量 |
| EndNorm | int | 报名截止基准：0 按开始时间 / 1 按结束时间 |
| CompanyId | string | 主办方公司 ID，用于查询隐私政策模板 |
| CountSum | int | 场次总数 |
| SceneInfoList | array | 场次列表 |
| SceneInfoList[].SceneId | string | 场次 ID |
| SceneInfoList[].SceneName | string | 场次名称（如"上海"、"在线"） |
| SceneInfoList[].SceneBeginDate | string | 开始时间 |
| SceneInfoList[].SceneEndDate | string | 结束时间 |
| SceneInfoList[].IsClose | int | 1 场次已关闭 |
| SceneInfoList[].EndSignUp | int | 1 报名结束 |
| SceneInfoList[].TicketInfoList | array | 票种列表 |
| SceneInfoList[].TicketInfoList[].TicketId | string | 票种 ID |
| SceneInfoList[].TicketInfoList[].TicketName | string | 票种名称 |
| SceneInfoList[].TicketInfoList[].TicketPrice | decimal | 票价（0 表示免费） |
| SceneInfoList[].TicketInfoList[].Remarks | string | 票种说明 |

**响应示例**

```json
[
  {
    "ActivityId": "A20261101001",
    "ActivityTitle": "2026 中国人力资源峰会",
    "ActivitySponsor": "HRflag 众旗",
    "ActivityCheck": 1,
    "ActivityBright": "<p>30+ 主题演讲</p>",
    "MainBody": "<p>聚焦组织效能与人才战略。</p>",
    "ImageUrl": "uploadimage/activity/cover2026.jpg",
    "PageView": 15230,
    "EndNorm": 0,
    "CompanyId": "193c6d87136e4267a74eed8c492daec5",
    "CountSum": 2,
    "SceneInfoList": [
      {
        "SceneId": "S230912585361919",
        "SceneName": "上海",
        "SceneBeginDate": "2026-12-05 09:00:00",
        "SceneEndDate": "2026-12-05 17:00:00",
        "IsClose": 0,
        "EndSignUp": 0,
        "TicketInfoList": [
          { "TicketId": "T001", "TicketName": "标准票", "TicketPrice": 680, "Remarks": "含午餐" },
          { "TicketId": "T002", "TicketName": "VIP票", "TicketPrice": 1280, "Remarks": "含前排席位" }
        ]
      }
    ]
  }
]
```

- **调用位置**：`codetail.js:812`、`Form.js:235`、`NewForm.js:338`、`StartNewForm.js` 同族

---

#### 3.2.2 场次详情

- **用途**：获取指定场次的时间、地点、签到要求与分享配置。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/GetSceneInfoNew?SceneID={SceneId}&phone={Phone}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| SceneID | string | 是 | 场次 ID |
| phone | string | 否 | 当前手机号；未登录传 `''`（两个单引号） |

**响应字段**（数组，取 `[0]`）

| 字段名 | 类型 | 说明 |
|---|---|---|
| SceneName | string | 场次名称 |
| SceneCounty | string | 国家/地区 |
| ScenePlace | string | 场地名称 |
| AttendPlace | string | 详细地址（`IsPass>0` 时返回） |
| TimeInterval | string | 时间区间文案 |
| IsPass | int | >0 表示需签到 |
| IsShare | int | 1 表示有分享有礼 |

**响应示例**

```json
[
  {
    "SceneName": "上海",
    "SceneCounty": "中国",
    "ScenePlace": "静安某酒店",
    "AttendPlace": "上海市静安区某路 1 号",
    "TimeInterval": "2026-12-05 09:00 ~ 17:00",
    "IsPass": 1,
    "IsShare": 1
  }
]
```

- **调用位置**：`codetail.js:908`

---

#### 3.2.3 查询当前用户报名状态

- **用途**：决定详情页展示"立即报名 / 待审核 / 已通过 / 未通过"。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/IfUserIsApply?sceneId={SceneId}&phone={Phone}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| sceneId | string | 是 | 场次 ID |
| phone | string | 是 | 当前手机号；未登录传 `''` |

**响应字段**：标量 `int`，`0` 未报名 / `1` 待审核 / `2` 审核通过 / `3` 审核未通过。

**响应示例**

```json
2
```

- **调用位置**：`codetail.js:938`

---

#### 3.2.4 活动基础信息

- **用途**：获取活动类型、审核方式等基础配置，用于表单分支判断。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/GetHRflagActivityByIdNew?SceneId={SceneId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| SceneId | string | 是 | 场次 ID |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| ActivityCheck | int | 审核方式 |
| ActivityType | int | 活动类型 ID |
| ActivityTypeName | string | 活动类型名称 |

**响应示例**

```json
[{ "ActivityCheck": 1, "ActivityType": 3, "ActivityTypeName": "线下峰会" }]
```

- **调用位置**：`codetail.js:1574`、`Form.js:1078`、`NewForm.js:1251`

---

#### 3.2.5 主办方隐私政策

- **用途**：返回活动关联的授权公司列表，用于渲染隐私政策链接。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/ComPrivacy?ActivityId={SceneId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| ActivityId | string | 是 | 当前前端传入的是 `sceneId`（沿用原参数名） |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| CompanyId | string | 公司 ID，用于拼接隐私条款链接 |
| CompanyName | string | 公司全称 |
| EnAbbreviation | string | 公司简称（优先展示） |

**响应示例**

```json
[
  {
    "CompanyId": "193c6d87136e4267a74eed8c492daec5",
    "CompanyName": "众旗人力资源（上海）有限公司",
    "EnAbbreviation": "HRflag"
  }
]
```

- **调用位置**：`codetail.js:870`、`Form.js:300`、`NewForm.js:418`

---

#### 3.2.6 隐私政策模板文本

- **用途**：按主办方公司获取隐私授权声明模板。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/ProjectList/DataIdToTemplate?type=2&dataId={CompanyId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| type | int | 是 | 固定 2 |
| dataId | string | 是 | 主办方 `CompanyId` |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| BeginText | string | 授权声明 HTML 片段 |

**响应示例**

```json
{ "BeginText": "本人同意主办方将上述信息用于本次活动报名与联络。" }
```

- **调用位置**：`codetail.js:852`、`Form.js:280`、`NewForm.js:393`

---

#### 3.2.7 分享有礼配置

- **用途**：获取场次的分享有礼规则与奖品档位。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/ActivitiesShare/WxSelectActivityShare`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| ScenId | string | 是 | 场次 ID |

**响应字段**（数组，取 `[0]`）

| 字段名 | 类型 | 说明 |
|---|---|---|
| BeginDate | string | 活动开始时间（ISO 格式，前端截取 `T` 前部分） |
| EndDate | string | 活动结束时间 |
| SceneTerm | int | 0 报名即可 / 1 报名且审核通过 / 2 报名且到场 |
| ActivityPresent | string | 奖品说明 |
| ActivityRuleA | string | 规则说明 |
| BeginWeekDay / EndWeekDay | string | 起止星期文案 |
| PeopleCount | int | 奖品所需邀请人数 |
| SuccessCount | int | 已完成人数 |
| PriceImg | string | 奖品图片相对路径（拼 `WXAPIPath`） |
| Pricename | string | 奖品名称 |
| ActivityPrizesInfoList | array | 奖品档位列表，字段同上 |

**响应示例**

```json
[
  {
    "BeginDate": "2026-11-01T00:00:00",
    "EndDate": "2026-12-05T23:59:59",
    "SceneTerm": 1,
    "ActivityPresent": "邀请好友报名，赢取定制礼品。",
    "ActivityRuleA": "被邀请人需完成报名并审核通过。",
    "BeginWeekDay": "周日",
    "EndWeekDay": "周六",
    "PeopleCount": 3,
    "SuccessCount": 1,
    "PriceImg": "WxActivity/prize1.png",
    "Pricename": "定制笔记本",
    "ActivityPrizesInfoList": [
      {
        "PeopleCount": 3,
        "SuccessCount": 1,
        "PriceImg": "WxActivity/prize1.png",
        "Pricename": "定制笔记本"
      }
    ]
  }
]
```

- **调用位置**：`codetail.js:975`、`Form.js:343`、`alipay.js:149`

---

#### 3.2.8 热门活动

- **用途**：详情页"热门活动"推荐。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/GetHotActivityDetail?count={count}&ScenceID={SceneId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| count | int | 是 | 返回条数，前端固定 7 |
| ScenceID | string | 否 | 当前场次 ID，用于排除 |

**响应字段**：`SceneId`、`ActivityId`、`ActivityTitle`、`ActivitySponsor`、`ImageUrl`、`ActivityTicketCheck`、`PageView`、`Weekness`、`SceneBeginDate`、`CityName`。

**响应示例**

```json
[
  {
    "SceneId": "S230912585361920",
    "ActivityId": "A20261101002",
    "ActivityTitle": "2026 薪酬福利论坛",
    "ActivitySponsor": "HRflag 众旗",
    "ImageUrl": "uploadimage/activity/cover2.jpg",
    "ActivityTicketCheck": "报名中",
    "PageView": 8210,
    "Weekness": "周四",
    "SceneBeginDate": "2026-11-26 13:30:00",
    "CityName": "北京"
  }
]
```

- **调用位置**：`codetail.js:510`

---

#### 3.2.9 最新活动

- **用途**：详情页"最新活动"推荐。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/GetNewActivityDetail?count={count}&ScenceId={SceneId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| count | int | 是 | 返回条数，前端固定 7 |
| ScenceId | string | 否 | 当前场次 ID，用于排除 |

**响应字段**：同 3.2.8。

**响应示例**

```json
[
  {
    "SceneId": "S230912585361921",
    "ActivityId": "A20261102001",
    "ActivityTitle": "2026 组织发展沙龙",
    "ActivitySponsor": "HRflag 众旗",
    "ImageUrl": "uploadimage/activity/cover3.jpg",
    "ActivityTicketCheck": "报名中",
    "PageView": 3201,
    "Weekness": "周六",
    "SceneBeginDate": "2026-12-12 14:00:00",
    "CityName": "深圳"
  }
]
```

- **调用位置**：`codetail.js:547`

---

### 3.3 报名与用户信息

#### 3.3.1 发送短信验证码（报名）

- **用途**：报名表单手机号验证，发送 6 位验证码。
- **请求**：`POST https://form.hrflag.com/WebAPI/Form/GetVF`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `""`（空名参数） | string | 是 | 手机号，前端以空键名提交 |

> 另有 `Form/GetYLVF`、`Form/GetMKVF` 为特定活动（医疗/迈肯锡）专用验证码接口，参数相同。

**响应字段**：无业务数据。

**响应示例**

```json
null
```

- **调用位置**：`codetail.js:1277`、`Form.js:760`、`NewForm.js:917`、`StartNewForm.js:575`

---

#### 3.3.2 校验短信验证码

- **用途**：校验手机号与验证码是否匹配。
- **请求**：`POST https://form.hrflag.com/WebAPI/Form/CheckVFCode`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| PhoneNumber | string | 是 | 手机号 |
| MsgCode | string | 是 | 6 位验证码 |

**响应字段**：标量 `bool`，`true` 校验通过。

**响应示例**

```json
true
```

- **调用位置**：`codetail.js:1320`、`Form.js:803`、`NewForm.js:960`

---

#### 3.3.3 手机号获取用户资料

- **用途**：表单中按手机号回填姓名、公司、职位等信息。
- **请求**：`POST https://form.hrflag.com/WebAPI/NewForm/GetUser?phone={Phone}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| phone | string | 是 | 手机号（QueryString） |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| Name | string | 姓名 |
| Company | string | 公司 |
| TradName | string | 行业 |
| Department | string | 部门 |
| Position | string | 职位 |
| Email | string | 邮箱 |

**响应示例**

```json
{
  "Name": "王睿",
  "Company": "众旗人力资源（上海）有限公司",
  "TradName": "人力资源服务",
  "Department": "人力资源部",
  "Position": "HRD",
  "Email": "example@hrflag.com"
}
```

- **调用位置**：`codetail.js:1352`、`Form.js:835`、`NewForm.js:992`、`StartNewForm.js:650`

---

#### 3.3.4 获取登录用户信息

- **用途**：报名成功后写 Cookie 所需的用户信息。
- **请求**：`POST https://form.hrflag.com/WebAPI/System/GetUserInfo`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| PhoneNumber | string | 是 | 手机号 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| Success | string | 状态码 |
| UserOutput | object | 用户对象，含 `UserId`、`Name`、`PhoneNumber`、`Email`、`Company`、`Department`、`Position`、`TradeName` |

**响应示例**

```json
{
  "Success": "3",
  "UserOutput": {
    "UserId": "8f2c1a6e-3b7d-4c11-9a02-7d1f5e6b8c33",
    "Name": "王睿",
    "PhoneNumber": "13800000000",
    "Email": "example@hrflag.com",
    "Company": "众旗人力资源（上海）有限公司",
    "Department": "人力资源部",
    "Position": "HRD",
    "TradeName": "人力资源服务"
  }
}
```

- **调用位置**：`codetail.js:2487`、`Form.js:2407`、`StartNewForm.js:2214`

---

#### 3.3.5 用户注册

- **用途**：未注册手机号在报名时同步注册主站账号。
- **请求**：`POST https://form.hrflag.com/WebAPI/Form/UserRegister`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| PhoneNumber | string | 是 | 手机号 |
| Name | string | 是 | 姓名 |
| Company | string | 是 | 公司 |
| Department | string | 否 | 部门 |
| Position | string | 否 | 职位 |
| Email | string | 否 | 邮箱 |
| TradName | string | 否 | 行业 |
| SceneId | string | 否 | 场次 ID（仅特定活动 `S230912585361919` 传值） |
| Comefrom | string | 是 | 固定 `"活动报名"` |

**响应字段**：`Success`、`UserOutput`（结构同 3.3.4）。

**响应示例**

```json
{ "Success": "3", "UserOutput": { "UserId": "8f2c1a6e-3b7d-4c11-9a02-7d1f5e6b8c33" } }
```

- **调用位置**：`codetail.js:2458`、`Form.js:2377`、`NewForm.js:2683`

---

#### 3.3.6 更新用户资料

- **用途**：报名信息与主站资料不一致时回写用户表。
- **请求**：`POST https://form.hrflag.com/WebAPI/NewForm/UpdateUserByPhone`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| PhoneNo | string | 是 | 手机号 |
| Name | string | 是 | 姓名 |
| Company | string | 是 | 公司 |
| Industry | string | 否 | 行业 |
| Position | string | 否 | 职位 |
| Department | string | 否 | 部门 |
| Email | string | 否 | 邮箱 |
| Comefrom | string | 否 | 固定 `"活动报名"` |
| SceneId | string | 否 | 场次 ID（仅特定活动传值） |
| PhoneIn | string | 否 | 手机号归属地 |

**响应字段**：标量 `bool`，`true` 更新成功。

**响应示例**

```json
true
```

- **调用位置**：`codetail.js:2149`、`Form.js:1697`、`StartNewForm.js:1533`

---

#### 3.3.7 提交报名（标准表单）

- **用途**：提交活动报名信息，返回是否成功。
- **请求**：`POST https://form.hrflag.com/WebAPI/NewForm/AddCustomerAllInfo`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| PhoneNo | string | 是 | 手机号 |
| Name | string | 是 | 姓名 |
| ActivityId | string | 是 | 活动 ID |
| SceneId | string | 是 | 场次 ID |
| Company | string | 是 | 公司 |
| Industry | string | 否 | 行业 |
| Position | string | 否 | 职位 |
| Department | string | 否 | 部门 |
| Email | string | 否 | 邮箱 |
| Comefrom | string | 是 | 固定 `"活动报名"` |
| PhoneIn | string | 否 | 手机号归属地 |
| City | string | 否 | 公司所在城市，格式 `省,市,区(区/县)` |
| CompanySize | string | 否 | 公司规模（特定活动必填） |

**响应字段**：标量 `bool`，`true` 表示报名提交成功。

**响应示例**

```json
true
```

- **调用位置**：`StartNewForm.js:1504`

---

#### 3.3.8 提交报名（动态表单）

- **用途**：主办方自定义报名表单提交，支持项目/赛道/推荐人等扩展字段。
- **请求**：`POST https://form.hrflag.com/WebAPI/NewForm/AddCustomerInfoTwo`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| PhoneNo | string | 是 | 手机号 |
| Name | string | 是 | 姓名 |
| ActivityId | string | 是 | 活动 ID |
| SceneId | string | 是 | 场次 ID；未选场次时前端传勾选文案（历史遗留） |
| Company | string | 是 | 公司 |
| Industry | string | 否 | 行业 |
| Position | string | 否 | 职位 |
| Department | string | 否 | 部门 |
| Email | string | 否 | 邮箱 |
| Comefrom | string | 是 | 固定 `"活动报名"` |
| PhoneIn | string | 否 | 手机号归属地 |
| ProjectName | string | 否 | 项目名称 |
| TrackName | string | 否 | 赛道名称 |
| ReferenceName | string | 否 | 推荐人 |
| IPAddress | string | 否 | IP 归属地 |
| IPAttac | string | 否 | IP 地址 |
| JsonStr | string | 否 | 自定义题目的 JSON 字符串 |
| CompanyId | string | 否 | 公司 ID |
| Source | string | 否 | 渠道来源 ID |

**响应字段**：标量 `bool`，`true` 表示提交成功。

**响应示例**

```json
true
```

- **调用位置**：`StartNewForm.js:1592`

---

#### 3.3.9 提交报名（旧版入口）

- **用途**：旧版详情页/表单页的报名入口，逻辑同 3.3.8 的子集。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/AddCustomerInfo`

**请求参数**：`PhoneNo`、`Name`、`ActivityId`、`SceneId`、`Company`、`Industry`、`Position`、`Department`、`Email`、`Comefrom`、`PhoneIn`。

**响应字段**：标量 `bool`。

**响应示例**

```json
true
```

- **调用位置**：`codetail.js:2098`、`Form.js:1606`

---

#### 3.3.10 提交报名（医疗行业专用）

- **用途**：医疗行业活动专用报名提交（附加字段由后端固定）。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/AddYLCustomerInfo`

**请求参数**：同 3.3.9。

**响应字段**：标量 `bool`。

**响应示例**

```json
true
```

- **调用位置**：`Form.js:1990`、`NewForm.js:2294`

---

#### 3.3.11 校验是否已报名（手机号维度）

- **用途**：提交前判断该手机号是否已报名当前场次，避免重复报名。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/CheckUserRegist`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| SceneId | string | 是 | 场次 ID |
| PhoneNo | string | 是 | 手机号 |

**响应字段**：数组，空数组表示未报名；有值表示已报名（含 `TicketPrice`、`LiveLink` 等）。

**响应示例**

```json
[]
```

- **调用位置**：`Form.js:2116`、`NewForm.js:2422`

---

#### 3.3.12 订单校验（当前场次）

- **用途**：判断当前手机号在本场次是否存在有效订单，用于跳转支付或提示已报名。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/CheckUserOrder`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| SceneId | string | 是 | 场次 ID |
| PhoneNo | string | 是 | 手机号 |
| ActivityId | string | 否 | 活动 ID |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| TicketPrice | decimal | 应付金额 |
| LiveLink | string | 直播地址（已报名且为线上活动时返回） |
| LiveToLink | string | 直播跳转地址 |

**响应示例**

```json
[{ "TicketPrice": 680, "LiveLink": "", "LiveToLink": "" }]
```

- **调用位置**：`codetail.js:2224`、`Form.js:2093`

---

#### 3.3.13 订单校验（跨场次/跨活动）

- **用途**：判断同一手机号是否已报名其他场次，处理换场或重复报名。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/CheckUserDifOrder`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| SceneId | string | 是 | 目标场次 ID |
| PhoneNo | string | 是 | 手机号 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| TicketPrice | decimal | 金额 |
| SourceId | string | 渠道 ID |
| SourceName | string | 渠道名称 |
| LiveLink | string | 直播地址 |

**响应示例**

```json
[{ "TicketPrice": 680, "SourceId": "A0001", "SourceName": "官网", "LiveLink": "" }]
```

- **调用位置**：`Form.js:2135`、`codetail.js:2246`

---

#### 3.3.14 按订单号查询报名人

- **用途**：支付前后查询订单对应的报名人信息与金额。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/GetCustomerByNo?OrderNo={OrderNo}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OrderNo | string | 是 | 订单号 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| TicketPrice | decimal | 金额 |
| SourceId | string | 渠道 ID |
| LiveLink | string | 直播地址 |

**响应示例**

```json
[{ "TicketPrice": 680, "SourceId": "A0001", "LiveLink": "" }]
```

- **调用位置**：`codetail.js:2270`、`Form.js:2158`

---

#### 3.3.15 查询签到记录

- **用途**：主办方表单页判断用户是否已签到。
- **请求**：`POST https://form.hrflag.com/WebAPI/NewForm/CheckCustomSignIn?ActivityId={ActivityId}&SceneId={SceneId}&PhoneNo={Phone}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| ActivityId | string | 是 | 活动 ID |
| SceneId | string | 是 | 场次 ID |
| PhoneNo | string | 是 | 手机号 |

**响应字段**：数组，非空表示已签到。

**响应示例**

```json
[{ "PhoneNo": "13800000000", "SignInTime": "2026-12-05 09:12:00" }]
```

- **调用位置**：`StartNewForm.js:1716`

---

#### 3.3.16 查询表单报名记录

- **用途**：按表单（活动）与手机号判断是否已提交报名。
- **请求**：`POST https://form.hrflag.com/WebAPI/NewForm/IsFormSignUp?FormId={ActivityId}&Phone={Phone}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| FormId | string | 是 | 表单 ID（即活动 ID） |
| Phone | string | 是 | 手机号 |

**响应字段**：数组，非空表示已报名。

**响应示例**

```json
[{ "Id": "f1e2d3c4" }]
```

- **调用位置**：`StartNewForm.js:1730`

---

#### 3.3.17 线上留资查询

- **用途**：查询用户在某场次的线上留资记录。
- **请求**：`POST https://form.hrflag.com/WebAPI/OnlineSpoor/GetCustomerInfo?SceneId={SceneId}&PhoneNo={Phone}&Status=0`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| SceneId | string | 是 | 场次 ID |
| PhoneNo | string | 是 | 手机号 |
| Status | int | 是 | 固定 0 |

**响应字段**：数组，非空表示已有留资。

**响应示例**

```json
[{ "PhoneNo": "13800000000", "CreateTime": "2026-11-10 10:00:00" }]
```

- **调用位置**：`codetail.js:2410`、`Form.js:2319`

---

#### 3.3.18 写入线上留资

- **用途**：报名成功后写入线上留资记录（用于线索归集）。
- **请求**：`POST https://form.hrflag.com/WebAPI/OnlineSpoor/AddOnlineSpoor`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| SceneId | string | 是 | 场次 ID |
| PhoneNo | string | 是 | 手机号 |
| PhoneNoIn | string | 否 | 归属地，默认空串 |
| CreateTime | string | 否 | 默认空串，由后端生成 |
| Remarks | string | 否 | 备注，默认空串 |

**响应字段**：无业务数据。

**响应示例**

```json
null
```

- **调用位置**：`codetail.js:2430`、`Form.js:2350`、`StartNewForm.js:1697`

---

#### 3.3.19 部门字典

- **用途**：报名表单"部门"下拉数据。
- **请求**：`GET https://form.hrflag.com/WebAPI/Departmen/GetAllDepart`

**请求参数**：无。

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| data | array | 部门列表 |
| data[].DepartmentName | string | 部门名称 |
| data[].TradeName | string | 所属行业 |

**响应示例**

```json
{ "data": [{ "DepartmentName": "人力资源部", "TradeName": "人力资源服务" }] }
```

- **调用位置**：`codetail.js:1197`、`Form.js:2526`、`StartNewForm.js:1795`

---

#### 3.3.20 行业字典

- **用途**：报名表单"行业"下拉数据。
- **请求**：`GET https://form.hrflag.com/WebAPI/Departmen/GetAllTradeInfo`

**请求参数**：无。

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| data | array | 行业列表 |
| data[].TradeName | string | 行业名称 |

**响应示例**

```json
{ "data": [{ "TradeName": "人力资源服务" }, { "TradeName": "制造业" }] }
```

- **调用位置**：`codetail.js:1212`、`Form.js:2543`、`StartNewForm.js:1817`

---

#### 3.3.21 高校专用字典（迈肯锡表单）

- **用途**：特定主办方表单的院系 / 学校 / 职位 / 行业下拉。
- **请求**：

| 接口 | 方法 | 路径 |
|---|---|---|
| 院系 | GET | `WebAPI/Activity/SchoolDepartmentn` |
| 学校 | GET | `WebAPI/Activity/SchoolCompany` |
| 职位 | GET | `WebAPI/Activity/SchoolPosition` |
| 行业 | GET | `WebAPI/Activity/Schoolindustry` |

**请求参数**：无。

**响应字段**：数组，元素字段由后端字典表定义（前端仅取名称渲染）。

**响应示例**

```json
["商学院", "法学院", "计算机学院"]
```

- **调用位置**：`Form.js:2558`~`Form.js:2591`

---

#### 3.3.22 手机号归属地

- **用途**：报名时补充手机号归属地、校验号段。
- **请求**：`GET https://form.hrflag.com/WebAPI/PhoneInCont/GetPhoneIn?Phone={Phone}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| Phone | string | 是 | 手机号 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| data.sp | string | 运营商 |
| data.province | string | 省份 |
| data.city | string | 城市 |

**响应示例**

```json
{ "data": { "sp": "移动", "province": "上海", "city": "上海" } }
```

- **调用位置**：`codetail.js:2653`、`Form.js:2509`、`StartNewForm.js:1488`

---

#### 3.3.23 生成活动二维码

- **用途**：生成活动分享/签到二维码并落库。
- **请求**：`POST https://form.hrflag.com/WebAPI/ImageFile/AddQRinfo?url={url}&nid={ActivityId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| url | string | 是 | 二维码跳转地址（需 URL 编码） |
| nid | string | 是 | 活动 ID |

**响应字段**：标量 `string`，二维码图片相对路径。

**响应示例**

```json
"QRCode/20261117/act20261101001.png"
```

- **调用位置**：`codetail.js:2673`

---

#### 3.3.24 手机号扫码绑定

- **用途**：生成"手机号绑定"小程序码 / 判断是否已绑定。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/UserInfo/SelectPhoneScan`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OpenId | string | 是 | 手机号或 `SceneId_3`（报名页绑定场景） |
| KindId | int | 是 | 业务大类：2 报名签到 / 5 分享 |
| ContentId | int | 是 | 业务子类：12 报名 / 13 表单绑定 / 16、17 分享图 |

**响应字段**：标量 `string`，小程序码相对路径（拼 `WXAPIPath`）；无数据时返回空。

**响应示例**

```json
"WxActivity/phone_scan_20261117.jpg"
```

- **调用位置**：`codetail.js:2805`、`Form.js:2773`、`StartNewForm.js:3064`

---

### 3.4 支付与订单

#### 3.4.1 查询表单是否需购买

- **用途**：判断当前活动是否为付费活动，决定是否创建订单。
- **请求**：`GET https://form.hrflag.com/WebAPI/FormOrder/IfFormIsBuy?activityId={ActivityId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| activityId | string | 是 | 活动 ID |

**响应字段**：数组/布尔，非空或 `true` 表示需付费。

**响应示例**

```json
[{ "ActivityId": "A20261101001", "IsBuy": 1 }]
```

- **调用位置**：`StartNewForm.js:2060`

---

#### 3.4.2 查询收货地址

- **用途**：付费活动（含实物）报名时获取用户收货地址。
- **请求**：`GET https://form.hrflag.com/WebAPI/FormOrder/GetTakeDeliveryInfo?phone={Phone}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| phone | string | 是 | 手机号 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| Id | string | 地址 ID，下单时传 `TakeDeliveryInfoId` |
| Name | string | 收件人 |
| Phone | string | 收件电话 |
| Region | string | 省市区 |
| AddressTxt | string | 详细地址 |

**响应示例**

```json
[
  {
    "Id": "addr-001",
    "Name": "王睿",
    "Phone": "13800000000",
    "Region": "上海市/上海市/静安区",
    "AddressTxt": "某路 1 号 101 室"
  }
]
```

- **调用位置**：`StartNewForm.js:1976`

---

#### 3.4.3 生成订单号

- **用途**：支付前生成唯一订单号。
- **请求**：`GET https://form.hrflag.com/WxSpAPI/MicroLesson/GetOrderNo`

**请求参数**：无。

**响应字段**：标量 `string`，订单号。

**响应示例**

```json
"202611171030120001"
```

- **调用位置**：`StartNewForm.js:2090`

---

#### 3.4.4 创建表单订单

- **用途**：报名信息提交成功后创建支付订单。
- **请求**：`GET https://form.hrflag.com/WebAPI/FormOrder/AddFormOrderInfo`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OrderMark | string | 是 | 订单号（由 3.4.3 生成） |
| ActivityID | string | 是 | 活动 ID |
| Phone | string | 是 | 手机号 |
| PayType | int | 是 | 0 未支付 / 1 微信 / 2 支付宝 |
| IP | string | 否 | 客户端 IP |
| IPAddress | string | 否 | IP 归属地 |
| Price | decimal | 是 | 订单金额 |
| TakeDeliveryInfoId | string | 否 | 收货地址 ID，无则传全零 GUID |
| JsonStr | string | 否 | 票种/数量等扩展信息 JSON |

**响应字段**：`Success`、`UserOutput`。

**响应示例**

```json
{ "Success": "3", "UserOutput": { "OrderNo": "202611171030120001" } }
```

- **调用位置**：`StartNewForm.js:2148`

---

#### 3.4.5 查询是否免支付

- **用途**：判断该活动对该用户是否走免支付流程（0 元票）。
- **请求**：`GET https://form.hrflag.com/WebAPI/FormOrder/IfIsNoPayment?activityId={ActivityId}&phone={Phone}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| activityId | string | 是 | 活动 ID |
| phone | string | 是 | 手机号 |

**响应字段**：标量 `bool`，`true` 表示免支付。

**响应示例**

```json
false
```

- **调用位置**：`StartNewForm.js:2179`

---

#### 3.4.6 更新支付时间

- **用途**：支付完成后回写支付时间。
- **请求**：`GET https://form.hrflag.com/WebAPI/FormOrder/UpdatePayTime?order={OrderNo}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| order | string | 是 | 订单号 |

**响应字段**：无业务数据。

**响应示例**

```json
null
```

- **调用位置**：`StartNewForm.js:2102`

---

#### 3.4.7 刷新订单状态

- **用途**：支付页加载时触发订单状态刷新（支付回调兜底）。
- **请求**：`POST https://form.hrflag.com/WebAPI/NewForm/BulkUpdatesFormOrderNew?OrderNo={OrderNo}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OrderNo | string | 是 | 订单号 |

**响应字段**：无业务数据。

**响应示例**

```json
null
```

- **调用位置**：`alipay.js:24`

---

#### 3.4.8 获取订单详情

- **用途**：支付页展示订单、活动、票种、金额与支付状态。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/GetCustomOrder?OrderNo={OrderNo}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OrderNo | string | 是 | 订单号 |

**响应字段**（数组，取 `[0]`）

| 字段名 | 类型 | 说明 |
|---|---|---|
| Name | string | 报名人姓名 |
| PhoneNo | string | 手机号 |
| Email | string | 邮箱 |
| ActivityTitle | string | 活动标题 |
| ImageUrl | string | 活动封面 |
| Date | string | 活动时间文案 |
| Place | string | 活动地点 |
| CountryName | string | 城市/国家 |
| TicketName | string | 票种名称 |
| TicketPrice | decimal | 单价 |
| PurchaseSum | int | 购买数量 |
| PayStatus | string | 支付状态（`已支付` 时禁止重复支付） |
| CustomStatus | string | 订单状态（`无效票` 时禁止支付） |
| SourceId | string | 渠道 ID |
| SceneId | string | 场次 ID |
| IsShare | int | 是否有分享有礼 |

**响应示例**

```json
[
  {
    "Name": "王睿",
    "PhoneNo": "13800000000",
    "Email": "example@hrflag.com",
    "ActivityTitle": "2026 中国人力资源峰会",
    "ImageUrl": "uploadimage/activity/cover2026.jpg",
    "Date": "2026-12-05 09:00 ~ 17:00",
    "Place": "上海 · 静安某酒店",
    "CountryName": "中国",
    "TicketName": "标准票",
    "TicketPrice": 680,
    "PurchaseSum": 1,
    "PayStatus": "未支付",
    "CustomStatus": "有效票",
    "SourceId": "A0001",
    "SceneId": "S230912585361919",
    "IsShare": 1
  }
]
```

- **调用位置**：`alipay.js:47`

---

#### 3.4.9 获取场次地图信息

- **用途**：支付页展示参会地点地图。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/GetActivityInfoMap?SceneId={SceneId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| SceneId | string | 是 | 场次 ID |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| ActivityTitle | string | 活动标题 |
| CityName | string | 城市（`在线`/`在线直播` 时隐藏地图） |
| CountryName | string | 国家 |
| ScenePlace | string | 场地 |
| AttendPlace | string | 详细地址 |
| SceneBeginDate / SceneEndDate | string | 起止时间 |
| Schedule | string | 日程 |
| ActivityCheck | int | 审核方式 |

**响应示例**

```json
[
  {
    "ActivityTitle": "2026 中国人力资源峰会",
    "CityName": "上海",
    "CountryName": "中国",
    "ScenePlace": "静安某酒店",
    "AttendPlace": "上海市静安区某路 1 号",
    "SceneBeginDate": "2026-12-05 09:00:00",
    "SceneEndDate": "2026-12-05 17:00:00",
    "Schedule": "09:00 签到",
    "ActivityCheck": 1
  }
]
```

- **调用位置**：`alipay.js:93`

---

#### 3.4.10 支付宝支付回写

- **用途**：支付宝支付成功后回写订单支付状态。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/RecordAliPay?OrderNo={OrderNo}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OrderNo | string | 是 | 订单号 |

**响应字段**：无业务数据；成功后前端重新拉取 3.4.8 校验 `PayStatus`。

**响应示例**

```json
null
```

- **调用位置**：`alipay.js:253`

---

#### 3.4.11 微信支付回写

- **用途**：微信支付成功后回写订单支付状态。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/RecordWxPay?OrderNo={OrderNo}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OrderNo | string | 是 | 订单号 |

**响应字段**：无业务数据。

**响应示例**

```json
null
```

- **调用位置**：`alipay.js:312`

---

### 3.5 来源、直播与分享

#### 3.5.1 获取直播地址

- **用途**：活动开始后获取当前场次直播入口。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/GetHRSceneALive?SceneId={SceneId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| SceneId | string | 是 | 场次 ID |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| LiveLink | string | 直播地址 |
| LiveToLink | string | 直播跳转地址 |
| SourceId | string | 渠道 ID |

**响应示例**

```json
[{ "LiveLink": "https://l.hrflag.com/live/123", "LiveToLink": "", "SourceId": "A0001" }]
```

- **调用位置**：`codetail.js:2301`、`Form.js:2188`

---

#### 3.5.2 获取特殊渠道 ID

- **用途**：按场次获取推广渠道标识。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/GetSpecialIdByScenceId`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| ScenceId | string | 是 | 场次 ID |

**响应字段**：`SourceId`、`SpecialId`。

**响应示例**

```json
[{ "SourceId": "A0001", "SpecialId": "SP2026" }]
```

- **调用位置**：`codetail.js:2322`

---

#### 3.5.3 特殊渠道 ID 换来源 ID

- **用途**：表单页把 `SpecialId` 解析为 `SourceId`。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/GetSourceIdBySpecialId`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| ScenceId | string | 是 | 场次 ID |
| SpecialId | string | 是 | 特殊渠道 ID |

**响应字段**：`SourceId`、`SourceName`。

**响应示例**

```json
[{ "SourceId": "A0001", "SourceName": "官网" }]
```

- **调用位置**：`Form.js:2207`

---

#### 3.5.4 绑定订单来源

- **用途**：将渠道来源绑定到订单，用于渠道归因。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/AddustomerSoure`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OrderNo | string | 是 | 订单号 |
| SourceId | string | 是 | 渠道 ID |
| SpecialId | string | 否 | 特殊渠道 ID |

**响应字段**：无业务数据。

**响应示例**

```json
null
```

- **调用位置**：`codetail.js:2343`、`Form.js:2227`

---

#### 3.5.5 来源访问埋点

- **用途**：记录渠道来源带来的访问量。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/AddSourceView`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| SourceId | string | 是 | 渠道 ID |
| UserCode | string | 否 | 用户标识（Cookie `UserId`，当前已注释） |
| IpAddress | string | 否 | IP 地址 |
| IpAttach | string | 否 | IP 归属地 |

**响应字段**：无业务数据。

**响应示例**

```json
null
```

- **调用位置**：`codetail.js:2362`、`Form.js:2271`

---

### 3.6 主办方表单（StartNewForm）

#### 3.6.1 获取活动信息

- **用途**：主办方表单页初始化，读取活动名称、主办方、场次等。
- **请求**：`POST https://form.hrflag.com/WebAPI/NewForm/GetActivityById?ActivityID={ActivityId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| ActivityID | string | 是 | 活动 ID（页面参数 `activityId`） |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| EventOrganizer | string | 主办方 |
| SceneId | string | 默认场次 ID |
| SceneName | string | 默认场次名称 |

**响应示例**

```json
[{ "EventOrganizer": "HRflag 众旗", "SceneId": "S230912585361919", "SceneName": "上海" }]
```

- **调用位置**：`StartNewForm.js:262`

---

#### 3.6.2 获取场次列表

- **用途**：主办方表单页场次选择。
- **请求**：`POST https://form.hrflag.com/WebAPI/NewForm/GetSceInfoById?ActivityId={ActivityId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| ActivityId | string | 是 | 活动 ID |

**响应字段**：`SceneId`、`SceneName`、`OutSite`（外部链接）、`TipMsg`（提示文案）。

**响应示例**

```json
[{ "SceneId": "S230912585361919", "SceneName": "上海", "OutSite": "", "TipMsg": "" }]
```

- **调用位置**：`StartNewForm.js:346`

---

#### 3.6.3 获取活动名称

- **用途**：按 ID 获取活动名称，用于页面标题。
- **请求**：`POST https://form.hrflag.com/WebAPI/NewForm/GetActivityName?id={ActivityId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| id | string | 是 | 活动 ID |

**响应字段**：对象/数组，含活动名称（前端直接渲染返回值中的名称字段）。

**响应示例**

```json
[{ "ActivityName": "2026 中国人力资源峰会" }]
```

- **调用位置**：`StartNewForm.js:457`

---

#### 3.6.4 主办方隐私政策（表单页）

- **用途**：表单页展示授权公司列表。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/MenuComPrivacyShow?ActivityIds={ActivityId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| ActivityIds | string | 是 | 活动 ID（多个用逗号分隔） |

**响应字段**：`CompanyId`、`CompanyName`、`EnAbbreviation`（同 3.2.5）。

**响应示例**

```json
[{ "CompanyId": "193c6d87136e4267a74eed8c492daec5", "EnAbbreviation": "HRflag" }]
```

- **调用位置**：`StartNewForm.js:397`

---

#### 3.6.5 更新活动状态

- **用途**：按当前时间刷新活动报名状态（报名中/已结束）。
- **请求**：`POST https://form.hrflag.com/WebAPI/NewForm/UpdateActivityStatus?dtNowDate={nowDate}&strActivityId={ActivityId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| dtNowDate | string | 是 | 当前时间（`yyyy-MM-dd HH:mm:ss`） |
| strActivityId | string | 是 | 活动 ID |

**响应字段**：无业务数据。

**响应示例**

```json
null
```

- **调用位置**：`StartNewForm.js:238`

---

### 3.7 广告与侧栏复用

#### 3.7.1 活动页广告位

- **用途**：详情页广告位。
- **请求**：`POST https://form.hrflag.com/WebAPI/Advertising/IGetActMeetingADAdv?userId={UserId}`

**请求参数**：`userId`（string，否）主站用户 ID，当前传空。

**响应字段**：`Id`、`ImagePath`、`Interlinkage`、`Location`。

**响应示例**

```json
[{ "Id": "ad801", "ImagePath": "UploadImage/ActivityImg/act.png", "Interlinkage": "https://hrflag.com/", "Location": 1 }]
```

- **调用位置**：`codetail.js:205`

---

#### 3.7.2 广告点击埋点

- **请求**：`POST https://form.hrflag.com/WebAPI/Advertising/Advertising/IAddMeetingUPClickRecord?userId={UserId}&aDid={AdId}`

**请求参数**：`userId`（string，否）、`aDid`（string，是）。

**响应字段**：无业务数据。

**响应示例**

```json
null
```

- **调用位置**：`codetail.js:228`

---

#### 3.7.3 侧栏内容与推荐（复用）

> 以下接口与人脉、社区模块完全一致，参数与响应见对应文档，此处仅列出活动页调用位置。

| 接口 | 方法 | 路径 | 用途 | 调用位置 |
|---|---|---|---|---|
| 热点会议与活动 | POST | `WebAPI/ActiveMeeting/GetinnerActivemeetingNew` | 侧栏活动 | `codetail.js:411` |
| 活动点击埋点 | POST | `WebAPI/ActiveMeeting/ActiveClickRecord` | 埋点 | `codetail.js:445` |
| 快讯列表 | POST | `WebAPI/Twitter/GetHrflagTwitter` | 侧栏快讯 | `codetail.js:583` |
| 快讯换一换 | POST | `WebAPI/Twitter/ChangeTwitters` | 快讯翻页 | `codetail.js:685` |
| 快讯点赞 | POST | `WebAPI/Twitter/AddTwitterLike` | 互动 | `codetail.js:642` |
| 快讯点赞数 | POST | `WebAPI/Twitter/GetUserLike` | 互动 | `codetail.js:664` |
| 快讯浏览埋点 | POST | `WebAPI/Twitter/AddTwitterView` | 统计 | `codetail.js:754` |
| 手机号换 OpenId | POST | `WxSpAPI/Contacts/GetUserInfoByPhone` | 人脉 | `codetail.js:183` |
| 人脉推荐 | POST | `WxSpAPI/Contacts/GetConnections` | 人脉 | `codetail.js:244` |
| 相似人脉 | POST | `WxSpAPI/Contacts/AlikeConnections` | 人脉 | `codetail.js:278` |
| 今日申请数 | POST | `WxSpAPI/Apply/UserApplyMax` | 人脉 | `codetail.js:346` |
| 发送好友申请 | POST | `WxSpAPI/Apply/AddUserApply` | 人脉 | `codetail.js:355` |
| 加好友行为 | POST | `WxSpAPI/Contacts/AddUserAction` | 人脉 | `codetail.js:367` |

---

## 4. 附录

### 4.1 接口总览

| 序号 | 接口 | 方法 | 路径 | 用途 |
|---|---|---|---|---|
| 1 | 活动一级分类 | POST | `WebAPI/ActivityUser/GetAllCategory` | 列表筛选 |
| 2 | 活动子分类 | POST | `WebAPI/ActivityUser/GetCategory` | 列表筛选 |
| 3 | 活动类型 | POST | `WebAPI/ActivityUser/GetAllActivityType` | 列表筛选 |
| 4 | 活动列表 | POST | `WebAPI/Activity/GetActivityListTwo` | 列表页 |
| 5 | 活动详情 | POST | `WebAPI/Activity/GetHRflagActivityByIdNewShow` | 详情页 |
| 6 | 场次详情 | POST | `WebAPI/Activity/GetSceneInfoNew` | 详情页 |
| 7 | 报名状态 | POST | `WebAPI/Activity/IfUserIsApply` | 详情页 |
| 8 | 活动基础信息 | POST | `WebAPI/Activity/GetHRflagActivityByIdNew` | 表单分支 |
| 9 | 主办方隐私政策 | POST | `WebAPI/Activity/ComPrivacy` | 合规 |
| 10 | 隐私模板文本 | POST | `WxSpAPI/ProjectList/DataIdToTemplate` | 合规 |
| 11 | 分享有礼 | POST | `WxSpAPI/ActivitiesShare/WxSelectActivityShare` | 分享 |
| 12 | 热门活动 | POST | `WebAPI/Activity/GetHotActivityDetail` | 推荐 |
| 13 | 最新活动 | POST | `WebAPI/Activity/GetNewActivityDetail` | 推荐 |
| 14 | 发送验证码 | POST | `WebAPI/Form/GetVF` | 报名 |
| 15 | 校验验证码 | POST | `WebAPI/Form/CheckVFCode` | 报名 |
| 16 | 手机号取用户 | POST | `WebAPI/NewForm/GetUser` | 报名回填 |
| 17 | 登录用户信息 | POST | `WebAPI/System/GetUserInfo` | 报名 |
| 18 | 用户注册 | POST | `WebAPI/Form/UserRegister` | 报名 |
| 19 | 更新用户资料 | POST | `WebAPI/NewForm/UpdateUserByPhone` | 报名 |
| 20 | 提交报名（标准） | POST | `WebAPI/NewForm/AddCustomerAllInfo` | 报名 |
| 21 | 提交报名（动态） | POST | `WebAPI/NewForm/AddCustomerInfoTwo` | 报名 |
| 22 | 提交报名（旧版） | POST | `WebAPI/Activity/AddCustomerInfo` | 报名 |
| 23 | 提交报名（医疗） | POST | `WebAPI/Activity/AddYLCustomerInfo` | 报名 |
| 24 | 报名校验 | POST | `WebAPI/Activity/CheckUserRegist` | 报名 |
| 25 | 订单校验 | POST | `WebAPI/Activity/CheckUserOrder` | 报名 |
| 26 | 跨场次校验 | POST | `WebAPI/Activity/CheckUserDifOrder` | 报名 |
| 27 | 订单报名人 | POST | `WebAPI/Activity/GetCustomerByNo` | 支付 |
| 28 | 签到记录 | POST | `WebAPI/NewForm/CheckCustomSignIn` | 表单 |
| 29 | 表单报名记录 | POST | `WebAPI/NewForm/IsFormSignUp` | 表单 |
| 30 | 线上留资查询 | POST | `WebAPI/OnlineSpoor/GetCustomerInfo` | 线索 |
| 31 | 线上留资写入 | POST | `WebAPI/OnlineSpoor/AddOnlineSpoor` | 线索 |
| 32 | 部门字典 | GET | `WebAPI/Departmen/GetAllDepart` | 表单 |
| 33 | 行业字典 | GET | `WebAPI/Departmen/GetAllTradeInfo` | 表单 |
| 34 | 高校字典 | GET | `WebAPI/Activity/School*` | 表单 |
| 35 | 手机号归属地 | GET | `WebAPI/PhoneInCont/GetPhoneIn` | 表单 |
| 36 | 生成二维码 | POST | `WebAPI/ImageFile/AddQRinfo` | 分享 |
| 37 | 手机号扫码绑定 | POST | `WxSpAPI/UserInfo/SelectPhoneScan` | 签到 |
| 38 | 是否需购买 | GET | `WebAPI/FormOrder/IfFormIsBuy` | 支付 |
| 39 | 收货地址 | GET | `WebAPI/FormOrder/GetTakeDeliveryInfo` | 支付 |
| 40 | 生成订单号 | GET | `WxSpAPI/MicroLesson/GetOrderNo` | 支付 |
| 41 | 创建订单 | GET | `WebAPI/FormOrder/AddFormOrderInfo` | 支付 |
| 42 | 是否免支付 | GET | `WebAPI/FormOrder/IfIsNoPayment` | 支付 |
| 43 | 更新支付时间 | GET | `WebAPI/FormOrder/UpdatePayTime` | 支付 |
| 44 | 刷新订单状态 | POST | `WebAPI/NewForm/BulkUpdatesFormOrderNew` | 支付 |
| 45 | 订单详情 | POST | `WebAPI/Activity/GetCustomOrder` | 支付 |
| 46 | 场次地图 | POST | `WebAPI/Activity/GetActivityInfoMap` | 支付 |
| 47 | 支付宝回写 | POST | `WebAPI/Activity/RecordAliPay` | 支付 |
| 48 | 微信支付回写 | POST | `WebAPI/Activity/RecordWxPay` | 支付 |
| 49 | 直播地址 | POST | `WebAPI/Activity/GetHRSceneALive` | 直播 |
| 50 | 特殊渠道 ID | POST | `WebAPI/Activity/GetSpecialIdByScenceId` | 渠道 |
| 51 | 渠道 ID 换来源 | POST | `WebAPI/Activity/GetSourceIdBySpecialId` | 渠道 |
| 52 | 绑定订单来源 | POST | `WebAPI/Activity/AddustomerSoure` | 渠道 |
| 53 | 来源访问埋点 | POST | `WebAPI/Activity/AddSourceView` | 渠道 |
| 54 | 活动信息（表单） | POST | `WebAPI/NewForm/GetActivityById` | 主办方表单 |
| 55 | 场次列表（表单） | POST | `WebAPI/NewForm/GetSceInfoById` | 主办方表单 |
| 56 | 活动名称 | POST | `WebAPI/NewForm/GetActivityName` | 主办方表单 |
| 57 | 隐私政策（表单） | POST | `WebAPI/Activity/MenuComPrivacyShow` | 主办方表单 |
| 58 | 更新活动状态 | POST | `WebAPI/NewForm/UpdateActivityStatus` | 主办方表单 |
| 59 | 活动页广告 | POST | `WebAPI/Advertising/IGetActMeetingADAdv` | 广告 |
| 60 | 广告点击埋点 | POST | `WebAPI/Advertising/Advertising/IAddMeetingUPClickRecord` | 广告 |

### 4.2 联调注意事项

1. **拼写不一致**：场次 ID 在各接口中分别写作 `SceneId`、`ScenceID`、`ScenId`、`sceneId`、`SceneID`；渠道接口中还有 `ScenceId`。联调时严格按接口文档传参，不要统一改写。
2. **未登录占位**：`GetSceneInfoNew`、`IfUserIsApply` 的 `phone` 在未登录时传两个单引号 `''`，不是空串。
3. **重复报名拦截**：提交报名前后需分别调用 `CheckUserRegist`、`CheckUserOrder`、`CheckUserDifOrder`，三层校验缺一不可。
4. **免费与付费分流**：先调 `IfFormIsBuy`、`IfIsNoPayment`，免费活动直接提交报名，付费活动需走 `GetOrderNo → AddFormOrderInfo → 支付 → RecordAliPay/RecordWxPay`。
5. **支付幂等**：`PayStatus == "已支付"` 或 `CustomStatus == "无效票"` 时必须阻止再次支付。
6. **审核状态**：`IfUserIsApply` 返回 1（待审核）时不可重复报名；返回 3（未通过）时需引导重新报名。
7. **验证码键名**：`Form/GetVF`、`Form/CheckVFCode` 使用空键名提交手机号，后端按默认绑定接收。
8. **表单提交字段差异**：标准表单用 `AddCustomerAllInfo`，动态表单用 `AddCustomerInfoTwo`（多出 `ProjectName`、`TrackName`、`JsonStr` 等），不可混用。
9. **图片与二维码**：活动封面拼 `FilePath`；小程序码与奖品图拼 `WXAPIPath`。
10. **前端 SDK 依赖**：页面依赖 ip138 获取 IP 归属地（`returnCitySN`），该服务异常时 `IPAddress` 可能为空，后端需容错。
