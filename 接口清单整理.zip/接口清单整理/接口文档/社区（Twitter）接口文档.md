# 社区（Twitter）模块接口文档

| 项目 | 内容 |
|---|---|
| 模块名称 | 社区（Twitter，站内亦称"快讯"） |
| 前端站点 | https://t.hrflag.com/ |
| 源码目录 | `G:\G-HRflag\Twitter` |
| 接口域名 | `https://form.hrflag.com/WxSpAPI/`（社区帖子）、`https://form.hrflag.com/WebAPI/`（分类/内容/广告）、`https://form.hrflag.com/WebAPIAliPlay/`（视频） |
| 文档版本 | v1.0 |
| 更新日期 | 2026-11-17 |
| 适用对象 | 前端开发、后端开发、联调测试 |

---

## 1. 模块概述

社区模块是 HRflag 的 UGC 内容流，支持帖子发布（小程序端）、列表浏览（推荐 / 好友 / 关注）、分类筛选、关键词搜索、帖子详情、点赞、分享、关注作者、浏览量统计，并在列表与详情页聚合最热新闻、高吸引力报告、会议活动与广告位。

### 1.1 页面与接口映射

| 页面 | 路由 | 主要功能 | 主要接口分组 |
|---|---|---|---|
| 社区列表 | `/Twitter/Twitter?page={page}`、`/Twitter/Twitter?name={keywords}` | 帖子流、分类筛选、搜索、广告、侧栏 | 3.2、3.3、3.4、3.5、3.6 |
| 帖子详情 | `/Twitter/Detail?guid={guid}` | 详情、点赞、分享、关注、评论引导 | 3.2、3.3、3.4、3.5、3.6 |
| 扫码登录弹层 | 列表/详情页内 | 小程序码登录、短信验证码登录 | 3.1 |

---

## 2. 通用约定

### 2.1 环境与基础地址

| 环境 | 基础地址 |
|---|---|
| 生产 | `https://form.hrflag.com/WxSpAPI/`、`https://form.hrflag.com/WebAPI/`、`https://form.hrflag.com/WebAPIAliPlay/` |
| 测试 | `http://demo.hrflag.com/WxSpAPI/`、`http://demo.hrflag.com/WebAPI/` |

> 前端常量见 `Scripts/Common/js/config.js`（`WXAPIPath`、`APIPath`、`FilePath`）。社区部分代码还使用了未在 `config.js` 中声明的 `WxSpAPI` 变量，其指向与 `WXAPIPath` 相同。

### 2.2 请求规范

- 主要使用 **POST**；少量接口为 **GET**（`IsNotLoggedPostLike`、`FollowOrUnfollow`、`PostLikeOrUnLike` 在部分调用点使用 GET，文档中按实际标注）。
- 请求体编码：`application/x-www-form-urlencoded; charset=UTF-8`。
- 响应体：`application/json; charset=utf-8`。
- 无鉴权头，身份由参数 `Phone`（手机号）或 Cookie 中的 `PhoneNumber`、`UserId` 传递。

### 2.3 身份与登录态

| 标识 | 来源 | 说明 |
|---|---|---|
| `PhoneNumber` | Cookie | 登录手机号；为空表示游客 |
| `UserId` | Cookie | 主站用户 ID（GUID），用于分享/广告/活动统计 |
| `Phone` | 请求参数 | 社区接口统一以手机号识别用户；游客统一传 `00000000000` |

登录方式有两种：

1. **小程序扫码登录**：`Decryption/CreateWxActivity` 生成小程序码 → `UserInfo/InsertWxLoginId` 登记 → 轮询 `UserInfo/SelectUserLoginInfo` 获取手机号 → `NewForm/GetUser` 获取用户资料。
2. **短信验证码登录**：`System/checkIsRegister` 校验注册 → `Form/GetVF` 发送验证码 → `System/DocShareLogin` 校验并写入 Cookie。

### 2.4 响应结构约定

| 形态 | 说明 | 涉及接口 |
|---|---|---|
| `{ "count": n, "data": [...] }` | 分页列表 | `Community/ListOfPosts` |
| 单对象 | 详情 | `Community/GetMainConmmentTable` |
| 数组 | 分类、侧栏内容、广告 | `Twitter/GetTwitterClass`、`News/GetHotNews` 等 |
| 标量 | 计数、状态 | `Twitter/GetUserLike`、`Community/IsNotLoggedPostLike` |

### 2.5 富媒体字段约定（重要）

`ListOfPosts`、`GetMainConmmentTable` 返回的图片/视频字段是**字符串化的 JSON**，前端需 `JSON.parse` 后使用：

| 字段 | 原始类型 | 解析后结构 |
|---|---|---|
| `Image` | string | `[{ "tempFilePath": "图片URL" }]` |
| `ImageandVideo` | string | `[{ "fileType": "image"\|"video", "videoId": "阿里云视频ID", "tempFilePath": "封面或图片URL" }]` |
| `VideoLinkId` | string | 逗号分隔的视频 ID，如 `"vid1,vid2"` |
| `ViewsImage` | string | 逗号分隔的访客头像 URL，前端 `split(",")` 后倒序展示 |

> 视频实际播放地址需再调用 `AliVideo/GetVideoByAliVid` 获取。

### 2.6 枚举值

| 枚举 | 取值 | 含义 |
|---|---|---|
| `Type`（列表类型） | 1 / 2 / 3 | 推荐列表 / 人脉好友列表 / 我的关注列表 |
| `CheckStatus`（审核状态） | 0 / 1 / 2 / 3 | 待审核 / 通过 / 通过但限流 / 拒绝（设为私密） |
| `IsDelete` | 0 / 1 | 正常 / 已删除 |
| `Infographic` | `"1"` / 其他 | 图文模式 / 普通模式（决定详情页排版） |
| `Location`（广告位） | 1 / 2 / 4 | 左侧 / 右侧位 2 / 右侧位 4 |
| `IsNotLoggedPostLike.type` | 0 / 1 | 取消赞 / 点赞 |
| `WhetherLikes` | int | >0 表示当前用户已点赞 |
| `WhetherFollower` / `WhetherFollowing` | int | >0 表示已关注我 / 我已关注 |

---

## 3. 接口明细

### 3.1 登录与访客身份

#### 3.1.1 生成小程序码（登录 / 评论）

- **用途**：生成带场景值的小程序码，用于 PC 端扫码登录或扫码评论。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Decryption/CreateWxActivity`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| StrDes | string | 是 | 加密场景值。登录传 `HRId`（随机数）；评论传 `AddPostShortId` 返回的短 ID |
| page | string | 是 | 小程序页面路径：登录 `packageC/pages/loginWeb/webcreat/webcreat`；评论 `packageE/pages/comment/comment` |
| width | string | 是 | 二维码宽度，前端固定 `"430"` |
| picPath | string | 是 | 二维码存放目录：登录 `/UserImage/UserLogin/`；评论 `/WxActivity/` |

**响应字段**：标量 `string`，小程序码相对路径；前端拼接 `WXAPIPath` 后作为 `img.src`。

**响应示例**

```json
"WxActivity/Img_20261117093012.jpg"
```

- **调用位置**：`twitter.js:61`、`twitter.js:712`；`twitterdetail.js:59`、`twitterdetail.js:835`

---

#### 3.1.2 登记扫码登录会话

- **用途**：记录本次扫码登录的会话 ID，供轮询接口查询结果。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/UserInfo/InsertWxLoginId`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| HRId | string | 是 | 本次登录会话随机 ID（前端生成的大整数） |
| Type | string | 是 | 登录来源，固定 `"网站"` |

**响应字段**：无业务数据。

**响应示例**

```json
null
```

- **调用位置**：`twitter.js:77`

---

#### 3.1.3 轮询扫码登录结果

- **用途**：轮询查询扫码后是否已获取手机号，成功后跳转登录。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/UserInfo/SelectUserLoginInfo`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| HRId | string | 是 | 会话 ID，与 3.1.2 一致 |
| Type | string | 是 | 固定 `"网站"` |

**响应字段**（数组）

| 字段名 | 类型 | 说明 |
|---|---|---|
| Phone | string | 扫码用户的手机号；数组为空表示尚未扫码 |

**响应示例**

```json
[{ "Phone": "13800000000" }]
```

- **调用位置**：`twitter.js:92`

---

#### 3.1.4 手机号换取主站用户资料

- **用途**：扫码登录拿到手机号后，换取主站用户资料用于写入 Cookie。
- **请求**：`POST https://form.hrflag.com/WebAPI/NewForm/GetUser?phone={Phone}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| phone | string | 是 | 手机号（QueryString） |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| UserId | string | 主站用户 ID |
| Name | string | 姓名 |
| PhoneNumber | string | 手机号 |
| Email | string | 邮箱 |
| Company | string | 公司 |
| Department | string | 部门 |
| Position | string | 职位 |
| TradeName | string | 行业 |

**响应示例**

```json
{
  "UserId": "8f2c1a6e-3b7d-4c11-9a02-7d1f5e6b8c33",
  "Name": "王睿",
  "PhoneNumber": "13800000000",
  "Email": "example@hrflag.com",
  "Company": "众旗人力资源（上海）有限公司",
  "Department": "人力资源部",
  "Position": "HRD",
  "TradeName": "人力资源服务"
}
```

- **调用位置**：`twitter.js:104`；`twitterdetail.js:102`

---

#### 3.1.5 判断手机号是否注册

- **用途**：短信登录前校验手机号是否已注册。
- **请求**：`POST https://form.hrflag.com/WebAPI/System/checkIsRegister`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `""`（空名参数） | string | 是 | 手机号，前端以空键名提交（`data: { "": phone }`） |
| type | int | 是 | 固定 1 |

**响应字段**：标量 `bool`，`true` 已注册，`false` 未注册。

**响应示例**

```json
true
```

- **调用位置**：`twitter.js:198`

---

#### 3.1.6 发送短信验证码

- **用途**：向已注册手机号发送 6 位短信验证码。
- **请求**：`POST https://form.hrflag.com/WebAPI/Form/GetVF`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `""`（空名参数） | string | 是 | 手机号，前端以空键名提交 |

**响应字段**：无业务数据；失败由前端 60 秒倒计时与错误文案兜底。

**响应示例**

```json
null
```

- **调用位置**：`twitter.js:182`

---

#### 3.1.7 短信验证码登录

- **用途**：校验验证码并返回用户资料，前端据此写入登录 Cookie。
- **请求**：`POST https://form.hrflag.com/WebAPI/System/DocShareLogin`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| PhoneNumber | string | 是 | 手机号 |
| MsgCode | string | 是 | 6 位短信验证码 |
| IPAddress | string | 否 | 客户端 IP（由 ip138 获取） |
| IPAttach | string | 否 | IP 归属地，格式 `国家,省,市` |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| Success | string | `"3"` 表示登录成功，其余为失败 |
| Message | string | 失败提示文案 |
| UserOutput | object | 用户资料，结构同 3.1.4 |

**响应示例**

```json
{
  "Success": "3",
  "Message": "",
  "UserOutput": {
    "UserId": "8f2c1a6e-3b7d-4c11-9a02-7d1f5e6b8c33",
    "Name": "王睿",
    "PhoneNumber": "13800000000",
    "Email": "example@hrflag.com",
    "Company": "众旗人力资源（上海）有限公司",
    "Department": "人力资源部",
    "Position": "HRD",
    "TradeName": "人力资源服务"
  }
}
```

- **调用位置**：`twitter.js:251`

---

### 3.2 帖子列表与详情

#### 3.2.1 帖子列表

- **用途**：社区首页/搜索页的帖子流，支持推荐、好友、关注三种类型，支持分类与关键词，分页加载。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Community/ListOfPosts`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| Content | string | 否 | 搜索关键词，来自 URL 参数 `name`；空串表示不搜索 |
| Limit | string | 是 | 每页条数，前端固定 `"10"` |
| Page | int | 是 | 页码，从 1 开始，来自 URL 参数 `page` |
| Type | int | 是 | 1 推荐 / 2 人脉好友 / 3 我的关注 |
| Phone | string | 是 | 当前登录手机号；游客固定传 `00000000000` |
| Id | string | 否 | 分类 ID（`Twitter/GetTwitterClass` 的 `ClassId`），空串表示全部分类 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| count | int | 总条数，用于判断是否加载完 |
| data | array | 帖子列表 |
| data[].Id | string | 帖子主键（GUID），用于详情页 `guid` |
| data[].Title | string | 标题 |
| data[].Content | string | 正文纯文本（列表截断展示） |
| data[].Image | string | 图片数组的 JSON 字符串，见 2.5 |
| data[].ImageandVideo | string | 图文/视频混合数组的 JSON 字符串，见 2.5 |
| data[].VideoLinkId | string | 视频 ID，逗号分隔 |
| data[].ViewsImage | string | 访客头像 URL，逗号分隔 |
| data[].ViewCount | int | 浏览量 |
| data[].CommentCount | int | 评论数 |
| data[].ShareCount | int | 分享数 |
| data[].LikeCount | int | 点赞数 |
| data[].WhetherLikes | int | >0 表示当前手机号已点赞 |
| data[].ClassName | string | 分类名称（展示为 `#分类`） |
| data[].TimeStr | string | 发布时间文案 |
| data[].TopPost | bool/int | 是否置顶 |
| data[].OpenId | string | 作者人脉 OpenId，用于跳转个人主页 |
| data[].HeadImage | string | 作者头像 |
| data[].Name | string | 作者姓名 |
| data[].Company | string | 作者公司 |
| data[].Position | string | 作者职位 |
| data[].UserPhoneNumber | string | 作者手机号，用于点赞去重与关注 |

**响应示例**

```json
{
  "count": 128,
  "data": [
    {
      "Id": "b3f1c2d4-5e6a-4b7c-8d9e-0f1a2b3c4d5e",
      "Title": "2027 年人力资源趋势观察",
      "Content": "从组织效能、技能薪酬到 AI 招聘，以下五点值得关注……",
      "Image": "[{\"tempFilePath\":\"https://hrflagfile.oss-cn-hangzhou.aliyuncs.com/twitter/1.jpg\"}]",
      "ImageandVideo": "",
      "VideoLinkId": "",
      "ViewsImage": "https://static.hrflag.com/img/tou.png,https://hrflagfile.oss-cn-hangzhou.aliyuncs.com/user/2.jpg",
      "ViewCount": 532,
      "CommentCount": 12,
      "ShareCount": 8,
      "LikeCount": 35,
      "WhetherLikes": 0,
      "ClassName": "行业洞察",
      "TimeStr": "2小时前",
      "TopPost": 0,
      "OpenId": "old0446IdtHqVBWd2V3P7qm1b08w",
      "HeadImage": "https://hrflagfile.oss-cn-hangzhou.aliyuncs.com/uploadimage/atdportrait/1.jpg",
      "Name": "王睿",
      "Company": "众旗人力资源（上海）有限公司",
      "Position": "HRD",
      "UserPhoneNumber": "13800000000"
    }
  ]
}
```

> 前端会对列表中每条帖子调用 3.2.4 记录一次浏览，并对 `video` 类型调用 3.6.8 换取封面。

- **调用位置**：`twitter.js:412`

---

#### 3.2.2 帖子详情

- **用途**：获取单条帖子的完整内容、作者信息、互动状态，详情页主数据源。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Community/GetMainConmmentTable?id={guid}&phone={Phone}&page=1&limit=10`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| id | string | 是 | 帖子主键（`guid`） |
| phone | string | 是 | 当前登录手机号；游客传 `00000000000` |
| page | int | 是 | 固定 1（接口同时承载评论分页） |
| limit | int | 是 | 固定 10 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| Id | string | 帖子主键 |
| Title | string | 标题 |
| Content | string | 正文纯文本 |
| RichText | string | 富文本 HTML，优先展示 |
| ClassName | string | 分类名称 |
| TimeStr | string | 发布时间文案 |
| ViewCount | int | 浏览量 |
| ViewsImage | string | 访客头像，逗号分隔 |
| Image | string | 图片数组 JSON 字符串 |
| ImageandVideo | string | 图文/视频数组 JSON 字符串 |
| Infographic | string | `"1"` 图文模式，其余普通模式 |
| VideoLinkId | string | 视频 ID，逗号分隔 |
| VideoLink | string | 视频链接（可空） |
| HeadImage | string | 作者头像 |
| Name | string | 作者姓名 |
| Company | string | 作者公司 |
| Position | string | 作者职位 |
| OpenId | string | 作者人脉 OpenId |
| UserPhoneNumber | string | 作者手机号 |
| WhetherFollower | int | >0 表示作者关注了我 |
| WhetherFollowing | int | >0 表示我已关注作者 |
| LikeCount | int | 点赞数 |
| WhetherLikes | int | >0 表示我已点赞 |
| ShareCount | int | 分享数 |
| CommentCount | int | 评论数 |
| TwitterInage | array | 大图列表，元素含 `BigImage`（相对路径） |

**响应示例**

```json
{
  "Id": "b3f1c2d4-5e6a-4b7c-8d9e-0f1a2b3c4d5e",
  "Title": "2027 年人力资源趋势观察",
  "Content": "从组织效能、技能薪酬到 AI 招聘，以下五点值得关注……",
  "RichText": "<p>从组织效能、技能薪酬到 AI 招聘，以下五点值得关注……</p>",
  "ClassName": "行业洞察",
  "TimeStr": "2026-11-17 08:30:00",
  "ViewCount": 532,
  "ViewsImage": "https://static.hrflag.com/img/tou.png",
  "Image": "[{\"tempFilePath\":\"https://hrflagfile.oss-cn-hangzhou.aliyuncs.com/twitter/1.jpg\"}]",
  "ImageandVideo": "[]",
  "Infographic": "0",
  "VideoLinkId": "",
  "VideoLink": "",
  "HeadImage": "https://hrflagfile.oss-cn-hangzhou.aliyuncs.com/uploadimage/atdportrait/1.jpg",
  "Name": "王睿",
  "Company": "众旗人力资源（上海）有限公司",
  "Position": "HRD",
  "OpenId": "old0446IdtHqVBWd2V3P7qm1b08w",
  "UserPhoneNumber": "13800000000",
  "WhetherFollower": 1,
  "WhetherFollowing": 0,
  "LikeCount": 35,
  "WhetherLikes": 1,
  "ShareCount": 8,
  "CommentCount": 12,
  "TwitterInage": [
    { "BigImage": "twitter/big/1.jpg" }
  ]
}
```

- **调用位置**：`twitterdetail.js:633`、`twitterdetail.js:659`（评论弹层预取）

---

#### 3.2.3 帖子状态校验

- **用途**：详情页打开前校验帖子是否存在、审核状态与作者身份，决定是否允许查看。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Community/PostCheckState?id={guid}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| id | string | 是 | 帖子主键 |

**响应字段**（数组，取 `[0]`）

| 字段名 | 类型 | 说明 |
|---|---|---|
| IsDelete | int | 0 正常 / 1 已删除（提示"帖子不存在"） |
| CheckStatus | int | 0 待审核 / 1 通过 / 2 通过但限流 / 3 拒绝（私密） |
| UserPhoneNumber | string | 作者手机号；与当前手机号相同时，审核中/私密帖仍可查看 |
| OpenId | string | 作者 OpenId |

**响应示例**

```json
[
  {
    "IsDelete": 0,
    "CheckStatus": 1,
    "UserPhoneNumber": "13800000000",
    "OpenId": "old0446IdtHqVBWd2V3P7qm1b08w"
  }
]
```

- **调用位置**：`twitterdetail.js:309`

---

#### 3.2.4 记录帖子浏览量

- **用途**：列表渲染与详情打开时各记录一次浏览。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Community/PostView?id={guid}&openId={OpenId}&phone={Phone}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| id | string | 是 | 帖子主键 |
| openId | string | 否 | 当前用户 OpenId，当前前端传空 |
| phone | string | 是 | 当前手机号；游客传 `00000000000` |

**响应字段**：无业务数据。

**响应示例**

```json
null
```

- **调用位置**：`twitter.js:844`、`twitterdetail.js:332`

---

#### 3.2.5 生成帖子短 ID

- **用途**：为帖子生成短 ID，用于小程序评论页场景值。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Community/AddPostShortId?postId={guid}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| postId | string | 是 | 帖子主键（GUID） |

**响应字段**：标量 `string`，短 ID（后续传给 3.1.1 的 `StrDes`）。

**响应示例**

```json
"a1b2c3d4"
```

- **调用位置**：`twitter.js:707`、`twitterdetail.js:830`、`twitterdetail.js:1499`

---

#### 3.2.6 游客点赞 / 取消点赞

- **用途**：未登录用户点赞或取消点赞（仅计数，不关联账号）。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Community/IsNotLoggedPostLike?postId={guid}&type={0|1}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| postId | string | 是 | 帖子主键 |
| type | int | 是 | 0 取消赞 / 1 点赞 |

**响应字段**：标量 `int`，最新点赞数（前端不强制使用，以本地加减为准）。

**响应示例**

```json
36
```

- **调用位置**：`twitter.js:647`、`twitter.js:663`、`twitterdetail.js:1251`

---

#### 3.2.7 登录用户点赞 / 取消点赞

- **用途**：已登录用户点赞或取消点赞，同一接口切换状态。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Community/PostLikeOrUnLike`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| PostInfoId | string | 是 | 帖子主键 |
| Phone | string | 是 | 点赞人手机号 |
| LikedPhone | string | 是 | 帖子作者手机号（用于消息通知/去重） |

**响应字段**：标量/对象，返回本次操作后的状态（前端仅以 HTTP 成功为准，刷新详情获取 `WhetherLikes`/`LikeCount`）。

**响应示例**

```json
true
```

- **调用位置**：`twitter.js:675`、`twitterdetail.js:1281`

---

#### 3.2.8 关注 / 取关作者

- **用途**：关注或取消关注帖子作者，同一接口切换状态。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Community/FollowOrUnfollow`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| FollowPhone | string | 是 | 当前用户（关注方）手机号 |
| FollowingPhone | string | 是 | 被关注作者手机号 |
| IpAddress | string | 否 | 客户端 IP，由 ip138 获取；获取失败为 `未知` |
| IPLocation | string | 否 | IP 归属地 `国家,省,市` |

**响应字段**：无业务数据；成功后前端重新调用 3.2.2 刷新关注状态。

**响应示例**

```json
null
```

- **调用位置**：`twitterdetail.js:1225`

---

### 3.3 分类与侧栏内容

#### 3.3.1 获取帖子分类

- **用途**：获取社区分类列表，渲染分类筛选下拉。
- **请求**：`POST https://form.hrflag.com/WebAPI/Twitter/GetTwitterClass`

**请求参数**：无。

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| ClassId | string | 分类 ID，作为 `ListOfPosts` 的 `Id` 参数 |
| ClassName | string | 分类名称 |

**响应示例**

```json
[
  { "ClassId": "1", "ClassName": "行业洞察" },
  { "ClassId": "2", "ClassName": "组织发展" },
  { "ClassId": "3", "ClassName": "招聘与配置" }
]
```

- **调用位置**：`twitter.js:315`

---

#### 3.3.2 最新快讯（侧栏）

- **用途**：右侧栏"最新快讯"列表。
- **请求**：`POST https://form.hrflag.com/WebAPI/Twitter/GetHrflagHighTwitter`

**请求参数**：无。

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| TName | string | 标题 |
| BTContent | string | 正文 |
| CreateTime | string | 发布时间 |

**响应示例**

```json
[
  {
    "TName": "某集团发布 2027 年人力资源战略",
    "BTContent": "该集团宣布将全面推行技能薪酬体系。",
    "CreateTime": "2026-11-16 09:00:00"
  }
]
```

- **调用位置**：`twitter.js:1178`、`twitterdetail.js:1463`

---

#### 3.3.3 最热新闻

- **用途**：左侧栏"最热新闻"榜单。
- **请求**：`POST https://form.hrflag.com/WebAPI/News/GetHotNews?count={count}&nId={nId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| count | int | 是 | 返回条数，前端传 15 |
| nId | string | 否 | 当前新闻 ID，用于排除自身 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| NId | string | 新闻 ID |
| Title | string | 标题 |
| NSource | string | 来源 |

**响应示例**

```json
[
  { "NId": "n20261116001", "Title": "灵活用工合规指引更新", "NSource": "HRflag" }
]
```

- **调用位置**：`twitter.js:390`、`twitterdetail.js:612`

---

#### 3.3.4 高吸引力报告

- **用途**：侧栏"高吸引力报告"推荐位。
- **请求**：`POST https://form.hrflag.com/WebAPI/FileMgr/GetHighForceFileld?Switch={Switch}&limit={limit}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| Switch | int | 是 | 推荐位类型：列表页 1，详情页 3 |
| limit | int | 否 | 返回条数，列表页 7，详情页 10 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| FileId | string | 报告 ID |
| Name | string | 报告名称 |
| ComName | string | 出品机构 |
| SmallImage | string | 封面（相对路径） |
| UploadUnit | string | 上传单位 |
| ReleaseTime | string | 发布时间 |
| PageViews | int | 预览数 |
| FilePages | int | 页数 |
| Downloads | int | 下载数 |

**响应示例**

```json
[
  {
    "FileId": "f20260901",
    "Name": "2026 中国人力资源薪酬白皮书",
    "ComName": "HRflag 研究院",
    "SmallImage": "uploadimage/report/cover2026.jpg",
    "UploadUnit": "HRflag 研究院",
    "ReleaseTime": "2026-09-01",
    "PageViews": 8421,
    "FilePages": 68,
    "Downloads": 1203
  }
]
```

- **调用位置**：`twitter.js:1133`、`twitterdetail.js:1388`

---

#### 3.3.5 热门活动（侧栏）

- **用途**：侧栏热门活动推荐。
- **请求**：`POST https://form.hrflag.com/WebAPI/Activity/GetHotActivityDetail?count={count}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| count | int | 是 | 返回条数 |

**响应字段**：`SceneId`、`ActivityId`、`ActivityTitle`、`ActivitySponsor`、`ImageUrl`、`ActivityTicketCheck`、`PageView`、`Weekness`、`SceneBeginDate`、`CityName`（字段含义同人脉模块 3.6.4）。

**响应示例**

```json
[
  {
    "SceneId": "1001",
    "ActivityId": "act20261101",
    "ActivityTitle": "2026 中国人力资源峰会",
    "ActivitySponsor": "HRflag 众旗",
    "ImageUrl": "uploadimage/activity/cover1.jpg",
    "ActivityTicketCheck": "报名中",
    "PageView": 15230,
    "Weekness": "周五",
    "SceneBeginDate": "2026-12-05 09:00:00",
    "CityName": "上海"
  }
]
```

- **调用位置**：`twitterdetail.js:1430`

---

#### 3.3.6 会议与活动（侧栏）

- **用途**：侧栏"热点会议与活动"列表。
- **请求**：`POST https://form.hrflag.com/WebAPI/ActiveMeeting/GetinnerActivemeetingNew`

**请求参数**：无。

**响应字段**：`ActiveId`、`ActiveName`、`SourceUrl`、`SpeakerName`、`SpeakerPosition`、`SpeakerImage`、`ActivityLogo`、`Activetime[]`（含 `SceneBeginDate`、`CountryName`），同人脉模块 3.6.1。

**响应示例**

```json
[
  {
    "ActiveId": "act20261101",
    "ActiveName": "2026 中国人力资源峰会",
    "SourceUrl": "https://events.hrflag.com/Detail?sceneId=1001&activityId=act20261101",
    "SpeakerName": "李明",
    "SpeakerPosition": "人力资源副总裁",
    "SpeakerImage": "uploadimage/speaker/1.jpg",
    "ActivityLogo": "uploadimage/activity/logo1.png",
    "Activetime": [{ "SceneBeginDate": "2026-12-05", "CountryName": "上海" }]
  }
]
```

- **调用位置**：`twitter.js:967`、`twitterdetail.js:556`

---

#### 3.3.7 活动点击埋点

- **用途**：侧栏活动点击上报。
- **请求**：`POST https://form.hrflag.com/WebAPI/ActiveMeeting/ActiveClickRecord?userId={UserId}&aDid={ActiveId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| userId | string | 否 | 主站用户 ID |
| aDid | string | 是 | 活动 ID |

**响应字段**：无业务数据。

**响应示例**

```json
null
```

- **调用位置**：`twitter.js:1002`、`twitterdetail.js:590`

---

#### 3.3.8 获取阿里云视频地址

- **用途**：按阿里云视频 ID 换取封面地址 / 播放地址。
- **请求**：`POST https://form.hrflag.com/WebAPIAliPlay/AliVideo/GetVideoByAliVid?Vid={Vid}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| Vid | string | 是 | 阿里云视频 ID（来自 `ImageandVideo[].videoId` 或 `VideoLinkId`） |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| CoverURL | string | 视频封面地址，列表页用作视频缩略图 |
| 其他 | - | 播放器所需的视频地址等字段（详情页直接透传给播放器） |

**响应示例**

```json
{
  "CoverURL": "https://hrflagfile.oss-cn-hangzhou.aliyuncs.com/video/cover/1.jpg",
  "VideoURL": "https://hrflagfile.oss-cn-hangzhou.aliyuncs.com/video/1.m3u8"
}
```

- **调用位置**：`twitter.js:747`、`twitterdetail.js:953`

---

### 3.4 快讯互动（WebAPI 旧接口）

#### 3.4.1 快讯总数

- **用途**：获取快讯总条数，计算总页数。
- **请求**：`POST https://form.hrflag.com/WebAPI/Twitter/GetHRflagTwitterInfo`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| limit | int | 是 | 固定 0（仅取总数） |
| page | int | 是 | 固定 0 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| count | int | 总条数 |

**响应示例**

```json
{ "count": 386 }
```

- **调用位置**：`twitter.js:952`

---

#### 3.4.2 快讯大图

- **用途**：查看大图时获取该快讯的全部大图地址。
- **请求**：`POST https://form.hrflag.com/WebAPI/Twitter/GetTwitterByid`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| Object | string | 是 | 快讯主键（GUID） |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| TwitterInage | array | 大图列表 |
| TwitterInage[].BigImage | string | 大图相对路径，需拼 `FilePath` 并将 `\\` 替换为 `/` |

**响应示例**

```json
{
  "TwitterInage": [
    { "BigImage": "twitter\\big\\1.jpg" },
    { "BigImage": "twitter\\big\\2.jpg" }
  ]
}
```

- **调用位置**：`twitter.js:792`

---

#### 3.4.3 快讯点赞数

- **用途**：获取单条快讯点赞总数。
- **请求**：`POST https://form.hrflag.com/WebAPI/Twitter/GetUserLike`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| Guid | string | 是 | 快讯主键 |

**响应字段**：标量 `int`，点赞总数。

**响应示例**

```json
35
```

- **调用位置**：`twitterdetail.js:970`

---

#### 3.4.4 记录快讯分享

- **用途**：分享到微博/领英/QQ/QQ空间时上报一次分享。
- **请求**：`POST https://form.hrflag.com/WebAPI/Twitter/AddTwitterShare`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| Guid | string | 是 | 快讯主键 |
| UserId | string | 否 | 主站用户 ID，可为空 |

**响应字段**：无业务数据；成功后前端再调用 3.4.5 刷新分享数。

**响应示例**

```json
null
```

- **调用位置**：`twitterdetail.js:1033`

---

#### 3.4.5 快讯分享数

- **用途**：获取单条快讯分享总数。
- **请求**：`POST https://form.hrflag.com/WebAPI/Twitter/GetUserShares`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| Guid | string | 是 | 快讯主键 |

**响应字段**：标量 `int`，分享总数；`0` 时前端展示"分享"。

**响应示例**

```json
8
```

- **调用位置**：`twitterdetail.js:1043`

---

#### 3.4.6 快讯浏览量（旧）

- **用途**：详情页记录一次快讯浏览。
- **请求**：`POST https://form.hrflag.com/WebAPI/Twitter/AddTwitterView`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| Object | string | 是 | 快讯主键 |

**响应字段**：无业务数据。

**响应示例**

```json
null
```

- **调用位置**：`twitter.js:1093`、`twitterdetail.js:1060`

---

#### 3.4.7 帖子浏览量（新）

- **用途**：以手机号 + 帖子维度记录浏览量，替代 3.4.6 用于社区帖子。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/Question/AddTwitterViews?PhoneNo={phone}&TwitterId={id}&OpenId={OpenId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| PhoneNo | string | 是 | 当前手机号 |
| TwitterId | string | 是 | 帖子主键 |
| OpenId | string | 否 | 当前用户 OpenId，可为空 |

**响应字段**：无业务数据。

**响应示例**

```json
null
```

- **调用位置**：`twitter.js:1107`、`twitterdetail.js:1076`

---

### 3.5 广告位与点击埋点

#### 3.5.1 列表信息流广告

- **用途**：帖子列表第 1 页插入的单条广告。
- **请求**：`POST https://form.hrflag.com/WebAPI/Advertising/IGetTwitterAD`

**请求参数**：无。

**响应字段**（单对象，可能为 `null` 表示无广告）

| 字段名 | 类型 | 说明 |
|---|---|---|
| Id | string | 广告 ID |
| ImagePath | string | 图片相对路径 |
| Interlinkage | string | 跳转链接 |

**响应示例**

```json
{
  "Id": "ad501",
  "ImagePath": "UploadImage/ActivityImg/twitter_ad.png",
  "Interlinkage": "https://events.hrflag.com/"
}
```

- **调用位置**：`twitter.js:857`

---

#### 3.5.2 左右侧广告位

- **用途**：列表页左/右栏广告位，按 `Location` 区分渲染位置。
- **请求**：`POST https://form.hrflag.com/WebAPI/Advertising/IGetTwitterADS?userId={UserId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| userId | string | 否 | 主站用户 ID，当前前端传空 |

**响应字段**

| 字段名 | 类型 | 说明 |
|---|---|---|
| Location | int | 1 左侧 / 2 右侧位 2 / 4 右侧位 4 |
| Id | string | 广告 ID |
| ImagePath | string | 图片相对路径 |
| Interlinkage | string | 跳转链接 |

**响应示例**

```json
[
  { "Location": 1, "Id": "ad601", "ImagePath": "UploadImage/ActivityImg/left.png", "Interlinkage": "https://hrflag.com/" },
  { "Location": 2, "Id": "ad602", "ImagePath": "UploadImage/ActivityImg/right2.png", "Interlinkage": "https://hrflag.com/" }
]
```

- **调用位置**：`twitter.js:891`

---

#### 3.5.3 详情页广告位

- **用途**：帖子详情页广告位。
- **请求**：`POST https://form.hrflag.com/WebAPI/Advertising/IGetTwitterAdv?userId={UserId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| userId | string | 否 | 主站用户 ID，当前前端传空 |

**响应字段**：同 3.5.2（`Id`、`ImagePath`、`Interlinkage`）。

**响应示例**

```json
[
  { "Id": "ad701", "ImagePath": "UploadImage/ActivityImg/detail.png", "Interlinkage": "https://hrflag.com/" }
]
```

- **调用位置**：`twitterdetail.js:1089`

---

#### 3.5.4 信息流广告点击埋点

- **用途**：点击 3.5.1 广告时上报。
- **请求**：`POST https://form.hrflag.com/WebAPI/Advertising/IAddTwitterADClickRecord?aDid={AdId}&userId={UserId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| aDid | string | 是 | 广告 ID |
| userId | string | 否 | 主站用户 ID |

**响应字段**：无业务数据。

**响应示例**

```json
null
```

- **调用位置**：`twitter.js:878`

---

#### 3.5.5 侧栏广告点击埋点

- **用途**：点击左右侧广告位时上报。
- **请求**：`POST https://form.hrflag.com/WebAPI/Advertising/IAddNewsDetailADClickRecord?userId={UserId}&aDid={AdId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| userId | string | 否 | 主站用户 ID |
| aDid | string | 是 | 广告 ID |

**响应字段**：无业务数据。

**响应示例**

```json
null
```

- **调用位置**：`twitter.js:924`

---

#### 3.5.6 通用广告点击埋点

- **用途**：详情页通用广告点击上报（路径含两级 `Advertising`，需原样调用）。
- **请求**：`POST https://form.hrflag.com/WebAPI/Advertising/Advertising/IAddMeetingUPClickRecord?userId={UserId}&aDid={AdId}`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| userId | string | 否 | 主站用户 ID |
| aDid | string | 是 | 广告 ID |

**响应字段**：无业务数据。

**响应示例**

```json
null
```

- **调用位置**：`twitterdetail.js:1127`

---

### 3.6 人脉能力复用

> 社区详情页与侧栏复用人脉模块的推荐与加好友能力，参数与响应与人脉模块一致，此处仅列出差异点。

#### 3.6.1 手机号换 OpenId

- **请求**：`POST https://form.hrflag.com/WxSpAPI/Contacts/GetUserInfoByPhone`
- **参数**：`Phone`（string，必填）
- **响应**：`{ "OpenId": "...", "IsDelete": 0 }`
- **调用位置**：`twitterdetail.js:365`

#### 3.6.2 人脉推荐（同行）

- **请求**：`POST https://form.hrflag.com/WxSpAPI/Contacts/GetConnectionInfo`
- **参数**：`Phone`、`ClassType=1`、`limit=8`、`page`
- **响应**：`[{ OpenId, Name, Image, Company, Position, PhoneNo, IsgoSend }]`
- **调用位置**：`twitterdetail.js:387`

#### 3.6.3 相似人脉推荐

- **请求**：`POST https://form.hrflag.com/WxSpAPI/Contacts/AlikeConnections`
- **参数**：`OpenId`、`MyOpenId`、`Limite=6`
- **响应**：`[{ OpenId, Name, Image, Company, Position, PhoneNo, IsgoSend }]`
- **调用位置**：`twitterdetail.js:423`

#### 3.6.4 今日已发送申请数

- **请求**：`POST https://form.hrflag.com/WxSpAPI/Apply/UserApplyMax`
- **参数**：`OpenId`
- **响应**：标量 `int`，`>= 30` 时禁止发送
- **调用位置**：`twitterdetail.js:487`、`twitterdetail.js:1170`

#### 3.6.5 发送好友申请

- **请求**：`POST https://form.hrflag.com/WxSpAPI/Apply/AddUserApply`
- **参数**：`SOpenId`、`BOpenId`
- **响应**：标量 `int`，`1` 成功
- **调用位置**：`twitterdetail.js:496`、`twitterdetail.js:1179`

#### 3.6.6 写入加好友行为记录

- **请求**：`POST https://form.hrflag.com/WxSpAPI/Contacts/AddUserAction`
- **参数**：`OpenId`、`KindId=1`、`ContentId=11`、`Remarks=对方手机号`
- **响应**：标量 `int`，`1` 成功
- **调用位置**：`twitterdetail.js:509`、`twitterdetail.js:1190`

#### 3.6.7 查询是否已申请

- **用途**：详情页判断"加为好友"按钮状态。返回 1 条表示已申请（显示"等待通过"），2 条表示已是好友（隐藏按钮）。
- **请求**：`POST https://form.hrflag.com/WxSpAPI/UserInfo/SelUserAction`

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|---|---|---|---|
| OpenId | string | 是 | 当前用户 OpenId |
| KindId | int | 是 | 固定 1 |
| ContentId | int | 是 | 固定 11 |
| Remarks | string | 是 | 对方手机号 |

**响应字段**：数组，长度含义见用途说明。

**响应示例**

```json
[{ "AId": 1024 }]
```

- **调用位置**：`twitterdetail.js:794`

---

## 4. 附录

### 4.1 接口总览

| 序号 | 接口 | 方法 | 路径 | 用途 |
|---|---|---|---|---|
| 1 | 生成小程序码 | POST | `WxSpAPI/Decryption/CreateWxActivity` | 扫码登录/评论 |
| 2 | 登记登录会话 | POST | `WxSpAPI/UserInfo/InsertWxLoginId` | 扫码登录 |
| 3 | 轮询登录结果 | POST | `WxSpAPI/UserInfo/SelectUserLoginInfo` | 扫码登录 |
| 4 | 手机号换资料 | POST | `WebAPI/NewForm/GetUser` | 扫码登录 |
| 5 | 是否注册 | POST | `WebAPI/System/checkIsRegister` | 短信登录 |
| 6 | 发送验证码 | POST | `WebAPI/Form/GetVF` | 短信登录 |
| 7 | 验证码登录 | POST | `WebAPI/System/DocShareLogin` | 短信登录 |
| 8 | 帖子列表 | POST | `WxSpAPI/Community/ListOfPosts` | 首页/搜索 |
| 9 | 帖子详情 | POST | `WxSpAPI/Community/GetMainConmmentTable` | 详情页 |
| 10 | 帖子状态校验 | POST | `WxSpAPI/Community/PostCheckState` | 详情页 |
| 11 | 浏览记录 | POST | `WxSpAPI/Community/PostView` | 浏览统计 |
| 12 | 帖子短 ID | POST | `WxSpAPI/Community/AddPostShortId` | 评论码 |
| 13 | 游客点赞 | POST | `WxSpAPI/Community/IsNotLoggedPostLike` | 未登录互动 |
| 14 | 登录点赞 | POST | `WxSpAPI/Community/PostLikeOrUnLike` | 互动 |
| 15 | 关注/取关 | POST | `WxSpAPI/Community/FollowOrUnfollow` | 关注作者 |
| 16 | 帖子分类 | POST | `WebAPI/Twitter/GetTwitterClass` | 分类筛选 |
| 17 | 最新快讯 | POST | `WebAPI/Twitter/GetHrflagHighTwitter` | 侧栏 |
| 18 | 最热新闻 | POST | `WebAPI/News/GetHotNews` | 侧栏 |
| 19 | 高吸引力报告 | POST | `WebAPI/FileMgr/GetHighForceFileld` | 侧栏 |
| 20 | 热门活动 | POST | `WebAPI/Activity/GetHotActivityDetail` | 侧栏 |
| 21 | 会议与活动 | POST | `WebAPI/ActiveMeeting/GetinnerActivemeetingNew` | 侧栏 |
| 22 | 活动点击埋点 | POST | `WebAPI/ActiveMeeting/ActiveClickRecord` | 埋点 |
| 23 | 视频地址 | POST | `WebAPIAliPlay/AliVideo/GetVideoByAliVid` | 视频封面/播放 |
| 24 | 快讯总数 | POST | `WebAPI/Twitter/GetHRflagTwitterInfo` | 分页 |
| 25 | 快讯大图 | POST | `WebAPI/Twitter/GetTwitterByid` | 图片查看 |
| 26 | 快讯点赞数 | POST | `WebAPI/Twitter/GetUserLike` | 互动 |
| 27 | 快讯分享记录 | POST | `WebAPI/Twitter/AddTwitterShare` | 分享统计 |
| 28 | 快讯分享数 | POST | `WebAPI/Twitter/GetUserShares` | 互动 |
| 29 | 快讯浏览量（旧） | POST | `WebAPI/Twitter/AddTwitterView` | 统计 |
| 30 | 帖子浏览量（新） | POST | `WxSpAPI/Question/AddTwitterViews` | 统计 |
| 31 | 信息流广告 | POST | `WebAPI/Advertising/IGetTwitterAD` | 广告位 |
| 32 | 左右侧广告 | POST | `WebAPI/Advertising/IGetTwitterADS` | 广告位 |
| 33 | 详情页广告 | POST | `WebAPI/Advertising/IGetTwitterAdv` | 广告位 |
| 34 | 信息流广告点击 | POST | `WebAPI/Advertising/IAddTwitterADClickRecord` | 广告统计 |
| 35 | 侧栏广告点击 | POST | `WebAPI/Advertising/IAddNewsDetailADClickRecord` | 广告统计 |
| 36 | 通用广告点击 | POST | `WebAPI/Advertising/Advertising/IAddMeetingUPClickRecord` | 广告统计 |
| 37 | 手机号换 OpenId | POST | `WxSpAPI/Contacts/GetUserInfoByPhone` | 人脉复用 |
| 38 | 人脉推荐 | POST | `WxSpAPI/Contacts/GetConnectionInfo` | 人脉复用 |
| 39 | 相似人脉 | POST | `WxSpAPI/Contacts/AlikeConnections` | 人脉复用 |
| 40 | 今日申请数 | POST | `WxSpAPI/Apply/UserApplyMax` | 人脉复用 |
| 41 | 发送申请 | POST | `WxSpAPI/Apply/AddUserApply` | 人脉复用 |
| 42 | 加好友行为 | POST | `WxSpAPI/Contacts/AddUserAction` | 人脉复用 |
| 43 | 查询申请状态 | POST | `WxSpAPI/UserInfo/SelUserAction` | 人脉复用 |

### 4.2 联调注意事项

1. **游客标识**：未登录时所有社区接口的 `Phone` 统一传 `00000000000`，不要传空串，否则部分接口会返回空列表。
2. **富媒体字段需二次解析**：`Image`、`ImageandVideo` 是字符串化 JSON，直接当数组用会报错；`ViewsImage` 是逗号分隔字符串。
3. **分页判断**：以 `count` 与 `Page * Limit` 比较判断是否加载完（`count < Page*10` 即最后一页）。
4. **审核态**：`CheckStatus` 为 0 或 3 时，仅作者本人（`UserPhoneNumber == 当前手机号`）可查看详情，前端需先调 `PostCheckState`。
5. **点赞双通道**：未登录走 `IsNotLoggedPostLike`，已登录走 `PostLikeOrUnLike`，两条链路互斥。
6. **分类筛选现状**：前端已渲染分类列表，但 `ListOfPosts` 的 `Id` 参数当前始终传空（源码中 `let Id = ""` 未赋值），分类筛选实际未生效，联调时需后端确认是否修正。
7. **登录参数键名**：`System/checkIsRegister`、`Form/GetVF` 使用空字符串作为参数名（`data: { "": phone }`），后端按默认绑定接收，改造时需同步。
8. **分享埋点时机**：分享到第三方平台前先调用 `AddTwitterShare`，成功后立即刷新 `GetUserShares`。
9. **视频封面**：列表只返回 `videoId`，必须调用 `AliVideo/GetVideoByAliVid` 取 `CoverURL` 才能展示缩略图。
