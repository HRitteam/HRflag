# 人脉（Network）模块表结构

本表结构由源码调用链定位：先按 接口源码/01-人脉（Network）接口源码对照.md 找到 Helper 方法，再从 Helper 的 SQL 中提取表名，最后读取数据库元数据生成字段清单。所有查询均为只读。

| 项目 | 内容 |
|---|---|
| 数据库 | `hrflag`（主站）、`hrflagwxsp`（人脉/社区）、`hrflagactivities`（活动） |
| 实例 | `rm-bp1qz3lr4bu51dy5eso.sqlserver.rds.aliyuncs.com`（SQL Server 2012，只读查询） |
| 表数量 | 32 张 |
| 采集时间 | 2026-11-17 |
| 采集方式 | 直接读取 `sys.columns` / `sys.indexes` / `sys.foreign_keys` / `sys.extended_properties` |

## 1. 表清单

| # | 库 | 表名 | 行数 | 字段数 | 用途 | 关联接口 |
|---|---|---|---|---|---|---|
| 1 | hrflagwxsp | HRUserInfo | 102,800 | 32 | 人脉用户主表，存储名片、联系方式、公司职位、头像、审核与展示状态；几乎所有 Contacts/UserInfo 接口的数据源 | Contacts/GetUserInfoByPhone、GetUserInfoByid、GetConnections、GetLookUser |
| 2 | hrflagwxsp | HRUser_Action | 2,527,489 | 10 | 用户行为流水，按 KindId + ContentId 区分浏览、点赞、加好友、分享等行为，Remarks 存目标标识 | Contacts/AddUserAction(s)、UserInfo/GetLookUser、GetCountAllorAdd |
| 3 | hrflagwxsp | HRUser_ImgAddress | 208,759 | 6 | 人脉用户图片地址表，存名片附图/视频封面地址 | Contacts/GetUserInfoByPhone（子查询 ImgAddress） |
| 4 | hrflagwxsp | HRRelation | 222,923 | 13 | 好友关系表，一条记录代表一次申请/通过，IsTake 表示处理状态 | Apply/AddUserApply、AdoptUserApply、PassUserApply |
| 5 | hrflagwxsp | UserFollows | 205,441 | 6 | 用户关注关系表（单向关注），支撑帖子关注流 | Community/ListOfPosts、FollowOrUnfollow（社区复用） |
| 6 | hrflagwxsp | UserHomePage | 20,075 | 8 | 个人主页配置表（背景、展示开关等） | Apply/AdoptUserApply、社区关注 |
| 7 | hrflag | User | 248,143 | 23 | 主站账号主表，手机号、姓名、公司、部门、职位、行业、删除标记 | Contacts/GetUserInfoByPhone、GetConnections、广告与埋点 |
| 8 | hrflag | VipUser | 1,563 | 14 | VIP 会员信息表，记录会员等级与权益 | Contacts/GetUserInfoByid |
| 9 | hrflag | UserPhoto | 124 | 4 | 用户头像表，主站上传头像地址 | UserInfo/GetUserById（公共布局） |
| 10 | hrflag | ActiveMeeting | 244 | 12 | 会议/活动推荐位主表，侧栏"热点会议与活动"数据源 | ActiveMeeting/GetinnerActivemeetingNew、GetActivemeeting |
| 11 | hrflag | ActiveMeetingClickRecord | 4,686 | 3 | 会议活动点击流水 | ActiveMeeting/ActiveClickRecord |
| 12 | hrflag | QuestionnaireInfo | 2,132 | 10 | 问卷信息表，与活动（ActivtyID）关联，侧栏取演讲嘉宾用 | ActiveMeeting/GetinnerActivemeetingNew |
| 13 | hrflag | Company | 3,747 | 15 | 公司主表，ComId/ComName，快讯与报告出品方关联 | FileMgr/GetHighForceFileld、Twitter 侧栏 |
| 14 | hrflag | Twitter | 8,150 | 20 | 快讯主表，标题、正文、浏览量、分类、发布公司 | Twitter/GetHrflagTwitter、ChangeTwitters |
| 15 | hrflag | TwitterClass | 8 | 5 | 快讯分类字典 | Twitter/GetHrflagTwitter（关联 ClassName） |
| 16 | hrflag | TwitterShare | 512 | 3 | 快讯分享记录，按 Guid + UserId 记录 | Twitter/AddTwitterShare、GetUserShares |
| 17 | hrflag | TwitterUserLike | 23,568 | 3 | 快讯点赞记录，按 Guid + UserId 记录 | Twitter/AddTwitterLike、GetUserLike |
| 18 | hrflag | TopAD | 41 | 12 | 顶部通栏广告表，含 ShowNum 曝光计数 | Advertising/IGetTopAD、IAddTopADViewRecord |
| 19 | hrflag | TopADClickRecord | 1,219 | 3 | 顶部广告点击流水 | Advertising/IAddTopADClickRecord |
| 20 | hrflag | MeetingUPClickRecord | 166 | 3 | 会议/通用广告点击流水（人脉页广告位复用） | Advertising/Advertising/IAddMeetingUPClickRecord |
| 21 | hrflag | PersonConnectionAdv | 7 | 11 | 人脉首页广告位配置表，含 Location 位置标识 | Advertising/IGetPersonConnectionAdv |
| 22 | hrflag | FriendApplyFor | 17 | 11 | 好友申请页广告位配置表 | Advertising/IGetFriendApplyForAdv |
| 23 | hrflag | FriendTable | 19 | 11 | 好友列表页广告位配置表 | Advertising/IGetFriendTableAdv |
| 24 | hrflag | StrangerAD | 20 | 11 | 陌生人/好友主页广告位配置表 | Advertising/IGetStrangerADAdv |
| 25 | hrflag | FileLibrary | 19,305 | 29 | 研究报告主表，报告名称、封面、页数、下载/预览数 | FileMgr/GetHighForceFileld |
| 26 | hrflag | FileAttach | 22,128 | 12 | 报告附件表，记录页数等 | FileMgr/GetHighForceFileld（FilePages 子查询） |
| 27 | hrflag | DownRecord | 428,935 | 10 | 报告下载记录，用于近 7 天/当天下载榜统计 | FileMgr/GetHighForceFileld |
| 28 | hrflagdataonline | ThinkerSpeaker | 1,774 | 15 | 演讲嘉宾表（在线活动库），侧栏会议卡片头像与嘉宾信息 | ActiveMeeting/GetinnerActivemeetingNew |
| 29 | hrflagdataonline | ThinkerCompanyInfo | 4,697 | 51 | 演讲嘉宾所属公司表，公司全称/中英文简称 | ActiveMeeting/GetinnerActivemeetingNew、Activity/ComPrivacy |
| 30 | hrflagactivities | SceneInfo | 2,477 | 28 | 活动场次表，取场次开始日期与城市，供侧栏活动卡片展示 | ActiveMeeting/GetinnerActivemeetingNew |
| 31 | hrflagactivities | CityInfoCfg | 44 | 2 | 城市字典表 | ActiveMeeting/GetinnerActivemeetingNew |
| 32 | hrflagactivities | CountyInfoCfg | 480 | 3 | 国家/地区字典表 | ActiveMeeting/GetinnerActivemeetingNew |

## 2. 表结构详情

### 1. HRUserInfo

**库**：`hrflagwxsp`　**行数**：102,800　**字段数**：32

**用途**：人脉用户主表，存储名片、联系方式、公司职位、头像、审核与展示状态；几乎所有 Contacts/UserInfo 接口的数据源

**关联接口**：Contacts/GetUserInfoByPhone、GetUserInfoByid、GetConnections、GetLookUser

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `OpenId` | nvarchar | 200 | 否 |  | **PK** |  |
| `UnionID` | nvarchar | 200 | 是 |  |  |  |
| `Image` | nvarchar | 1000 | 是 |  |  |  |
| `PhoneNo` | nvarchar | 11 | 是 |  |  |  |
| `PhonePlace` | nvarchar | 20 | 是 | (N'') |  |  |
| `Name` | nvarchar | 50 | 是 |  |  |  |
| `NameNumber` | nvarchar | 100 | 是 |  |  |  |
| `Company` | nvarchar | 200 | 是 |  |  |  |
| `CompanyLogo` | nvarchar | 200 | 是 |  |  |  |
| `TradName` | nvarchar | 200 | 是 |  |  |  |
| `Department` | nvarchar | 200 | 是 |  |  |  |
| `Position` | nvarchar | 200 | 是 |  |  |  |
| `Email` | nvarchar | 100 | 是 |  |  |  |
| `Place` | nvarchar | 100 | 是 |  |  |  |
| `Address` | nvarchar | 300 | 是 |  |  |  |
| `TelePhone` | nvarchar | 50 | 是 |  |  |  |
| `WxCode` | nvarchar | 200 | 是 |  |  |  |
| `IsCreate` | bit |  | 是 |  |  |  |
| `Status` | int |  | 是 | ((1)) |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `UpdateTime` | datetime |  | 是 |  |  |  |
| `IsDelete` | int |  | 是 | ((0)) |  |  |
| `IsShow` | int |  | 是 | ((0)) |  | 0显示   1不显示 |
| `IsDisplay` | int |  | 是 | ((0)) |  | 0显示 1不显示 |
| `Reamrks` | nvarchar | 100 | 是 |  |  |  |
| `BusinessColour` | nvarchar | 50 | 是 | (N'blue') |  |  |
| `Privacybool` | bit |  | 是 | ((0)) |  |  |
| `Relationbool` | bit |  | 是 | ((1)) |  |  |
| `IPAddress` | nvarchar | 50 | 是 |  |  |  |
| `IPAttach` | nvarchar | 50 | 是 |  |  |  |
| `IsRestrict` | int |  | 是 |  |  | 是否限制(0:未限制 1:已限制) |
| `RestrictTime` | datetime |  | 是 |  |  | 限制时间 |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| HRUserInfo_Index | NONCLUSTERED | 否 | PhoneNo,CreateTime,UpdateTime,Status,IsCreate,IsDelete |
| IX_HRUserInfo_PhoneNo | NONCLUSTERED | 否 | PhoneNo |
| IX_HRUserInfo_Phone | NONCLUSTERED | 否 | PhoneNo |
| IX_HRUserInfo_Phone_Delete | NONCLUSTERED | 否 | PhoneNo,IsDelete,IsCreate |
| IX_HRUserInfo_PhoneNo_Filter | NONCLUSTERED | 否 | PhoneNo |
| IX_HRUserInfo_Phone_ValidUser | NONCLUSTERED | 否 | PhoneNo,IsDelete,IsCreate,CreateTime |

### 2. HRUser_Action

**库**：`hrflagwxsp`　**行数**：2,527,489　**字段数**：10

**用途**：用户行为流水，按 KindId + ContentId 区分浏览、点赞、加好友、分享等行为，Remarks 存目标标识

**关联接口**：Contacts/AddUserAction(s)、UserInfo/GetLookUser、GetCountAllorAdd

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Id` | int |  | 否 |  | **PK** | 自增 |
| `OpenId` | nvarchar | 100 | 是 |  |  |  |
| `KindId` | int |  | 是 |  |  |  |
| `ContentId` | int |  | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `Remarks` | nvarchar | 300 | 是 |  |  |  |
| `IsDelete` | int |  | 是 | ((0)) |  |  |
| `IPAddress` | nvarchar | 50 | 是 |  |  |  |
| `IPAttach` | nvarchar | 50 | 是 |  |  |  |
| `flag` | int |  | 是 |  |  | 0:扫展商二维码 1:互换名片 |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| Index_All | NONCLUSTERED | 否 | KindId,ContentId,OpenId,Remarks,CreateTime,IsDelete |
| IX_HRUserAction_LookSearch | NONCLUSTERED | 否 | ContentId,KindId,Remarks,OpenId |

### 3. HRUser_ImgAddress

**库**：`hrflagwxsp`　**行数**：208,759　**字段数**：6

**用途**：人脉用户图片地址表，存名片附图/视频封面地址

**关联接口**：Contacts/GetUserInfoByPhone（子查询 ImgAddress）

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Id` | int |  | 否 |  | **PK** | 自增 |
| `OpenId` | nvarchar | 200 | 是 |  |  |  |
| `ImgAddress` | nvarchar | 1000 | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `Status` | int |  | 是 |  |  |  |
| `IsDelete` | int |  | 是 |  |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| Index_All | NONCLUSTERED | 否 | OpenId |

### 4. HRRelation

**库**：`hrflagwxsp`　**行数**：222,923　**字段数**：13

**用途**：好友关系表，一条记录代表一次申请/通过，IsTake 表示处理状态

**关联接口**：Apply/AddUserApply、AdoptUserApply、PassUserApply

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Id` | int |  | 否 |  | **PK** | 自增 |
| `OpenId` | nvarchar | 200 | 否 |  |  |  |
| `OpenIdPass` | nvarchar | 200 | 否 |  |  |  |
| `Status` | int |  | 否 | ((0)) |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `UpdateTime` | datetime |  | 是 |  |  |  |
| `IsSendMsg` | int |  | 否 | ((1)) |  |  |
| `IsDelete` | int |  | 否 | ((0)) |  |  |
| `Remarks` | nvarchar | 100 | 是 |  |  |  |
| `IPAddress` | nvarchar | 50 | 是 |  |  |  |
| `IPAttach` | nvarchar | 50 | 是 |  |  |  |
| `SenderPhone` | varchar | 11 | 是 |  |  | 发送人手机号 |
| `ReceiverPhone` | varchar | 11 | 是 |  |  | 接收人手机号 |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| Index_All | NONCLUSTERED | 否 | CreateTime,OpenId,OpenIdPass |
| IX_HRRelation_SenderPhone | NONCLUSTERED | 否 | SenderPhone |
| IX_HRRelation_ReceiverPhone | NONCLUSTERED | 否 | ReceiverPhone |
| IX_HRRelation_Sender | NONCLUSTERED | 否 | SenderPhone,IsDelete,ReceiverPhone |
| IX_HRRelation_Receiver | NONCLUSTERED | 否 | ReceiverPhone,IsDelete,SenderPhone |

### 5. UserFollows

**库**：`hrflagwxsp`　**行数**：205,441　**字段数**：6

**用途**：用户关注关系表（单向关注），支撑帖子关注流

**关联接口**：Community/ListOfPosts、FollowOrUnfollow（社区复用）

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `FollowId` | uniqueidentifier |  | 否 | (newid()) | **PK** |  |
| `FollowerPhone` | varchar | 11 | 否 |  |  |  |
| `FollowingPhone` | varchar | 11 | 否 |  |  |  |
| `IpAddress` | varchar | 40 | 否 |  |  |  |
| `IPLocation` | nvarchar | 100 | 否 |  |  |  |
| `FollowTime` | datetime |  | 是 | (getdate()) |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| IX_UserFollows_FollowerPhone_FollowingPhone | NONCLUSTERED | 否 | FollowerPhone,FollowingPhone |
| IX_UserFollows_FollowerPhone | NONCLUSTERED | 否 | FollowerPhone |
| IX_UserFollows_FollowingPhone_FollowerPhone | NONCLUSTERED | 否 | FollowingPhone,FollowerPhone |
| IX_UserFollows_Follower_Following | NONCLUSTERED | 否 | FollowerPhone,FollowingPhone |
| IX_UserFollows_Following_Follower | NONCLUSTERED | 否 | FollowingPhone,FollowerPhone |

### 6. UserHomePage

**库**：`hrflagwxsp`　**行数**：20,075　**字段数**：8

**用途**：个人主页配置表（背景、展示开关等）

**关联接口**：Apply/AdoptUserApply、社区关注

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Phone` | varchar | 11 | 否 |  | **PK** |  |
| `VermicelliCount` | int |  | 是 | ((0)) |  |  |
| `FollowCount` | int |  | 是 | ((0)) |  |  |
| `BePraisedCount` | int |  | 是 | ((0)) |  |  |
| `PostCount` | int |  | 是 | ((0)) |  |  |
| `IPGeolocation` | nvarchar | 20 | 是 | ('未知') |  |  |
| `CreateTime` | datetime |  | 是 | (getdate()) |  |  |
| `PageViews` | int |  | 是 | ((0)) |  |  |

### 7. User

**库**：`hrflag`　**行数**：248,143　**字段数**：23

**用途**：主站账号主表，手机号、姓名、公司、部门、职位、行业、删除标记

**关联接口**：Contacts/GetUserInfoByPhone、GetConnections、广告与埋点

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `UserId` | nvarchar | 100 | 否 |  | **PK** |  |
| `Name` | nvarchar | 100 | 是 |  |  |  |
| `Sex` | nvarchar | 50 | 是 |  |  |  |
| `PhoneNumber` | nvarchar | 100 | 是 |  |  |  |
| `PhonePlace` | nvarchar | 100 | 是 | ('') |  |  |
| `Email` | nvarchar | 200 | 是 |  |  |  |
| `Company` | nvarchar | 100 | 是 |  |  |  |
| `TradName` | nvarchar | 200 | 是 |  |  |  |
| `Department` | nvarchar | 200 | 是 |  |  |  |
| `Position` | nvarchar | 100 | 是 |  |  |  |
| `Comefrom` | nvarchar | 100 | 是 |  |  |  |
| `IPAddress` | nvarchar | 50 | 是 | ('') |  |  |
| `IPAttach` | nvarchar | 50 | 是 | ('') |  |  |
| `ExTypeNumber` | int |  | 是 |  |  |  |
| `ActTypeNumber` | int |  | 是 |  |  |  |
| `UpdateTime` | datetime |  | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `IsBlackList` | int |  | 是 |  |  |  |
| `IsDelete` | bit |  | 是 | ((0)) |  |  |
| `CheckStatus` | int |  | 是 | ((1)) |  |  |
| `Remark` | nvarchar | 200 | 是 |  |  |  |
| `UserRemark` | nvarchar | 200 | 是 |  |  |  |
| `BatchId` | uniqueidentifier |  | 是 | ('00000000-0000-0000-0000-000000000000') |  | 导入excel批次id |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| User_Index | NONCLUSTERED | 否 | CreateTime,UpdateTime,PhoneNumber |
| <Name of Missing Index, sysname,> | NONCLUSTERED | 否 | PhoneNumber |
| IX_User_PhoneNumber | NONCLUSTERED | 否 | PhoneNumber |

### 8. VipUser

**库**：`hrflag`　**行数**：1,563　**字段数**：14

**用途**：VIP 会员信息表，记录会员等级与权益

**关联接口**：Contacts/GetUserInfoByid

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `UserId` | nvarchar | 50 | 否 |  | **PK** |  |
| `CompanyId` | nvarchar | 50 | 是 |  |  |  |
| `Name` | nvarchar | 100 | 是 |  |  |  |
| `Phone` | nvarchar | 100 | 是 |  |  |  |
| `Department` | nvarchar | 100 | 是 |  |  |  |
| `Position` | nvarchar | 100 | 是 |  |  |  |
| `Email` | nvarchar | 100 | 是 |  |  |  |
| `TradName` | nvarchar | 100 | 是 |  |  |  |
| `WxORQq` | nvarchar | 100 | 是 |  |  |  |
| `SpareEmail` | nvarchar | 100 | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `Status` | int |  | 是 |  |  |  |
| `IsDelete` | int |  | 是 |  |  |  |
| `Remarks` | nvarchar | 100 | 是 |  |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| Index_All | NONCLUSTERED | 否 | CompanyId,IsDelete,Phone |

### 9. UserPhoto

**库**：`hrflag`　**行数**：124　**字段数**：4

**用途**：用户头像表，主站上传头像地址

**关联接口**：UserInfo/GetUserById（公共布局）

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `UserPhoneNo` | nvarchar | 11 | 否 |  | **PK** |  |
| `UserPhotoUrl` | nvarchar | 500 | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `UpdateTime` | datetime |  | 是 |  |  |  |

### 10. ActiveMeeting

**库**：`hrflag`　**行数**：244　**字段数**：12

**用途**：会议/活动推荐位主表，侧栏"热点会议与活动"数据源

**关联接口**：ActiveMeeting/GetinnerActivemeetingNew、GetActivemeeting

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `ActiveId` | int |  | 否 |  | **PK** | 自增 |
| `ActiveName` | nvarchar | 200 | 是 |  |  |  |
| `SourceUrl` | nvarchar | 500 | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `BrowseNum` | nvarchar | 100 | 是 |  |  |  |
| `ClickView` | nvarchar | 100 | 是 |  |  |  |
| `Status` | int |  | 是 |  |  |  |
| `SeqNo` | int |  | 是 |  |  |  |
| `Remark` | nvarchar | 100 | 是 |  |  |  |
| `IsDel` | int |  | 是 |  |  |  |
| `PastDue` | datetime |  | 是 |  |  |  |
| `ActivtyID` | nvarchar | 100 | 是 |  |  |  |

### 11. ActiveMeetingClickRecord

**库**：`hrflag`　**行数**：4,686　**字段数**：3

**用途**：会议活动点击流水

**关联接口**：ActiveMeeting/ActiveClickRecord

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `UserId` | nvarchar | 100 | 是 |  |  |  |
| `ADId` | int |  | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |

### 12. QuestionnaireInfo

**库**：`hrflag`　**行数**：2,132　**字段数**：10

**用途**：问卷信息表，与活动（ActivtyID）关联，侧栏取演讲嘉宾用

**关联接口**：ActiveMeeting/GetinnerActivemeetingNew

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `QId` | varchar | 50 | 否 |  | **PK** |  |
| `QTitle` | nvarchar | 200 | 否 |  |  |  |
| `SceneId` | nvarchar | 200 | 否 |  |  |  |
| `SpeakerId` | nvarchar | 500 | 是 |  |  |  |
| `BeginTime` | datetime |  | 是 |  |  |  |
| `EndTime` | datetime |  | 是 |  |  |  |
| `IsOnLineType` | int |  | 是 | ((0)) |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `IsDelete` | int |  | 是 | ((0)) |  |  |
| `ActivityId` | nvarchar | 100 | 是 |  |  |  |

### 13. Company

**库**：`hrflag`　**行数**：3,747　**字段数**：15

**用途**：公司主表，ComId/ComName，快讯与报告出品方关联

**关联接口**：FileMgr/GetHighForceFileld、Twitter 侧栏

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `ComId` | nvarchar | 100 | 否 |  | **PK** |  |
| `ComName` | nvarchar | 100 | 是 |  |  |  |
| `ComEng` | nvarchar | 100 | 是 |  |  |  |
| `Image` | nvarchar | 100 | 是 |  |  |  |
| `CTId` | nvarchar | 50 | 是 |  |  |  |
| `Describtion` | nvarchar | 2000 | 是 |  |  |  |
| `PhoneNumber` | nvarchar | 100 | 是 |  |  |  |
| `Email` | nvarchar | 100 | 是 |  |  |  |
| `Website` | nvarchar | 100 | 是 |  |  |  |
| `UpdateTime` | datetime |  | 是 |  |  |  |
| `UpdateUser` | nvarchar | 100 | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `CreateUser` | nvarchar | 100 | 是 |  |  |  |
| `IsDelete` | bit |  | 是 |  |  |  |
| `Remark` | nvarchar | 200 | 是 |  |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| Index_All | NONCLUSTERED | 否 | ComName |

### 14. Twitter

**库**：`hrflag`　**行数**：8,150　**字段数**：20

**用途**：快讯主表，标题、正文、浏览量、分类、发布公司

**关联接口**：Twitter/GetHrflagTwitter、ChangeTwitters

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Guid` | nvarchar | 100 | 否 |  | **PK** |  |
| `TName` | nvarchar | 200 | 是 |  |  |  |
| `TContent` | ntext |  | 是 |  |  |  |
| `BTContent` | text |  | 是 |  |  |  |
| `TImage` | nvarchar | 200 | 是 |  |  |  |
| `TPubName` | nvarchar | 100 | 是 |  |  |  |
| `TClass` | nvarchar | 100 | 是 |  |  |  |
| `TWebSite` | nvarchar | max | 是 |  |  |  |
| `PageView` | int |  | 是 | ((0)) |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `SeqNo` | int |  | 是 | ((0)) |  |  |
| `Status` | int |  | 是 | ((0)) |  |  |
| `IsDelete` | int |  | 是 | ((0)) |  |  |
| `Advertising` | int |  | 是 | ((1)) |  |  |
| `AdvertisingType` | int |  | 是 | ((3)) |  |  |
| `AdvertisingContent` | nvarchar | max | 是 | ('') |  |  |
| `VideoLinkId` | nvarchar | 200 | 是 |  |  |  |
| `VideoName` | nvarchar | max | 是 |  |  |  |
| `InfoGraphicsId` | nvarchar | 100 | 是 | ('') |  |  |
| `ExpireTime` | datetime |  | 是 |  |  |  |

### 15. TwitterClass

**库**：`hrflag`　**行数**：8　**字段数**：5

**用途**：快讯分类字典

**关联接口**：Twitter/GetHrflagTwitter（关联 ClassName）

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `ClassId` | nvarchar | 50 | 否 |  |  |  |
| `ClassName` | nvarchar | 50 | 是 |  |  |  |
| `SeqNo` | int |  | 是 |  |  |  |
| `IsDelete` | int |  | 是 | ((0)) |  |  |
| `ClassIdV50` | varchar | 50 | 是 |  |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| IX_TwitterClass_ClassId | NONCLUSTERED | 否 | ClassId |
| IX_TwitterClass_ClassIdV50 | NONCLUSTERED | 否 | ClassIdV50 |

### 16. TwitterShare

**库**：`hrflag`　**行数**：512　**字段数**：3

**用途**：快讯分享记录，按 Guid + UserId 记录

**关联接口**：Twitter/AddTwitterShare、GetUserShares

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Guid` | nvarchar | 100 | 是 |  |  |  |
| `UserId` | nvarchar | 100 | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |

### 17. TwitterUserLike

**库**：`hrflag`　**行数**：23,568　**字段数**：3

**用途**：快讯点赞记录，按 Guid + UserId 记录

**关联接口**：Twitter/AddTwitterLike、GetUserLike

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Guid` | nvarchar | 100 | 是 |  |  |  |
| `UserId` | nvarchar | 100 | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |

### 18. TopAD

**库**：`hrflag`　**行数**：41　**字段数**：12

**用途**：顶部通栏广告表，含 ShowNum 曝光计数

**关联接口**：Advertising/IGetTopAD、IAddTopADViewRecord

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Id` | int |  | 否 |  | **PK** | 自增 |
| `Name` | nvarchar | 500 | 是 |  |  |  |
| `ImagePath` | nvarchar | 500 | 是 |  |  |  |
| `Interlinkage` | nvarchar | 500 | 是 |  |  |  |
| `Random` | nvarchar | 300 | 是 |  |  |  |
| `ShowNum` | int |  | 是 |  |  |  |
| `ClickNum` | int |  | 是 |  |  |  |
| `State` | int |  | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `IsDelete` | bit |  | 是 |  |  |  |
| `PastDue` | datetime |  | 是 |  |  |  |
| `Remark` | nvarchar | 100 | 是 |  |  |  |

### 19. TopADClickRecord

**库**：`hrflag`　**行数**：1,219　**字段数**：3

**用途**：顶部广告点击流水

**关联接口**：Advertising/IAddTopADClickRecord

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `UserId` | nvarchar | 100 | 是 |  |  |  |
| `ADId` | int |  | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |

### 20. MeetingUPClickRecord

**库**：`hrflag`　**行数**：166　**字段数**：3

**用途**：会议/通用广告点击流水（人脉页广告位复用）

**关联接口**：Advertising/Advertising/IAddMeetingUPClickRecord

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `UserId` | nvarchar | 100 | 是 |  |  |  |
| `ADId` | int |  | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |

### 21. PersonConnectionAdv

**库**：`hrflag`　**行数**：7　**字段数**：11

**用途**：人脉首页广告位配置表，含 Location 位置标识

**关联接口**：Advertising/IGetPersonConnectionAdv

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Id` | int |  | 否 |  |  | 自增 |
| `Name` | nvarchar | 500 | 是 |  |  |  |
| `ImagePath` | nvarchar | 500 | 是 |  |  |  |
| `Interlinkage` | nvarchar | 500 | 是 |  |  |  |
| `ShowNum` | int |  | 是 |  |  |  |
| `ClickNum` | int |  | 是 |  |  |  |
| `State` | int |  | 是 |  |  |  |
| `Location` | int |  | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `IsDelete` | bit |  | 是 |  |  |  |
| `PastDue` | datetime |  | 是 |  |  |  |

### 22. FriendApplyFor

**库**：`hrflag`　**行数**：17　**字段数**：11

**用途**：好友申请页广告位配置表

**关联接口**：Advertising/IGetFriendApplyForAdv

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Id` | int |  | 否 |  |  | 自增 |
| `Name` | nvarchar | 500 | 是 |  |  |  |
| `ImagePath` | nvarchar | 500 | 是 |  |  |  |
| `Interlinkage` | nvarchar | 500 | 是 |  |  |  |
| `ShowNum` | int |  | 是 |  |  |  |
| `ClickNum` | int |  | 是 |  |  |  |
| `State` | int |  | 是 |  |  |  |
| `Location` | int |  | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `IsDelete` | bit |  | 是 |  |  |  |
| `PastDue` | datetime |  | 是 |  |  |  |

### 23. FriendTable

**库**：`hrflag`　**行数**：19　**字段数**：11

**用途**：好友列表页广告位配置表

**关联接口**：Advertising/IGetFriendTableAdv

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Id` | int |  | 否 |  |  | 自增 |
| `Name` | nvarchar | 500 | 是 |  |  |  |
| `ImagePath` | nvarchar | 500 | 是 |  |  |  |
| `Interlinkage` | nvarchar | 500 | 是 |  |  |  |
| `ShowNum` | int |  | 是 |  |  |  |
| `ClickNum` | int |  | 是 |  |  |  |
| `State` | int |  | 是 |  |  |  |
| `Location` | int |  | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `IsDelete` | bit |  | 是 |  |  |  |
| `PastDue` | datetime |  | 是 |  |  |  |

### 24. StrangerAD

**库**：`hrflag`　**行数**：20　**字段数**：11

**用途**：陌生人/好友主页广告位配置表

**关联接口**：Advertising/IGetStrangerADAdv

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Id` | int |  | 否 |  |  | 自增 |
| `Name` | nvarchar | 500 | 是 |  |  |  |
| `ImagePath` | nvarchar | 500 | 是 |  |  |  |
| `Interlinkage` | nvarchar | 500 | 是 |  |  |  |
| `ShowNum` | int |  | 是 |  |  |  |
| `ClickNum` | int |  | 是 |  |  |  |
| `State` | int |  | 是 |  |  |  |
| `Location` | int |  | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `IsDelete` | bit |  | 是 |  |  |  |
| `PastDue` | datetime |  | 是 |  |  |  |

### 25. FileLibrary

**库**：`hrflag`　**行数**：19,305　**字段数**：29

**用途**：研究报告主表，报告名称、封面、页数、下载/预览数

**关联接口**：FileMgr/GetHighForceFileld

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `FileId` | nvarchar | 100 | 否 |  | **PK** |  |
| `Name` | nvarchar | 200 | 是 |  |  |  |
| `Image` | nvarchar | 300 | 是 |  |  |  |
| `SmallImage` | nvarchar | 500 | 是 |  |  |  |
| `Describtion` | ntext |  | 是 |  |  |  |
| `DescribtionText` | ntext |  | 是 |  |  |  |
| `ReleaseTime` | nvarchar | 20 | 是 |  |  |  |
| `FId` | nvarchar | 100 | 是 |  |  |  |
| `FCId` | nvarchar | 1000 | 是 |  |  |  |
| `FileCategoryId` | int |  | 是 |  |  |  |
| `FTId` | nvarchar | 100 | 是 |  |  |  |
| `UploadUnit` | nvarchar | 1000 | 是 |  |  |  |
| `Downloads` | int |  | 是 |  |  |  |
| `PageViews` | int |  | 是 |  |  |  |
| `KeyWords` | nvarchar | 100 | 是 |  |  |  |
| `Fitf` | bit |  | 是 |  |  |  |
| `SeqNo` | int |  | 是 |  |  |  |
| `CreateUser` | nvarchar | 100 | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `UpdateUser` | nvarchar | 100 | 是 |  |  |  |
| `UpdateTime` | datetime |  | 是 |  |  |  |
| `IsDelete` | bit |  | 是 |  |  |  |
| `Remark` | nvarchar | 200 | 是 |  |  |  |
| `CompanyId` | nvarchar | 1000 | 是 |  |  |  |
| `IsForm` | varchar | 50 | 是 |  |  |  |
| `AIReportSummary` | nvarchar | max | 是 | ('') |  |  |
| `OssKey` | nvarchar | 500 | 是 |  |  |  |
| `IsPreviewDirty` | bit |  | 否 | ((1)) |  |  |
| `ReportCount` | int |  | 是 | ((0)) |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| Index_All | NONCLUSTERED | 否 | FCId,CreateTime,IsDelete |

### 26. FileAttach

**库**：`hrflag`　**行数**：22,128　**字段数**：12

**用途**：报告附件表，记录页数等

**关联接口**：FileMgr/GetHighForceFileld（FilePages 子查询）

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `FId` | nvarchar | 100 | 否 |  | **PK** |  |
| `FileName` | nvarchar | 200 | 是 |  |  |  |
| `ExtensionName` | nvarchar | 20 | 是 |  |  |  |
| `FolderName` | nvarchar | 100 | 是 |  |  |  |
| `RelativePath` | nvarchar | 200 | 是 |  |  |  |
| `FileSize` | nvarchar | 200 | 是 |  |  |  |
| `FilePages` | int |  | 是 |  |  |  |
| `CreateUser` | nvarchar | 100 | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `IsDelete` | bit |  | 是 |  |  |  |
| `Remark` | nvarchar | 200 | 是 |  |  |  |
| `AlyUrl` | nvarchar | 500 | 是 |  |  |  |

### 27. DownRecord

**库**：`hrflag`　**行数**：428,935　**字段数**：10

**用途**：报告下载记录，用于近 7 天/当天下载榜统计

**关联接口**：FileMgr/GetHighForceFileld

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `DrId` | nvarchar | 100 | 否 |  | **PK** |  |
| `UserId` | nvarchar | 50 | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `FileId` | nvarchar | 50 | 是 |  |  |  |
| `IPAddress` | nvarchar | 50 | 是 |  |  |  |
| `CityId` | nvarchar | 100 | 是 |  |  |  |
| `CityName` | nvarchar | 100 | 是 |  |  |  |
| `Source` | int |  | 是 |  |  |  |
| `ProjectType` | nvarchar | 100 | 是 |  |  |  |
| `IsDelete` | nvarchar | 50 | 是 |  |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| Index_All | NONCLUSTERED | 否 | CreateTime,UserId |

### 28. ThinkerSpeaker

**库**：`hrflagdataonline`　**行数**：1,774　**字段数**：15

**用途**：演讲嘉宾表（在线活动库），侧栏会议卡片头像与嘉宾信息

**关联接口**：ActiveMeeting/GetinnerActivemeetingNew

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `SpeakerId` | nvarchar | 50 | 否 |  | **PK** |  |
| `SpeakerName` | nvarchar | 100 | 是 |  |  |  |
| `SpeakerComId` | nvarchar | 50 | 是 |  |  |  |
| `SpeakerPosition` | nvarchar | 100 | 是 |  |  |  |
| `SpeakerPhone` | nvarchar | 100 | 是 |  |  |  |
| `SpeakerEmail` | nvarchar | 100 | 是 |  |  |  |
| `SpeakerImage` | nvarchar | 200 | 是 |  |  |  |
| `SpeakerDes` | text |  | 是 |  |  |  |
| `BSpeakerDes` | ntext |  | 是 |  |  |  |
| `Speakerintroduce` | text |  | 是 |  |  |  |
| `BSpeakerintroduce` | ntext |  | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `IsDelete` | int |  | 是 | ((0)) |  |  |
| `Status` | int |  | 是 | ((0)) |  |  |
| `Reamrks` | nvarchar | 50 | 是 |  |  |  |

### 29. ThinkerCompanyInfo

**库**：`hrflagdataonline`　**行数**：4,697　**字段数**：51

**用途**：演讲嘉宾所属公司表，公司全称/中英文简称

**关联接口**：ActiveMeeting/GetinnerActivemeetingNew、Activity/ComPrivacy

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `CompanyId` | nvarchar | 4000 | 是 |  |  |  |
| `CompanyName` | nvarchar | 4000 | 是 |  |  |  |
| `ChiAbbreviation` | nvarchar | 4000 | 是 |  |  |  |
| `EnAbbreviation` | nvarchar | 4000 | 是 |  |  |  |
| `LogoPath` | nvarchar | max | 是 |  |  |  |
| `PropagandaVideo` | nvarchar | 4000 | 是 |  |  |  |
| `VideoImagePath` | nvarchar | 4000 | 是 |  |  |  |
| `CompanyDataPath` | nvarchar | 4000 | 是 |  |  |  |
| `CompanyLabel` | nvarchar | 4000 | 是 |  |  |  |
| `CompanytDescribtion` | nvarchar | max | 是 |  |  |  |
| `BCompanyDescribtion` | nvarchar | max | 是 |  |  |  |
| `CompanyFocus` | nvarchar | 4000 | 是 |  |  |  |
| `CompanyProduct` | nvarchar | max | 是 |  |  |  |
| `CompanyClass` | nvarchar | 50 | 是 |  |  |  |
| `CompanyCountry` | nvarchar | 50 | 是 |  |  |  |
| `CompanyList` | int |  | 是 | ((0)) |  |  |
| `ListedCity` | nvarchar | max | 是 |  |  |  |
| `Code` | nvarchar | 4000 | 是 |  |  |  |
| `EmployNum` | nvarchar | max | 是 |  |  |  |
| `Date` | nvarchar | 4000 | 是 |  |  |  |
| `CompanyAdress` | nvarchar | max | 是 |  |  |  |
| `WebSite` | nvarchar | 4000 | 是 |  |  |  |
| `CompanyEmail` | nvarchar | 4000 | 是 |  |  |  |
| `CompanyPhone` | nvarchar | 50 | 是 |  |  |  |
| `CompanyRQCode` | nvarchar | 4000 | 是 |  |  |  |
| `LinkedInWebSite` | nvarchar | 4000 | 是 |  |  |  |
| `ContactsName` | nvarchar | 20 | 是 |  |  |  |
| `ContactsWx` | nvarchar | 4000 | 是 |  |  |  |
| `ContactsPhone` | nvarchar | 11 | 是 |  |  |  |
| `PhoneAreaCode` | nvarchar | 10 | 是 |  |  |  |
| `Telephone` | nvarchar | 20 | 是 |  |  |  |
| `ContactsEmail` | nvarchar | 50 | 是 |  |  |  |
| `ContactsLinkedIn` | nvarchar | 50 | 是 |  |  |  |
| `FormInfo` | nvarchar | 4000 | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `IsDelete` | int |  | 是 | ((0)) |  |  |
| `Status` | int |  | 是 | ((0)) |  |  |
| `Privacy` | nvarchar | 4000 | 是 |  |  |  |
| `PhoneExtension` | nvarchar | 20 | 是 | (NULL) |  |  |
| `CompanyLogoFilePath` | nvarchar | 4000 | 是 | (NULL) |  |  |
| `City` | nvarchar | 50 | 是 | (NULL) |  |  |
| `County` | nvarchar | 50 | 是 | (NULL) |  |  |
| `ContactsIndustry` | nvarchar | 4000 | 是 | (NULL) |  |  |
| `ContactsDepartment` | nvarchar | 4000 | 是 | (NULL) |  |  |
| `ContactsPosition` | nvarchar | 4000 | 是 | (NULL) |  |  |
| `province` | nvarchar | 50 | 是 |  |  |  |
| `CityList` | nvarchar | 50 | 是 |  |  |  |
| `ProjectId` | nvarchar | 100 | 是 |  |  |  |
| `CompanyLocation` | nvarchar | 4000 | 是 | ('') |  |  |
| `Industry` | nvarchar | max | 是 |  |  |  |
| `IndustryId` | varchar | 155 | 是 | ('') |  | 关联行业Id |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| Index_All | NONCLUSTERED | 否 | CompanyId |
| IX_ThinkerCompanyInfo_CompanyId | NONCLUSTERED | 否 | CompanyId |

### 30. SceneInfo

**库**：`hrflagactivities`　**行数**：2,477　**字段数**：28

**用途**：活动场次表，取场次开始日期与城市，供侧栏活动卡片展示

**关联接口**：ActiveMeeting/GetinnerActivemeetingNew

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `ActivityId` | nvarchar | 200 | 否 |  | **PK** |  |
| `SceneId` | nvarchar | 200 | 否 |  | **PK** |  |
| `SceneName` | nvarchar | 200 | 是 |  |  |  |
| `SceneCounty` | nvarchar | 200 | 是 |  |  |  |
| `ScenePlace` | nvarchar | 200 | 是 |  |  |  |
| `SignUpPerson` | nvarchar | 50 | 是 |  |  |  |
| `SceneBeginDate` | datetime |  | 是 |  |  |  |
| `SceneEndDate` | datetime |  | 是 |  |  |  |
| `ScenePeopleNum` | int |  | 是 | ((0)) |  |  |
| `SceneStatus` | int |  | 是 | ((1)) |  |  |
| `SeqNo` | int |  | 是 |  |  |  |
| `IsDelete` | int |  | 是 | ((0)) |  |  |
| `EndSignUp` | int |  | 是 | ((0)) |  |  |
| `IsClose` | int |  | 是 | ((0)) |  |  |
| `IsDraft` | int |  | 是 | ((0)) |  |  |
| `IsShare` | int |  | 是 | ((0)) |  | 活动是否开启 |
| `IsSignIn` | bit |  | 是 | ((0)) |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `Remarks` | nvarchar | 200 | 是 |  |  |  |
| `LiaisonName` | nvarchar | 50 | 是 |  |  |  |
| `LiaisonPhone` | nvarchar | 100 | 是 |  |  |  |
| `LiaisonEmail` | nvarchar | 100 | 是 |  |  |  |
| `PrivacyAuthorization` | nvarchar | 500 | 是 | ('') |  |  |
| `ActivitySponsorTwo` | nvarchar | 500 | 是 |  |  |  |
| `IsReturn` | int |  | 是 | ((2)) |  |  |
| `AttendPlace` | nvarchar | 100 | 是 | ('') |  |  |
| `IsSCRM` | int |  | 是 | ((1)) |  |  |
| `CheckQuantity` | int |  | 是 | ((0)) |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| Index_All | NONCLUSTERED | 否 | IsClose,ActivityId,SceneName,SceneCounty |
| IX_SceneInfo_IsDelete_SceneId | NONCLUSTERED | 否 | IsDelete,SceneId |
| IX_SceneInfo_ActivityId | NONCLUSTERED | 否 | ActivityId |

### 31. CityInfoCfg

**库**：`hrflagactivities`　**行数**：44　**字段数**：2

**用途**：城市字典表

**关联接口**：ActiveMeeting/GetinnerActivemeetingNew

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `CityName` | nvarchar | 500 | 是 |  |  |  |
| `CityCode` | nvarchar | 50 | 是 |  |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| Index_All | NONCLUSTERED | 否 | CityCode |

### 32. CountyInfoCfg

**库**：`hrflagactivities`　**行数**：480　**字段数**：3

**用途**：国家/地区字典表

**关联接口**：ActiveMeeting/GetinnerActivemeetingNew

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `ID` | int |  | 否 |  | **PK** | 自增 |
| `CityCode` | nvarchar | 50 | 是 |  |  |  |
| `CountryName` | nvarchar | 500 | 是 |  |  |  |

---

## 3. 表关系与联调要点

### 3.1 主链路

```
User(hrflag) ──PhoneNumber──┐
                            ↓
                    HRUserInfo(hrflagwxsp, PK=OpenId)
                     ├── HRUser_ImgAddress(OpenId)
                     ├── HRUser_Action(OpenId, KindId+ContentId)
                     ├── HRRelation(申请人/被申请人 OpenId, IsTake)
                     ├── UserFollows(OpenId)
                     └── UserHomePage(OpenId)
```

- **身份连通**：`Contacts/GetUserInfoByPhone` 以手机号查 `HRUserInfo`，并在 SQL 内子查询 `hrflag.dbo.User` 取 `UserId`，这就是前端 Cookie `UserId` 的来源；人脉体系内一律用 `OpenId`。
- **行为编码**：`HRUser_Action` 是"是否已浏览 / 已点赞 / 已申请"的唯一判据，`KindId=1` 配合 `ContentId`（2 浏览、9 点赞、11 加好友），`Remarks` 存对方 `OpenId` 或手机号。
- **好友状态**：`HRRelation.IsTake`（0 未处理 / 1 已同意 / 2 已忽略）直接映射为接口返回的 `IsTake`。
- **广告位**：`PersonConnectionAdv`、`FriendApplyFor`、`FriendTable`、`StrangerAD` 四张配置表结构一致（`Id`、`Name`、`ImagePath`、`Interlinkage`、`Location`），每次查询都会写一条曝光；点击分别落 `TopADClickRecord`、`MeetingUPClickRecord`。
- **侧栏内容**：`hrflag.ActiveMeeting` → `QuestionnaireInfo` → `hrflagdataonline.ThinkerSpeaker / ThinkerCompanyInfo`，场次信息再跨库取 `hrflagactivities.SceneInfo / CityInfoCfg / CountyInfoCfg`。

### 3.2 性能与索引提示

- `HRUser_Action` 已 252 万行，接口普遍按 `OpenId + KindId + ContentId + Remarks` 组合查询，若索引缺失会全表扫描，是"谁看过我""我点赞了谁"慢查询的首要排查点。
- `HRUserInfo` 以 `OpenId` 为主键，但登录、搜索入口按 `PhoneNo` 查，需确认 `PhoneNo` 上有索引。
- `DownRecord` 42.9 万行，`GetHighForceFileld` 按 `CreateTime` 区间 + `GROUP BY FileId` 统计，建议在 `CreateTime` 上有索引。

### 3.3 字段陷阱

- `HRUserInfo.Image`、`ActivityLogo` 等为**相对路径**，前端需拼 `FilePath`；空值返回 `../../files/imgs/tou.png` 的场景要按默认头像处理。
- `HRUser_Action` 无自增主键之外的时间索引时，`GetLookUser` 的 `DISTINCT` + 分页代价较高，分页务必带 `page/limit`。
- `Twitter`、`TwitterShare`、`TwitterUserLike` 的 `Guid` 为字符串主键，跨表关联时注意大小写与空格。
