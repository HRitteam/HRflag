# 会议与活动（Events）模块表结构

本表结构由源码调用链定位：先按 接口源码/03-会议与活动（Events）接口源码对照.md 找到 Helper 方法，再从 Helper 的 SQL 中提取表名，最后读取数据库元数据生成字段清单。所有查询均为只读。

| 项目 | 内容 |
|---|---|
| 数据库 | `hrflag`（主站）、`hrflagwxsp`（人脉/社区）、`hrflagactivities`（活动） |
| 实例 | `rm-bp1qz3lr4bu51dy5eso.sqlserver.rds.aliyuncs.com`（SQL Server 2012，只读查询） |
| 表数量 | 25 张 |
| 采集时间 | 2026-11-17 |
| 采集方式 | 直接读取 `sys.columns` / `sys.indexes` / `sys.foreign_keys` / `sys.extended_properties` |

## 1. 表清单

| # | 库 | 表名 | 行数 | 字段数 | 用途 | 关联接口 |
|---|---|---|---|---|---|---|
| 1 | hrflagactivities | ActivityInfo | 1,363 | 35 | 活动主表，活动标题、主办方、封面、审核方式、浏览量、活动类型、状态 | Activity/GetActivityListTwo、GetHRflagActivityByIdNewShow、IfFormIsBuy |
| 2 | hrflagactivities | SceneInfo | 2,477 | 28 | 场次表，一场活动多个场次，含时间、城市、场地、是否关闭、报名截止 | Activity/GetSceneInfoNew、GetActivityListTwo、GetHRflagActivityByIdNewShow |
| 3 | hrflagactivities | CustomerInfo | 301,801 | 41 | 报名记录表（当前主用），手机号 + 场次 + 票种，含审核状态、签到状态 | Activity/AddCustomerInfo、GetSceneInfoNew、IfUserIsApply、BulkUpdatesFormOrderNew |
| 4 | hrflagactivities | CustomerInfoNew | 301,859 | 44 | 报名记录表（新版），动态表单提交写入 | NewForm/AddCustomerInfoTwo、UpdateUserByPhone、BulkUpdatesFormOrderNew |
| 5 | hrflagactivities | SellTicketsInfo | 247,656 | 9 | 售票/票务明细表，按订单与票种记录 | Activity/AddCustomerInfo |
| 6 | hrflag | FormOrderInfo | 2,732 | 17 | 表单订单表，订单号、金额、支付方式、支付状态、收货地址 | FormOrder/AddFormOrderInfo、IfIsNoPayment、UpdatePayTime |
| 7 | hrflag | TakeDeliveryInfo | 1,920 | 8 | 收货地址表，付费且含实物的活动报名使用 | FormOrder/GetTakeDeliveryInfo |
| 8 | hrflagactivities | CityInfoCfg | 44 | 2 | 城市字典表（CityCode/CityName） | Activity/GetActivityListTwo、GetActivityInfoMap |
| 9 | hrflagactivities | CountyInfoCfg | 480 | 3 | 国家/地区字典表 | Activity/GetActivityListTwo、GetActivityInfoMap |
| 10 | hrflagactivities | ActivityTypeCfg | 16 | 4 | 活动类型字典表 | Activity/GetHRflagActivityByIdNew、ActivityUser/GetAllActivityType |
| 11 | hrflagdataonline | SCRMForm | 946 | 13 | SCRM 动态表单配置表，主办方自定义题目 | NewForm/AddCustomerInfoTwo |
| 12 | hrflagdataonline | SCRMFormHistory | 5,480 | 23 | SCRM 表单填写历史 | NewForm/AddCustomerInfoTwo |
| 13 | hrflagdataonline | SCRMDownloadHistory | 714,130 | 27 | SCRM 资料下载记录 | Activity/AddCustomerInfo |
| 14 | hrflagwxsp | ShareActivity | 6 | 15 | 分享有礼配置表（场次维度），含规则、起止时间、达成条件 | ActivitiesShare/WxSelectActivityShare |
| 15 | hrflagwxsp | ActivityPrizes | 12 | 8 | 分享有礼奖品档位表，记录档位人数与奖品图 | ActivitiesShare/WxSelectActivityShare |
| 16 | hrflagactivities | CustomerSource | 284,239 | 5 | 客户渠道来源表 | Activity/AddustomerSoure、ActivitiesShare（渠道统计） |
| 17 | hrflagactivities | ActivitySource | 18,957 | 13 | 活动渠道字典表 | Activity/GetSpecialIdByScenceId、ActivitiesShare |
| 18 | hrflag | User | 248,143 | 23 | 主站账号主表，报名时按手机号关联/更新 | Form/UserRegister、NewForm/UpdateUserByPhone、System/GetUserInfo |
| 19 | hrflag | UserPhoto | 124 | 4 | 用户头像表 | System/GetUserInfo（头像回填） |
| 20 | hrflag | UserInfoHistory | 9,294 | 23 | 用户资料变更历史，报名回写资料时记录 | NewForm/UpdateUserByPhone |
| 21 | hrflag | CustomerInfo | 40,048 | 30 | 主站客户信息表，IsFormSignUp 按表单 + 手机号判断是否已报名 | NewForm/IsFormSignUp |
| 22 | hrflag | ActivityInfo | 911 | 20 | 主站活动表，MenuComPrivacyShow 关联活动与主办方 | Activity/MenuComPrivacyShow、ComPrivacy |
| 23 | hrflag | Company | 3,747 | 15 | 公司主表 | Activity/ComPrivacy、活动侧栏 |
| 24 | hrflagdataonline | ThinkerCompanyInfo | 4,697 | 51 | 主办方公司信息表，隐私条款按 CompanyId 取公司名称 | Activity/ComPrivacy、MenuComPrivacyShow |
| 25 | hrflagwxsp | HRUserInfo | 102,800 | 32 | 人脉用户主表，报名时若存在同名手机号则关联 | Activity/AddCustomerInfo、AddCustomerInfoTwo |

## 2. 表结构详情

### 1. ActivityInfo

**库**：`hrflagactivities`　**行数**：1,363　**字段数**：35

**用途**：活动主表，活动标题、主办方、封面、审核方式、浏览量、活动类型、状态

**关联接口**：Activity/GetActivityListTwo、GetHRflagActivityByIdNewShow、IfFormIsBuy

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `ActivityId` | nvarchar | 200 | 否 |  | **PK** |  |
| `ActivityTitle` | nvarchar | 500 | 是 |  |  |  |
| `ActivityType` | nvarchar | 100 | 是 |  |  |  |
| `ActivityTypeChl` | nvarchar | 200 | 是 |  |  |  |
| `ActivityClass` | nvarchar | 200 | 是 |  |  |  |
| `ActivityBright` | nvarchar | max | 是 |  |  |  |
| `ActivityUrl` | nvarchar | 200 | 是 |  |  |  |
| `ImageUrl` | nvarchar | 500 | 是 |  |  |  |
| `MainBody` | ntext |  | 是 |  |  |  |
| `ActivitySponsor` | nvarchar | 250 | 是 |  |  |  |
| `ActivityLabel` | nvarchar | 200 | 是 |  |  |  |
| `PageView` | int |  | 是 |  |  |  |
| `ClickView` | int |  | 是 |  |  |  |
| `ActivityCheck` | int |  | 是 |  |  |  |
| `ActivityTicketCheck` | int |  | 是 |  |  |  |
| `Status` | int |  | 是 | ((1)) |  |  |
| `IsDelete` | int |  | 是 | ((0)) |  |  |
| `IsDraft` | int |  | 是 | ((0)) |  |  |
| `SeqNo` | int |  | 是 |  |  |  |
| `IsClose` | int |  | 是 | ((0)) |  |  |
| `EndSignUp` | int |  | 是 | ((0)) |  |  |
| `EndNorm` | int |  | 是 | ((1)) |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `Remarks` | nvarchar | 1000 | 是 |  |  |  |
| `ActivityLogo` | nvarchar | 500 | 是 |  |  |  |
| `PrivacyAuthorization` | nvarchar | 1500 | 是 |  |  |  |
| `CompanyId` | nvarchar | 500 | 是 |  |  |  |
| `VIPActivity` | int |  | 是 |  |  |  |
| `EnglishActivityTitle` | nvarchar | 200 | 是 |  |  |  |
| `NonMemberPrice` | nvarchar | 100 | 是 | ('') |  |  |
| `ActivitiesLocation` | nvarchar | 300 | 是 | ('') |  |  |
| `Sponsor` | nvarchar | 300 | 是 | ('') |  |  |
| `Formlink` | nvarchar | 300 | 是 | ('') |  |  |
| `OfficialLink` | nvarchar | 300 | 是 | ('') |  |  |
| `IsEmployer` | int |  | 是 | ((0)) |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| Index_All | NONCLUSTERED | 否 | ActivityType,CreateTime |

### 2. SceneInfo

**库**：`hrflagactivities`　**行数**：2,477　**字段数**：28

**用途**：场次表，一场活动多个场次，含时间、城市、场地、是否关闭、报名截止

**关联接口**：Activity/GetSceneInfoNew、GetActivityListTwo、GetHRflagActivityByIdNewShow

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `ActivityId` | nvarchar | 200 | 否 |  | **PK** |  |
| `SceneId` | nvarchar | 200 | 否 |  | **PK** |  |
| `SceneName` | nvarchar | 200 | 是 |  |  |  |
| `SceneCounty` | nvarchar | 200 | 是 |  |  |  |
| `ScenePlace` | nvarchar | 200 | 是 |  |  |  |
| `SignUpPerson` | nvarchar | 50 | 是 |  |  |  |
| `SceneBeginDate` | datetime |  | 是 |  |  |  |
| `SceneEndDate` | datetime |  | 是 |  |  |  |
| `ScenePeopleNum` | int |  | 是 | ((0)) |  |  |
| `SceneStatus` | int |  | 是 | ((1)) |  |  |
| `SeqNo` | int |  | 是 |  |  |  |
| `IsDelete` | int |  | 是 | ((0)) |  |  |
| `EndSignUp` | int |  | 是 | ((0)) |  |  |
| `IsClose` | int |  | 是 | ((0)) |  |  |
| `IsDraft` | int |  | 是 | ((0)) |  |  |
| `IsShare` | int |  | 是 | ((0)) |  | 活动是否开启 |
| `IsSignIn` | bit |  | 是 | ((0)) |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `Remarks` | nvarchar | 200 | 是 |  |  |  |
| `LiaisonName` | nvarchar | 50 | 是 |  |  |  |
| `LiaisonPhone` | nvarchar | 100 | 是 |  |  |  |
| `LiaisonEmail` | nvarchar | 100 | 是 |  |  |  |
| `PrivacyAuthorization` | nvarchar | 500 | 是 | ('') |  |  |
| `ActivitySponsorTwo` | nvarchar | 500 | 是 |  |  |  |
| `IsReturn` | int |  | 是 | ((2)) |  |  |
| `AttendPlace` | nvarchar | 100 | 是 | ('') |  |  |
| `IsSCRM` | int |  | 是 | ((1)) |  |  |
| `CheckQuantity` | int |  | 是 | ((0)) |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| Index_All | NONCLUSTERED | 否 | IsClose,ActivityId,SceneName,SceneCounty |
| IX_SceneInfo_IsDelete_SceneId | NONCLUSTERED | 否 | IsDelete,SceneId |
| IX_SceneInfo_ActivityId | NONCLUSTERED | 否 | ActivityId |

### 3. CustomerInfo

**库**：`hrflagactivities`　**行数**：301,801　**字段数**：41

**用途**：报名记录表（当前主用），手机号 + 场次 + 票种，含审核状态、签到状态

**关联接口**：Activity/AddCustomerInfo、GetSceneInfoNew、IfUserIsApply、BulkUpdatesFormOrderNew

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `OrderNo` | nvarchar | 100 | 否 |  | **PK** |  |
| `PhoneNo` | nvarchar | 11 | 否 |  |  |  |
| `ActivityId` | nvarchar | 200 | 是 |  |  |  |
| `SceneId` | nvarchar | 200 | 是 |  |  |  |
| `TicketId` | nvarchar | 200 | 是 |  |  |  |
| `PurchaseSum` | int |  | 是 |  |  |  |
| `Name` | nvarchar | 50 | 是 |  |  |  |
| `Company` | nvarchar | 150 | 是 |  |  |  |
| `PhoneNoIn` | nvarchar | 100 | 是 |  |  |  |
| `TradName` | nvarchar | 100 | 是 |  |  |  |
| `Position` | nvarchar | 100 | 是 |  |  |  |
| `Department` | nvarchar | 100 | 是 |  |  |  |
| `Email` | nvarchar | 100 | 是 |  |  |  |
| `Comefrom` | nvarchar | 100 | 是 |  |  |  |
| `IPAddress` | nvarchar | 100 | 是 |  |  |  |
| `IPAttach` | nvarchar | 100 | 是 |  |  |  |
| `Status` | int |  | 是 | ((1)) |  |  |
| `IsDelete` | int |  | 是 | ((0)) |  |  |
| `IsSignIns` | int |  | 是 | ((0)) |  |  |
| `IsSignIn` | int |  | 是 | ((0)) |  |  |
| `IsLook` | int |  | 是 | ((0)) |  |  |
| `PayStatus` | int |  | 是 | ((0)) |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `Remarks` | nvarchar | 500 | 是 |  |  |  |
| `SigninTime` | datetime |  | 是 |  |  |  |
| `Signinperson` | nvarchar | 100 | 是 |  |  |  |
| `SigninMode` | nvarchar | 100 | 是 |  |  |  |
| `SigninTimes` | datetime |  | 是 |  |  |  |
| `Signinpersons` | nvarchar | 100 | 是 |  |  |  |
| `SigninModes` | nvarchar | 100 | 是 |  |  |  |
| `IsAgree` | nvarchar | 10 | 是 | ('同意') |  |  |
| `IsPurchaseLy` | int |  | 是 | ((0)) |  | 是否已购买过领英服务  0：默认 1：否 2：是  |
| `IsInterestedLy` | int |  | 是 | ((0)) |  | 是否对领英全球化人才招聘解决方案感兴趣并希望顾问联系 0：默认 1：否 2：是  |
| `CompanyId` | nvarchar | 100 | 是 |  |  | 关联公司 |
| `SignBeginTime` | datetime |  | 是 |  |  | 签到开始时间 |
| `SignEndTime` | datetime |  | 是 |  |  | 签到结束时间 |
| `IDNumber` | varchar | 18 | 是 | ('/') |  |  |
| `PlaceCity` | nvarchar | 200 | 是 | ('') |  |  |
| `StaffNumber` | nvarchar | 50 | 是 | ('') |  |  |
| `AssemblyRoom` | nvarchar | max | 是 |  |  |  |
| `Scale` | nvarchar | 300 | 是 | ('') |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| CustomerInfo_index | NONCLUSTERED | 否 | SceneId,ActivityId,PhoneNo,Name,CreateTime,Status |

### 4. CustomerInfoNew

**库**：`hrflagactivities`　**行数**：301,859　**字段数**：44

**用途**：报名记录表（新版），动态表单提交写入

**关联接口**：NewForm/AddCustomerInfoTwo、UpdateUserByPhone、BulkUpdatesFormOrderNew

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `OrderNo` | nvarchar | 100 | 否 | ('') |  |  |
| `Phone` | nvarchar | 11 | 是 | ('') |  |  |
| `ActivityId` | nvarchar | 200 | 是 |  |  |  |
| `SceneId` | nvarchar | 200 | 是 | ('') |  |  |
| `TicketQuantity` | int |  | 是 |  |  |  |
| `Name` | nvarchar | 50 | 是 | ('') |  |  |
| `Company` | nvarchar | 150 | 是 | ('') |  |  |
| `PhoneLocation` | nvarchar | 100 | 是 | ('') |  |  |
| `Industry` | nvarchar | 100 | 是 | ('') |  |  |
| `Position` | nvarchar | 100 | 是 | ('') |  |  |
| `Department` | nvarchar | 100 | 是 | ('') |  |  |
| `Email` | nvarchar | 100 | 是 | ('') |  |  |
| `Comefrom` | nvarchar | 100 | 是 | ('') |  |  |
| `IP` | nvarchar | 100 | 是 | ('') |  |  |
| `IpAddress` | nvarchar | 100 | 是 | ('') |  |  |
| `CheckStaus` | int |  | 是 | ((1)) |  |  |
| `IsLook` | int |  | 是 | ((0)) |  |  |
| `PayStatus` | int |  | 是 | ((0)) |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `Remarks` | nvarchar | 500 | 是 | ('') |  |  |
| `MorningCheckinTime` | datetime |  | 是 | ('') |  |  |
| `MorningCheckin` | nvarchar | 100 | 是 | ('') |  |  |
| `SigninMorningMode` | nvarchar | 100 | 是 | ('0') |  |  |
| `AfternoonCheckin` | nvarchar | 100 | 是 | ('') |  |  |
| `AfternoonCheckerTime` | datetime |  | 是 | ('') |  |  |
| `SigninAfternoonMode` | nvarchar | 100 | 是 | ('0') |  |  |
| `IsAgree` | nvarchar | 10 | 是 | ('同意') |  |  |
| `CompanyId` | nvarchar | 100 | 是 | ('') |  |  |
| `SignBeginTime` | datetime |  | 是 | ('') |  |  |
| `SignEndTime` | datetime |  | 是 | ('') |  |  |
| `PlaceCity` | nvarchar | 200 | 是 | ('') |  |  |
| `TicketNo` | nvarchar | 200 | 是 | ('') |  |  |
| `EticketTime` | datetime |  | 是 | ('') |  |  |
| `JsonStr` | nvarchar | max | 是 | ('') |  |  |
| `ContactTime` | datetime |  | 是 | ('') |  |  |
| `ContactPhoneNo` | nvarchar | 200 | 是 | ('') |  |  |
| `Clue` | int |  | 是 | ('0') |  |  |
| `OrderID` | nvarchar | 100 | 是 | ('') |  |  |
| `SourceName` | nvarchar | 200 | 是 | ('') |  |  |
| `IsRefresh` | int |  | 是 | ((0)) |  | 是否刷新 1:刷新来的 0:非刷新来的 |
| `AssemblyRoom` | nvarchar | max | 是 |  |  |  |
| `Scale` | nvarchar | 300 | 是 | ('') |  |  |
| `IDNumber` | varchar | 18 | 是 |  |  |  |
| `PayTime` | datetime |  | 是 | ('1900-01-01 00:00:00.000') |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| Index_All | NONCLUSTERED | 否 | SceneId,CheckStaus,TicketNo,CompanyId,Phone,SourceName,ContactPhoneNo,PayStatus |
| idx_CustomerInfoNew_SceneId | NONCLUSTERED | 否 | SceneId |
| IX_CustomerInfoNew_SceneId_Phone | NONCLUSTERED | 否 | SceneId,Phone |
| IX_CustomerInfoNew_Phone | NONCLUSTERED | 否 | Phone |
| IX_CustomerInfoNew_Phone_CheckStaus | NONCLUSTERED | 否 | Phone,CheckStaus |
| IX_CustomerInfoNew_ContactPhoneNo | NONCLUSTERED | 否 | ContactPhoneNo |

### 5. SellTicketsInfo

**库**：`hrflagactivities`　**行数**：247,656　**字段数**：9

**用途**：售票/票务明细表，按订单与票种记录

**关联接口**：Activity/AddCustomerInfo

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `OrderNo` | nvarchar | 50 | 是 |  |  |  |
| `OrderID` | nvarchar | 50 | 否 |  | **PK** |  |
| `PhoneNo` | nvarchar | 11 | 否 |  |  |  |
| `ActivityId` | nvarchar | 100 | 否 |  | **PK** |  |
| `SceneId` | nvarchar | 100 | 否 |  | **PK** |  |
| `TicketId` | nvarchar | 100 | 否 |  | **PK** |  |
| `PurchaseNum` | int |  | 是 |  |  |  |
| `Status` | int |  | 是 | ((0)) |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| Index_All | NONCLUSTERED | 否 | OrderNo,CreateTime |

### 6. FormOrderInfo

**库**：`hrflag`　**行数**：2,732　**字段数**：17

**用途**：表单订单表，订单号、金额、支付方式、支付状态、收货地址

**关联接口**：FormOrder/AddFormOrderInfo、IfIsNoPayment、UpdatePayTime

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `OId` | uniqueidentifier |  | 否 |  | **PK** |  |
| `OrderMark` | varchar | 50 | 否 |  |  |  |
| `ActivityID` | nvarchar | 200 | 否 |  |  |  |
| `Phone` | varchar | 11 | 否 |  |  |  |
| `PayTime` | datetime |  | 是 | ('1900-01-01 00:00:00') |  |  |
| `PayType` | int |  | 否 |  |  |  |
| `IP` | varchar | 15 | 是 | ('') |  |  |
| `IPAddress` | nvarchar | 40 | 是 | ('') |  |  |
| `IsDeliverGoods` | int |  | 是 | ((0)) |  |  |
| `ExpressageCompany` | nvarchar | 50 | 是 | ('') |  |  |
| `LogisticsOdd` | varchar | 100 | 是 | ('') |  |  |
| `Price` | money |  | 否 |  |  |  |
| `TakeDeliveryInfoId` | uniqueidentifier |  | 否 |  |  |  |
| `IsDelete` | int |  | 是 | ((0)) |  |  |
| `CreateTime` | datetime |  | 是 | (getdate()) |  |  |
| `JsonStr` | nvarchar | 500 | 是 | ('') |  |  |
| `GenerateNumber` | int |  | 是 |  |  |  |

### 7. TakeDeliveryInfo

**库**：`hrflag`　**行数**：1,920　**字段数**：8

**用途**：收货地址表，付费且含实物的活动报名使用

**关联接口**：FormOrder/GetTakeDeliveryInfo

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Id` | uniqueidentifier |  | 否 |  | **PK** |  |
| `UserPhone` | varchar | 11 | 否 |  |  |  |
| `Name` | nvarchar | 50 | 否 |  |  |  |
| `Phone` | varchar | 11 | 否 |  |  |  |
| `Region` | nvarchar | 150 | 否 |  |  |  |
| `AddressTxt` | nvarchar | 200 | 否 |  |  |  |
| `CreateTime` | datetime |  | 是 | (getdate()) |  |  |
| `IsDelete` | int |  | 是 | ((0)) |  |  |

### 8. CityInfoCfg

**库**：`hrflagactivities`　**行数**：44　**字段数**：2

**用途**：城市字典表（CityCode/CityName）

**关联接口**：Activity/GetActivityListTwo、GetActivityInfoMap

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `CityName` | nvarchar | 500 | 是 |  |  |  |
| `CityCode` | nvarchar | 50 | 是 |  |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| Index_All | NONCLUSTERED | 否 | CityCode |

### 9. CountyInfoCfg

**库**：`hrflagactivities`　**行数**：480　**字段数**：3

**用途**：国家/地区字典表

**关联接口**：Activity/GetActivityListTwo、GetActivityInfoMap

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `ID` | int |  | 否 |  | **PK** | 自增 |
| `CityCode` | nvarchar | 50 | 是 |  |  |  |
| `CountryName` | nvarchar | 500 | 是 |  |  |  |

### 10. ActivityTypeCfg

**库**：`hrflagactivities`　**行数**：16　**字段数**：4

**用途**：活动类型字典表

**关联接口**：Activity/GetHRflagActivityByIdNew、ActivityUser/GetAllActivityType

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `ActivityTypeId` | nvarchar | 200 | 否 |  | **PK** |  |
| `ActivityTypeName` | nvarchar | 200 | 是 |  |  |  |
| `Remark` | nvarchar | 100 | 是 |  |  |  |
| `Sort` | int |  | 是 |  |  |  |

### 11. SCRMForm

**库**：`hrflagdataonline`　**行数**：946　**字段数**：13

**用途**：SCRM 动态表单配置表，主办方自定义题目

**关联接口**：NewForm/AddCustomerInfoTwo

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Id` | int |  | 否 |  | **PK** | 自增 |
| `FormName` | nvarchar | 200 | 是 |  |  |  |
| `Status` | nvarchar | 50 | 是 |  |  |  |
| `LastStatus` | nvarchar | 50 | 是 |  |  |  |
| `FormId` | nvarchar | 100 | 是 |  |  |  |
| `FormBeginTime` | datetime |  | 是 | ('1900-01-01 00:00:00') |  |  |
| `FormEndTime` | datetime |  | 是 | ('1900-01-01 00:00:00') |  |  |
| `Roles` | nvarchar | 100 | 是 |  |  |  |
| `Remarks` | nvarchar | 200 | 是 |  |  |  |
| `IsDelete` | int |  | 是 | ((0)) |  |  |
| `CreateTime` | datetime |  | 是 | (getdate()) |  |  |
| `AllocationState` | nvarchar | 50 | 是 | ((0)) |  |  |
| `UpdateTime` | datetime |  | 是 | (getdate()) |  |  |

### 12. SCRMFormHistory

**库**：`hrflagdataonline`　**行数**：5,480　**字段数**：23

**用途**：SCRM 表单填写历史

**关联接口**：NewForm/AddCustomerInfoTwo

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Id` | int |  | 否 |  | **PK** | 主键；自增 |
| `UserId` | nvarchar | 100 | 是 | ('') |  | 用户Id |
| `Source` | nvarchar | 20 | 是 | ('') |  | 表单来源Id  |
| `HeadPortraits` | nvarchar | 500 | 是 | ('') |  | 头像 |
| `Name` | nvarchar | 20 | 是 | ('') |  | 姓名 |
| `PhoneNo` | nvarchar | 11 | 是 | ('') |  | 手机号 |
| `PhoneLocation` | nvarchar | 50 | 是 | ('') |  | 手机号归属地 |
| `CompanyName` | nvarchar | 200 | 是 | ('') |  | 公司名称 |
| `FormName` | nvarchar | 300 | 是 | ('') |  | 表单名称 |
| `CompanyId` | nvarchar | 1000 | 是 | ('') |  | 授权公司ID |
| `Department` | nvarchar | 100 | 是 | ('') |  | 部门 |
| `Industry` | nvarchar | 100 | 是 | ('') |  | 行业 |
| `Position` | nvarchar | 100 | 是 | ('') |  | 职位 |
| `BehaviorsIntrodoction` | nvarchar | 500 | 是 | ('') |  |  |
| `EMail` | nvarchar | 100 | 是 | ('') |  | 邮箱 |
| `FormId` | nvarchar | 100 | 是 | ('') |  | 表单Id |
| `IP` | nvarchar | 50 | 是 | ('') |  | IP |
| `IPAddress` | nvarchar | 255 | 是 | ('') |  | IP归属地 |
| `IsDelete` | bit |  | 是 | ((0)) |  | 是否删除 0：未删除，1：删除 |
| `Remarks` | nvarchar | 255 | 是 | ('') |  | 备注 |
| `CreateTime` | datetime |  | 是 | (getdate()) |  | 创建时间 默认数据库当前时间 |
| `UpdateTime` | datetime |  | 是 | (getdate()) |  | 修改时间 默认数据库当前时间 |
| `Behavior` | nvarchar | 20 | 是 | ((0)) |  | 行为描述：1、表单报名 |

### 13. SCRMDownloadHistory

**库**：`hrflagdataonline`　**行数**：714,130　**字段数**：27

**用途**：SCRM 资料下载记录

**关联接口**：Activity/AddCustomerInfo

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Id` | int |  | 否 |  | **PK** | 自增 |
| `UserId` | varchar | 300 | 是 |  |  | 用户Id |
| `Source` | int |  | 是 | ((0)) |  | 来源	0：PC端		1：小程序端（智能通讯录） |
| `HeadPortraits` | varchar | 300 | 是 |  |  | 头像 |
| `Name` | varchar | 300 | 是 |  |  | 姓名: 1:登录	2:导出 |
| `PhoneNo` | varchar | 300 | 是 |  |  | 手机号  |
| `CompanyName` | varchar | 300 | 是 |  |  | 公司名称  |
| `FileName` | nvarchar | 500 | 是 |  |  | 下载文件名称 |
| `CompanyId` | varchar | max | 是 |  |  | 报告所属公司  |
| `Department` | varchar | 300 | 是 |  |  | 职位  |
| `Position` | varchar | 300 | 是 |  |  | 行为描述  |
| `BehaviorsIntrodoction` | nvarchar | 500 | 是 |  |  |  |
| `EMail` | nvarchar | 100 | 是 | ('') |  | 邮箱  |
| `FileId` | nvarchar | 300 | 是 |  |  | 下载文件Id  |
| `IP` | nvarchar | 50 | 是 |  |  | IP  |
| `IPAddress` | nvarchar | 50 | 是 |  |  | IP归属地	 |
| `IsDelete` | int |  | 是 | ((1)) |  | 是否删除 删除为0  不删除为1  |
| `Remarks` | nvarchar | 100 | 是 |  |  | 备注 |
| `CreateTime` | datetime |  | 是 | (getdate()) |  | 创建时间 |
| `UpdateTime` | datetime |  | 是 | (getdate()) |  | 修改时间 |
| `Behavior` | int |  | 是 |  |  | 行为描述：1、下载文件	2、观看视频 |
| `IsForm` | varchar | 50 | 是 |  |  |  |
| `IsShow` | int |  | 是 | ((1)) |  |  |
| `IsSignin` | nvarchar | 50 | 是 |  |  |  |
| `ForenoonSignInTime` | nvarchar | 200 | 是 |  |  |  |
| `AfternoonSignInTime` | nvarchar | 200 | 是 |  |  |  |
| `JsonStr` | nvarchar | max | 是 | ('') |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| index_All | NONCLUSTERED | 否 | PhoneNo,FileId,IsDelete,Remarks |

### 14. ShareActivity

**库**：`hrflagwxsp`　**行数**：6　**字段数**：15

**用途**：分享有礼配置表（场次维度），含规则、起止时间、达成条件

**关联接口**：ActivitiesShare/WxSelectActivityShare

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Sceneld` | nvarchar | 100 | 否 |  | **PK** |  |
| `BeginDate` | datetime |  | 是 |  |  |  |
| `EndDate` | datetime |  | 是 |  |  |  |
| `ConductImg` | nvarchar | 100 | 是 |  |  |  |
| `ActivityPresent` | nvarchar | 1000 | 是 |  |  |  |
| `ActivityRuleA` | ntext |  | 是 |  |  |  |
| `ActivityRuleB` | ntext |  | 是 |  |  |  |
| `IsCreate` | int |  | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `SceneTerm` | int |  | 是 |  |  |  |
| `Enter_Integral` | int |  | 是 |  |  |  |
| `Auditing_Integral` | int |  | 是 |  |  |  |
| `SingnIn_Integral` | int |  | 是 |  |  |  |
| `IsDelete` | int |  | 是 |  |  |  |
| `Remarks` | nvarchar | 500 | 是 |  |  |  |

### 15. ActivityPrizes

**库**：`hrflagwxsp`　**行数**：12　**字段数**：8

**用途**：分享有礼奖品档位表，记录档位人数与奖品图

**关联接口**：ActivitiesShare/WxSelectActivityShare

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Pid` | nvarchar | 100 | 否 |  | **PK** |  |
| `SceneId` | nvarchar | 50 | 是 |  |  |  |
| `Pricename` | nvarchar | 50 | 是 |  |  |  |
| `PeopleCount` | int |  | 是 |  |  |  |
| `PriceImg` | nvarchar | 200 | 是 |  |  |  |
| `PriceTerm` | int |  | 是 |  |  |  |
| `IsDelete` | int |  | 是 | ((0)) |  |  |
| `Remarks` | varchar | 300 | 是 |  |  |  |

### 16. CustomerSource

**库**：`hrflagactivities`　**行数**：284,239　**字段数**：5

**用途**：客户渠道来源表

**关联接口**：Activity/AddustomerSoure、ActivitiesShare（渠道统计）

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Id` | int |  | 否 |  | **PK** | 自增 |
| `OrderNo` | nvarchar | 100 | 是 |  |  |  |
| `SourceId` | nvarchar | 100 | 是 |  |  |  |
| `SpecialId` | nvarchar | 100 | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| Index_All | NONCLUSTERED | 否 | OrderNo,SourceId,CreateTime,SpecialId |

### 17. ActivitySource

**库**：`hrflagactivities`　**行数**：18,957　**字段数**：13

**用途**：活动渠道字典表

**关联接口**：Activity/GetSpecialIdByScenceId、ActivitiesShare

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `SourceId` | int |  | 否 |  | **PK** | 自增 |
| `ScenceId` | nvarchar | 100 | 是 |  |  |  |
| `SourceName` | nvarchar | 100 | 是 |  |  |  |
| `SpecialId` | nvarchar | 10 | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `LongWebSite` | nvarchar | 500 | 是 |  |  |  |
| `ShortWebSite` | nvarchar | 100 | 是 |  |  |  |
| `MiniprogramWebSite` | nvarchar | 100 | 是 |  |  |  |
| `InteriorMiniprogramWebSite` | nvarchar | 100 | 是 |  |  |  |
| `Remarks` | nvarchar | 200 | 是 |  |  |  |
| `IsDelete` | int |  | 是 | ((0)) |  |  |
| `CompanyId` | nvarchar | 50 | 是 |  |  |  |
| `ScrmSource` | nvarchar | 50 | 是 |  |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| Index_All | NONCLUSTERED | 否 | ScenceId,IsDelete |

### 18. User

**库**：`hrflag`　**行数**：248,143　**字段数**：23

**用途**：主站账号主表，报名时按手机号关联/更新

**关联接口**：Form/UserRegister、NewForm/UpdateUserByPhone、System/GetUserInfo

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `UserId` | nvarchar | 100 | 否 |  | **PK** |  |
| `Name` | nvarchar | 100 | 是 |  |  |  |
| `Sex` | nvarchar | 50 | 是 |  |  |  |
| `PhoneNumber` | nvarchar | 100 | 是 |  |  |  |
| `PhonePlace` | nvarchar | 100 | 是 | ('') |  |  |
| `Email` | nvarchar | 200 | 是 |  |  |  |
| `Company` | nvarchar | 100 | 是 |  |  |  |
| `TradName` | nvarchar | 200 | 是 |  |  |  |
| `Department` | nvarchar | 200 | 是 |  |  |  |
| `Position` | nvarchar | 100 | 是 |  |  |  |
| `Comefrom` | nvarchar | 100 | 是 |  |  |  |
| `IPAddress` | nvarchar | 50 | 是 | ('') |  |  |
| `IPAttach` | nvarchar | 50 | 是 | ('') |  |  |
| `ExTypeNumber` | int |  | 是 |  |  |  |
| `ActTypeNumber` | int |  | 是 |  |  |  |
| `UpdateTime` | datetime |  | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `IsBlackList` | int |  | 是 |  |  |  |
| `IsDelete` | bit |  | 是 | ((0)) |  |  |
| `CheckStatus` | int |  | 是 | ((1)) |  |  |
| `Remark` | nvarchar | 200 | 是 |  |  |  |
| `UserRemark` | nvarchar | 200 | 是 |  |  |  |
| `BatchId` | uniqueidentifier |  | 是 | ('00000000-0000-0000-0000-000000000000') |  | 导入excel批次id |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| User_Index | NONCLUSTERED | 否 | CreateTime,UpdateTime,PhoneNumber |
| <Name of Missing Index, sysname,> | NONCLUSTERED | 否 | PhoneNumber |
| IX_User_PhoneNumber | NONCLUSTERED | 否 | PhoneNumber |

### 19. UserPhoto

**库**：`hrflag`　**行数**：124　**字段数**：4

**用途**：用户头像表

**关联接口**：System/GetUserInfo（头像回填）

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `UserPhoneNo` | nvarchar | 11 | 否 |  | **PK** |  |
| `UserPhotoUrl` | nvarchar | 500 | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `UpdateTime` | datetime |  | 是 |  |  |  |

### 20. UserInfoHistory

**库**：`hrflag`　**行数**：9,294　**字段数**：23

**用途**：用户资料变更历史，报名回写资料时记录

**关联接口**：NewForm/UpdateUserByPhone

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `UserId` | nvarchar | 100 | 否 |  |  |  |
| `Name` | nvarchar | 100 | 是 |  |  |  |
| `Sex` | nvarchar | 50 | 是 |  |  |  |
| `PhoneNumber` | nvarchar | 100 | 是 |  |  |  |
| `PhonePlace` | nvarchar | 100 | 是 | (N'') |  |  |
| `Email` | nvarchar | 100 | 是 |  |  |  |
| `Company` | nvarchar | 100 | 是 |  |  |  |
| `TradName` | nvarchar | 50 | 是 |  |  |  |
| `Department` | nvarchar | 50 | 是 |  |  |  |
| `Position` | nvarchar | 100 | 是 |  |  |  |
| `Comefrom` | nvarchar | 100 | 是 |  |  |  |
| `IPAddress` | nvarchar | 50 | 是 | ('') |  |  |
| `IPAttach` | nvarchar | 50 | 是 | ('') |  |  |
| `ExTypeNumber` | int |  | 是 |  |  |  |
| `ActTypeNumber` | int |  | 是 |  |  |  |
| `UpdateTime` | datetime |  | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `IsBlackList` | int |  | 是 |  |  |  |
| `IsDelete` | bit |  | 是 | ((0)) |  |  |
| `CheckStatus` | int |  | 是 | ((1)) |  |  |
| `Remark` | nvarchar | 200 | 是 |  |  |  |
| `Source` | nvarchar | 50 | 是 | ((0)) |  |  |
| `Img` | nvarchar | 500 | 是 |  |  |  |

### 21. CustomerInfo

**库**：`hrflag`　**行数**：40,048　**字段数**：30

**用途**：主站客户信息表，IsFormSignUp 按表单 + 手机号判断是否已报名

**关联接口**：NewForm/IsFormSignUp

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `ID` | int |  | 否 |  |  | 自增 |
| `PhoneNo` | nvarchar | 11 | 否 |  |  |  |
| `ActivityId` | nvarchar | 200 | 否 |  |  |  |
| `SceneId` | nvarchar | 500 | 是 |  |  |  |
| `Name` | nvarchar | 50 | 是 |  |  |  |
| `Company` | nvarchar | 150 | 是 |  |  |  |
| `Industry` | nvarchar | 100 | 是 |  |  |  |
| `Position` | nvarchar | 100 | 是 |  |  |  |
| `Department` | nvarchar | 100 | 是 |  |  |  |
| `Email` | nvarchar | 100 | 是 |  |  |  |
| `Comefrom` | nvarchar | 100 | 是 |  |  |  |
| `PhoneIn` | nvarchar | 50 | 是 |  |  |  |
| `City` | nvarchar | 100 | 是 | ('') |  |  |
| `CompanySize` | nvarchar | 50 | 是 | ('') |  |  |
| `IsLook` | int |  | 是 | ((0)) |  |  |
| `IsDelete` | int |  | 是 | ((0)) |  |  |
| `Status` | int |  | 是 | ((1)) |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `Remarks` | nvarchar | 100 | 是 |  |  |  |
| `IDNumber` | varchar | 18 | 是 | ('/') |  |  |
| `PlaceCity` | nvarchar | 200 | 是 | ('') |  |  |
| `StaffNumber` | nvarchar | 50 | 是 | ('') |  |  |
| `AssemblyRoom` | nvarchar | 50 | 是 | ('') |  |  |
| `ProjectName` | nvarchar | 500 | 是 |  |  |  |
| `TrackName` | nvarchar | 500 | 是 |  |  |  |
| `ReferenceName` | nvarchar | 50 | 是 |  |  |  |
| `IPAddress` | nvarchar | 500 | 是 | ('') |  |  |
| `IPAttach` | nvarchar | 500 | 是 | ('') |  |  |
| `JsonStr` | nvarchar | 500 | 是 | ('') |  |  |
| `IsInterestedLy` | int |  | 是 |  |  |  |

### 22. ActivityInfo

**库**：`hrflag`　**行数**：911　**字段数**：20

**用途**：主站活动表，MenuComPrivacyShow 关联活动与主办方

**关联接口**：Activity/MenuComPrivacyShow、ComPrivacy

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `ActivityID` | nvarchar | 200 | 否 |  | **PK** |  |
| `ActivityName` | nvarchar | 200 | 是 |  |  |  |
| `SignUpSum` | int |  | 是 |  |  |  |
| `WaitCheckSum` | int |  | 是 | ((0)) |  |  |
| `BegInDate` | datetime |  | 是 |  |  |  |
| `EndDate` | datetime |  | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `Status` | int |  | 是 | ((2)) |  |  |
| `ActivityType` | nvarchar | 100 | 是 |  |  |  |
| `Remarks` | nvarchar | 200 | 是 |  |  |  |
| `OutSite` | nvarchar | 500 | 是 |  |  |  |
| `TipMsg` | nvarchar | 200 | 是 |  |  |  |
| `EventOrganizer` | nvarchar | 200 | 是 |  |  |  |
| `CompanyId` | nvarchar | 1000 | 是 | (N'’‘') |  |  |
| `IsOrderForm` | int |  | 是 | ((0)) |  |  |
| `Price` | decimal | 10,2 | 是 | ((0.00)) |  |  |
| `RecordName` | nvarchar | 100 | 是 |  |  |  |
| `RecordUpdatetime` | datetime |  | 是 |  |  |  |
| `RecordIP` | nvarchar | 100 | 是 |  |  |  |
| `RecordIPaddress` | nvarchar | 100 | 是 |  |  |  |

### 23. Company

**库**：`hrflag`　**行数**：3,747　**字段数**：15

**用途**：公司主表

**关联接口**：Activity/ComPrivacy、活动侧栏

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `ComId` | nvarchar | 100 | 否 |  | **PK** |  |
| `ComName` | nvarchar | 100 | 是 |  |  |  |
| `ComEng` | nvarchar | 100 | 是 |  |  |  |
| `Image` | nvarchar | 100 | 是 |  |  |  |
| `CTId` | nvarchar | 50 | 是 |  |  |  |
| `Describtion` | nvarchar | 2000 | 是 |  |  |  |
| `PhoneNumber` | nvarchar | 100 | 是 |  |  |  |
| `Email` | nvarchar | 100 | 是 |  |  |  |
| `Website` | nvarchar | 100 | 是 |  |  |  |
| `UpdateTime` | datetime |  | 是 |  |  |  |
| `UpdateUser` | nvarchar | 100 | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `CreateUser` | nvarchar | 100 | 是 |  |  |  |
| `IsDelete` | bit |  | 是 |  |  |  |
| `Remark` | nvarchar | 200 | 是 |  |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| Index_All | NONCLUSTERED | 否 | ComName |

### 24. ThinkerCompanyInfo

**库**：`hrflagdataonline`　**行数**：4,697　**字段数**：51

**用途**：主办方公司信息表，隐私条款按 CompanyId 取公司名称

**关联接口**：Activity/ComPrivacy、MenuComPrivacyShow

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `CompanyId` | nvarchar | 4000 | 是 |  |  |  |
| `CompanyName` | nvarchar | 4000 | 是 |  |  |  |
| `ChiAbbreviation` | nvarchar | 4000 | 是 |  |  |  |
| `EnAbbreviation` | nvarchar | 4000 | 是 |  |  |  |
| `LogoPath` | nvarchar | max | 是 |  |  |  |
| `PropagandaVideo` | nvarchar | 4000 | 是 |  |  |  |
| `VideoImagePath` | nvarchar | 4000 | 是 |  |  |  |
| `CompanyDataPath` | nvarchar | 4000 | 是 |  |  |  |
| `CompanyLabel` | nvarchar | 4000 | 是 |  |  |  |
| `CompanytDescribtion` | nvarchar | max | 是 |  |  |  |
| `BCompanyDescribtion` | nvarchar | max | 是 |  |  |  |
| `CompanyFocus` | nvarchar | 4000 | 是 |  |  |  |
| `CompanyProduct` | nvarchar | max | 是 |  |  |  |
| `CompanyClass` | nvarchar | 50 | 是 |  |  |  |
| `CompanyCountry` | nvarchar | 50 | 是 |  |  |  |
| `CompanyList` | int |  | 是 | ((0)) |  |  |
| `ListedCity` | nvarchar | max | 是 |  |  |  |
| `Code` | nvarchar | 4000 | 是 |  |  |  |
| `EmployNum` | nvarchar | max | 是 |  |  |  |
| `Date` | nvarchar | 4000 | 是 |  |  |  |
| `CompanyAdress` | nvarchar | max | 是 |  |  |  |
| `WebSite` | nvarchar | 4000 | 是 |  |  |  |
| `CompanyEmail` | nvarchar | 4000 | 是 |  |  |  |
| `CompanyPhone` | nvarchar | 50 | 是 |  |  |  |
| `CompanyRQCode` | nvarchar | 4000 | 是 |  |  |  |
| `LinkedInWebSite` | nvarchar | 4000 | 是 |  |  |  |
| `ContactsName` | nvarchar | 20 | 是 |  |  |  |
| `ContactsWx` | nvarchar | 4000 | 是 |  |  |  |
| `ContactsPhone` | nvarchar | 11 | 是 |  |  |  |
| `PhoneAreaCode` | nvarchar | 10 | 是 |  |  |  |
| `Telephone` | nvarchar | 20 | 是 |  |  |  |
| `ContactsEmail` | nvarchar | 50 | 是 |  |  |  |
| `ContactsLinkedIn` | nvarchar | 50 | 是 |  |  |  |
| `FormInfo` | nvarchar | 4000 | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `IsDelete` | int |  | 是 | ((0)) |  |  |
| `Status` | int |  | 是 | ((0)) |  |  |
| `Privacy` | nvarchar | 4000 | 是 |  |  |  |
| `PhoneExtension` | nvarchar | 20 | 是 | (NULL) |  |  |
| `CompanyLogoFilePath` | nvarchar | 4000 | 是 | (NULL) |  |  |
| `City` | nvarchar | 50 | 是 | (NULL) |  |  |
| `County` | nvarchar | 50 | 是 | (NULL) |  |  |
| `ContactsIndustry` | nvarchar | 4000 | 是 | (NULL) |  |  |
| `ContactsDepartment` | nvarchar | 4000 | 是 | (NULL) |  |  |
| `ContactsPosition` | nvarchar | 4000 | 是 | (NULL) |  |  |
| `province` | nvarchar | 50 | 是 |  |  |  |
| `CityList` | nvarchar | 50 | 是 |  |  |  |
| `ProjectId` | nvarchar | 100 | 是 |  |  |  |
| `CompanyLocation` | nvarchar | 4000 | 是 | ('') |  |  |
| `Industry` | nvarchar | max | 是 |  |  |  |
| `IndustryId` | varchar | 155 | 是 | ('') |  | 关联行业Id |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| Index_All | NONCLUSTERED | 否 | CompanyId |
| IX_ThinkerCompanyInfo_CompanyId | NONCLUSTERED | 否 | CompanyId |

### 25. HRUserInfo

**库**：`hrflagwxsp`　**行数**：102,800　**字段数**：32

**用途**：人脉用户主表，报名时若存在同名手机号则关联

**关联接口**：Activity/AddCustomerInfo、AddCustomerInfoTwo

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `OpenId` | nvarchar | 200 | 否 |  | **PK** |  |
| `UnionID` | nvarchar | 200 | 是 |  |  |  |
| `Image` | nvarchar | 1000 | 是 |  |  |  |
| `PhoneNo` | nvarchar | 11 | 是 |  |  |  |
| `PhonePlace` | nvarchar | 20 | 是 | (N'') |  |  |
| `Name` | nvarchar | 50 | 是 |  |  |  |
| `NameNumber` | nvarchar | 100 | 是 |  |  |  |
| `Company` | nvarchar | 200 | 是 |  |  |  |
| `CompanyLogo` | nvarchar | 200 | 是 |  |  |  |
| `TradName` | nvarchar | 200 | 是 |  |  |  |
| `Department` | nvarchar | 200 | 是 |  |  |  |
| `Position` | nvarchar | 200 | 是 |  |  |  |
| `Email` | nvarchar | 100 | 是 |  |  |  |
| `Place` | nvarchar | 100 | 是 |  |  |  |
| `Address` | nvarchar | 300 | 是 |  |  |  |
| `TelePhone` | nvarchar | 50 | 是 |  |  |  |
| `WxCode` | nvarchar | 200 | 是 |  |  |  |
| `IsCreate` | bit |  | 是 |  |  |  |
| `Status` | int |  | 是 | ((1)) |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `UpdateTime` | datetime |  | 是 |  |  |  |
| `IsDelete` | int |  | 是 | ((0)) |  |  |
| `IsShow` | int |  | 是 | ((0)) |  | 0显示   1不显示 |
| `IsDisplay` | int |  | 是 | ((0)) |  | 0显示 1不显示 |
| `Reamrks` | nvarchar | 100 | 是 |  |  |  |
| `BusinessColour` | nvarchar | 50 | 是 | (N'blue') |  |  |
| `Privacybool` | bit |  | 是 | ((0)) |  |  |
| `Relationbool` | bit |  | 是 | ((1)) |  |  |
| `IPAddress` | nvarchar | 50 | 是 |  |  |  |
| `IPAttach` | nvarchar | 50 | 是 |  |  |  |
| `IsRestrict` | int |  | 是 |  |  | 是否限制(0:未限制 1:已限制) |
| `RestrictTime` | datetime |  | 是 |  |  | 限制时间 |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| HRUserInfo_Index | NONCLUSTERED | 否 | PhoneNo,CreateTime,UpdateTime,Status,IsCreate,IsDelete |
| IX_HRUserInfo_PhoneNo | NONCLUSTERED | 否 | PhoneNo |
| IX_HRUserInfo_Phone | NONCLUSTERED | 否 | PhoneNo |
| IX_HRUserInfo_Phone_Delete | NONCLUSTERED | 否 | PhoneNo,IsDelete,IsCreate |
| IX_HRUserInfo_PhoneNo_Filter | NONCLUSTERED | 否 | PhoneNo |
| IX_HRUserInfo_Phone_ValidUser | NONCLUSTERED | 否 | PhoneNo,IsDelete,IsCreate,CreateTime |

---

## 3. 表关系与联调要点

### 3.1 主链路

```
ActivityInfo(hrflagactivities, PK=ActivityId)
   └── SceneInfo(SceneId, 多场次)
          ├── CustomerInfo / CustomerInfoNew(报名记录: PhoneNo+SceneId+TicketId)
          │        └── SellTicketsInfo(票务明细)
          ├── ShareActivity(分享有礼配置) ── ActivityPrizes(奖品档位)
          └── CustomerSource ── ActivitySource(渠道)

FormOrderInfo(订单, 支付) ── TakeDeliveryInfo(收货地址, 付费实物活动)
字典：CityInfoCfg / CountyInfoCfg / ActivityTypeCfg
SCRM：SCRMForm / SCRMFormHistory / SCRMDownloadHistory(hrflagdataonline)
主站：User / UserPhoto / UserInfoHistory(hrflag)、HRUserInfo(hrflagwxsp)
```

- **报名双表**：`CustomerInfo` 为当前主用报名表（固定字段），`CustomerInfoNew` 为动态表单报名表（配合 `SCRMForm` 存自定义题目），两表按 `PhoneNo + SceneId` 判断重复，**排查重复报名要同时查两张表**。
- **审核状态**：`CustomerInfo.Status` / `CheckStatus` 对应接口 `IfUserIsApply` 的 1 待审核 / 2 通过 / 3 不通过；签到用 `IsSignIn`。
- **订单与支付**：`FormOrderInfo` 的支付状态字段对应 `PayStatus` / `CustomStatus`；`RecordAliPay` / `RecordWxPay` 只更新该表，不做幂等，回调重复会重复写入（需业务层保证）。
- **跨库无外键**：活动库 `hrflagactivities` 与主站 `hrflag`、人脉库 `hrflagwxsp` 通过 `ActivityId` / `PhoneNo` / `OpenId` 逻辑关联，数据库层面没有外键约束（各表"外键"小节为空即为此原因），删除数据需自行保证一致性。

### 3.2 性能与索引提示

- `SceneInfo` 按 `ActivityId` 查场次、按 `SceneBeginDate` 过滤未开始场次，需 `ActivityId + SceneBeginDate` 索引。
- `CustomerInfo` 按 `PhoneNo` / `SceneId` 双条件高频查询（报名校验、状态查询），建议各建索引。
- `FormOrderInfo` 按 `OrderNo` 查询，需唯一索引；`TakeDeliveryInfo` 按 `phone` 查询。
- 活动列表 `GetActivityListTwo` 涉及 `ActivityInfo + SceneInfo + CityInfoCfg + CountyInfoCfg` 四表联查并分页，是活动模块最重的查询。

### 3.3 字段陷阱

- `ActivityInfo.MainBody`、`ActivityBright` 为 `ntext`，存储 HTML，字段较大，列表接口不应查询（`GetActivityListTwo` 未取）。
- `SceneInfo.SceneName` 既是城市名又是"在线/全国"等特殊值，判断线上活动需结合 `CityName`。
- `SellTicketsInfo` / `CustomerInfo` 中的手机号、邮箱为明文存储，导出与日志需脱敏。
- `ActivityInfo.CompanyId` 对应 `hrflagdataonline.ThinkerCompanyInfo.CompanyId`，跨库取公司名称。
