# 社区（Twitter）模块表结构

本表结构由源码调用链定位：先按 接口源码/02-社区（Twitter）接口源码对照.md 找到 Helper 方法，再从 Helper 的 SQL 中提取表名，最后读取数据库元数据生成字段清单。所有查询均为只读。

| 项目 | 内容 |
|---|---|
| 数据库 | `hrflag`（主站）、`hrflagwxsp`（人脉/社区）、`hrflagactivities`（活动） |
| 实例 | `rm-bp1qz3lr4bu51dy5eso.sqlserver.rds.aliyuncs.com`（SQL Server 2012，只读查询） |
| 表数量 | 18 张 |
| 采集时间 | 2026-11-17 |
| 采集方式 | 直接读取 `sys.columns` / `sys.indexes` / `sys.foreign_keys` / `sys.extended_properties` |

## 1. 表清单

| # | 库 | 表名 | 行数 | 字段数 | 用途 | 关联接口 |
|---|---|---|---|---|---|---|
| 1 | hrflagwxsp | PostInfo | 14,744 | 35 | 帖子主表，存标题、正文、富文本、图片/视频 JSON、审核状态、置顶、浏览量、评论数 | Community/ListOfPosts、GetMainConmmentTable、PostCheckState |
| 2 | hrflagwxsp | PostLikes | 6,103 | 5 | 帖子点赞记录，按帖子 + 手机号去重 | Community/PostLikeOrUnLike、IsNotLoggedPostLike |
| 3 | hrflagwxsp | PostViews | 26,210,297 | 5 | 帖子浏览记录，含浏览人头像，用于列表头像堆叠 | Community/PostView、ListOfPosts（ViewsImage） |
| 4 | hrflagwxsp | MainComments | 191 | 20 | 主评论表，帖子详情页评论区 | Community/GetMainConmmentTable |
| 5 | hrflagwxsp | MainCommentsControlsInfos | 46 | 7 | 评论管控信息表，记录审核/屏蔽状态 | Community/GetMainConmmentTable |
| 6 | hrflagwxsp | PostLongIdToShortId | 10,204 | 3 | 帖子长 ID 与短 ID 映射表，用于小程序评论页场景值 | Community/AddPostShortId |
| 7 | hrflagwxsp | SystemNotifications | 5,344 | 8 | 系统通知表，点赞/关注后写入消息 | Community/PostLikeOrUnLike、FollowOrUnfollow |
| 8 | hrflagwxsp | UserFollows | 205,441 | 6 | 用户关注关系表（关注/粉丝） | Community/FollowOrUnfollow、ListOfPosts(Type=3) |
| 9 | hrflagwxsp | ExhibitorFollows | 68,867 | 9 | 展商关注关系表，影响推荐流排序 | Community/ListOfPosts |
| 10 | hrflagwxsp | ExhibitorHomePage | 201 | 5 | 展商主页配置表，列表卡片展示展商信息 | Community/ListOfPosts、GetMainConmmentTable |
| 11 | hrflagwxsp | HRUserInfo | 102,800 | 32 | 人脉用户主表，帖子作者名片来源 | Community/ListOfPosts、GetMainConmmentTable |
| 12 | hrflag | TwitterClass | 8 | 5 | 快讯分类字典（ClassName） | Twitter/GetTwitterClass、GetHrflagTwitter |
| 13 | hrflag | Twitter | 8,150 | 20 | 快讯主表，社区详情页"最新快讯"与快讯点赞/分享使用 | Twitter/GetHrflagHighTwitter、AddTwitterView |
| 14 | hrflag | TwitterImage | 5,090 | 6 | 快讯图片表，查看大图时按 Guid 取图 | Twitter/GetTwitterByid |
| 15 | hrflag | TwitterShare | 512 | 3 | 快讯分享记录 | Twitter/AddTwitterShare、GetUserShares |
| 16 | hrflag | TwitterUserLike | 23,568 | 3 | 快讯点赞记录 | Twitter/AddTwitterLike、GetUserLike |
| 17 | hrflag | Company | 3,747 | 15 | 公司主表，快讯发布公司关联 | Twitter/GetHrflagHighTwitter、GetHrflagTwitter |
| 18 | hrflag | CapTrueValue | 14,786 | 26 | 资讯主表（已审核 CheckStatus=2），侧栏"最热新闻"数据源 | News/GetHotNews |

## 2. 表结构详情

### 1. PostInfo

**库**：`hrflagwxsp`　**行数**：14,744　**字段数**：35

**用途**：帖子主表，存标题、正文、富文本、图片/视频 JSON、审核状态、置顶、浏览量、评论数

**关联接口**：Community/ListOfPosts、GetMainConmmentTable、PostCheckState

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Id` | uniqueidentifier |  | 否 | (newid()) | **PK** |  |
| `Title` | nvarchar | 500 | 是 | ('') |  |  |
| `Content` | nvarchar | max | 是 | ('') |  |  |
| `RichText` | nvarchar | max | 是 | ('') |  |  |
| `Image` | nvarchar | max | 是 | ('[]') |  |  |
| `CommentCount` | int |  | 是 | ((0)) |  |  |
| `LikeCount` | int |  | 是 | ((0)) |  |  |
| `FavoriteCount` | int |  | 是 | ((0)) |  |  |
| `ViewCount` | int |  | 是 | ((0)) |  |  |
| `ShareCount` | int |  | 是 | ((0)) |  |  |
| `UserPhoneNumber` | varchar | 11 | 否 |  |  |  |
| `Category` | varchar | 50 | 是 | ('') |  |  |
| `CheckStatus` | int |  | 是 | ((0)) |  |  |
| `VisibilityType` | int |  | 是 | ((0)) |  |  |
| `NotVisibleToOthers` | varchar | 1000 | 是 | ('') |  |  |
| `ReviewerPhoneNumber` | varchar | 11 | 是 | ('') |  |  |
| `ApprovalTime` | datetime |  | 是 | ('1900-01-01 00:00:00') |  |  |
| `TopPost` | bit |  | 是 | ((0)) |  |  |
| `SourceType` | int |  | 是 | ((0)) |  |  |
| `Location` | nvarchar | 200 | 是 | ('') |  |  |
| `IpAddress` | varchar | 40 | 否 |  |  |  |
| `IPLocation` | nvarchar | 100 | 否 |  |  |  |
| `IsDelete` | bit |  | 是 | ((0)) |  |  |
| `TwitterGuId` | nvarchar | 100 | 是 |  |  |  |
| `Advertising` | int |  | 是 | ((1)) |  |  |
| `AdvertisingType` | int |  | 是 | ((3)) |  |  |
| `AdvertisingContent` | nvarchar | max | 是 | ('') |  |  |
| `UserHeadPortrait` | nvarchar | max | 是 |  |  |  |
| `UserCompanyId` | nvarchar | 100 | 是 |  |  |  |
| `CreatedTime` | datetime |  | 是 | (getdate()) |  |  |
| `VideoLinkId` | nvarchar | max | 是 |  |  |  |
| `VideoName` | nvarchar | max | 是 |  |  |  |
| `ImageandVideo` | nvarchar | max | 是 |  |  |  |
| `InfoGraphicsId` | nvarchar | 100 | 是 | ('') |  |  |
| `Infographic` | int |  | 是 | ((0)) |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| Index_All | NONCLUSTERED | 否 | UserPhoneNumber,CheckStatus,VisibilityType |
| IX_PostInfo_VisibilityType_CheckStatus | NONCLUSTERED | 否 | VisibilityType,CheckStatus |
| IX_PostInfo_Filter_Order | NONCLUSTERED | 否 | IsDelete,CheckStatus,TopPost,CreatedTime |
| IX_PostInfo_Filter_Sort | NONCLUSTERED | 否 | IsDelete,CheckStatus,VisibilityType,TopPost,CreatedTime |
| IX_PostInfo_ListFeed | NONCLUSTERED | 否 | IsDelete,VisibilityType,CheckStatus,Advertising,TopPost,CreatedTime |
| IX_PostInfo_List_Filter_Sort | NONCLUSTERED | 否 | IsDelete,Advertising,VisibilityType,CheckStatus,TopPost,CreatedTime |
| IX_PostInfo_User_Filter | NONCLUSTERED | 否 | UserPhoneNumber,IsDelete,VisibilityType,CheckStatus,Advertising,CreatedTime |

### 2. PostLikes

**库**：`hrflagwxsp`　**行数**：6,103　**字段数**：5

**用途**：帖子点赞记录，按帖子 + 手机号去重

**关联接口**：Community/PostLikeOrUnLike、IsNotLoggedPostLike

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Id` | uniqueidentifier |  | 否 | (newid()) | **PK** |  |
| `PostInfoId` | uniqueidentifier |  | 否 |  |  |  |
| `Phone` | varchar | 11 | 否 |  |  |  |
| `LikedPhone` | varchar | 11 | 否 |  |  |  |
| `CreateTime` | datetime |  | 是 | (getdate()) |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| Index_All | NONCLUSTERED | 否 | PostInfoId,Phone |
| IX_PostLikes_Phone_PostInfoId | NONCLUSTERED | 否 | Phone,PostInfoId |
| IX_PostLikes_Post_Phone | NONCLUSTERED | 否 | PostInfoId,Phone |

### 3. PostViews

**库**：`hrflagwxsp`　**行数**：26,210,297　**字段数**：5

**用途**：帖子浏览记录，含浏览人头像，用于列表头像堆叠

**关联接口**：Community/PostView、ListOfPosts（ViewsImage）

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Id` | uniqueidentifier |  | 否 | (newid()) | **PK** |  |
| `PostInfoId` | uniqueidentifier |  | 否 |  |  |  |
| `Phone` | varchar | 11 | 否 |  |  |  |
| `CreateTime` | datetime |  | 是 | (getdate()) |  |  |
| `OpenId` | nvarchar | 200 | 是 | ('') |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| Index_All | NONCLUSTERED | 否 | PostInfoId,Phone |
| IX_PostViews_Phone_PostInfoId | NONCLUSTERED | 否 | Phone,PostInfoId |
| IX_PostViews_PostInfoId_CreateTime | NONCLUSTERED | 否 | PostInfoId,CreateTime |
| IX_PostViews_PostInfoId_Phone | NONCLUSTERED | 否 | PostInfoId,Phone |
| IX_PostViews_PostInfoId_Phone_CreateTime | NONCLUSTERED | 否 | PostInfoId,Phone,CreateTime |
| IX_PostViews_Post_Phone_CreateTime | NONCLUSTERED | 否 | PostInfoId,Phone,CreateTime |
| IX_PostViews_Post_CreateTime | NONCLUSTERED | 否 | PostInfoId,CreateTime |

### 4. MainComments

**库**：`hrflagwxsp`　**行数**：191　**字段数**：20

**用途**：主评论表，帖子详情页评论区

**关联接口**：Community/GetMainConmmentTable

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Id` | uniqueidentifier |  | 否 | (newid()) | **PK** |  |
| `Content` | nvarchar | 1000 | 否 |  |  |  |
| `Phone` | varchar | 11 | 否 |  |  |  |
| `CommentedPhone` | varchar | 11 | 否 |  |  |  |
| `IsLook` | int |  | 是 | ((0)) |  |  |
| `PostInfoId` | uniqueidentifier |  | 否 |  |  |  |
| `ChildCommentCount` | int |  | 是 | ((0)) |  |  |
| `LikesCount` | int |  | 是 | ((0)) |  |  |
| `TreadCount` | int |  | 是 | ((0)) |  |  |
| `VisibilityType` | int |  | 是 | ((0)) |  |  |
| `TopPost` | bit |  | 是 | ((0)) |  |  |
| `CheckStatus` | int |  | 是 | ((0)) |  |  |
| `ReviewerPhoneNumber` | varchar | 11 | 是 | ('') |  |  |
| `ApprovalTime` | datetime |  | 是 | ('1900-01-01 00:00:00') |  |  |
| `SourceType` | int |  | 是 | ((0)) |  |  |
| `IpAddress` | varchar | 40 | 否 |  |  |  |
| `IPLocation` | nvarchar | 100 | 否 |  |  |  |
| `IsDelete` | bit |  | 是 | ((0)) |  |  |
| `Advertising` | int |  | 是 | ((1)) |  |  |
| `CreateTime` | datetime |  | 是 | (getdate()) |  |  |

### 5. MainCommentsControlsInfos

**库**：`hrflagwxsp`　**行数**：46　**字段数**：7

**用途**：评论管控信息表，记录审核/屏蔽状态

**关联接口**：Community/GetMainConmmentTable

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Id` | uniqueidentifier |  | 否 | (newid()) | **PK** |  |
| `MainCommentsId` | uniqueidentifier |  | 否 |  |  |  |
| `Phone` | varchar | 11 | 否 |  |  |  |
| `PassivePhone` | varchar | 11 | 否 |  |  |  |
| `IsLook` | int |  | 是 | ((0)) |  |  |
| `State` | int |  | 是 | ((0)) |  |  |
| `CreateTime` | datetime |  | 是 | (getdate()) |  |  |

### 6. PostLongIdToShortId

**库**：`hrflagwxsp`　**行数**：10,204　**字段数**：3

**用途**：帖子长 ID 与短 ID 映射表，用于小程序评论页场景值

**关联接口**：Community/AddPostShortId

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `PostInfoId` | uniqueidentifier |  | 否 |  | **PK** |  |
| `ShortId` | int |  | 否 |  |  | 自增 |
| `CreateTime` | datetime |  | 是 | (getdate()) |  |  |

### 7. SystemNotifications

**库**：`hrflagwxsp`　**行数**：5,344　**字段数**：8

**用途**：系统通知表，点赞/关注后写入消息

**关联接口**：Community/PostLikeOrUnLike、FollowOrUnfollow

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Id` | uniqueidentifier |  | 否 | (newid()) | **PK** |  |
| `Phone` | varchar | 11 | 否 |  |  |  |
| `InformPhone` | varchar | 11 | 是 | ('') |  |  |
| `NotificationText` | nvarchar | max | 否 |  |  |  |
| `IsRead` | bit |  | 是 | ((0)) |  |  |
| `InformType` | int |  | 是 | ((0)) |  |  |
| `CreateTime` | datetime |  | 是 | (getdate()) |  |  |
| `Remark` | nvarchar | 200 | 是 | ('') |  |  |

### 8. UserFollows

**库**：`hrflagwxsp`　**行数**：205,441　**字段数**：6

**用途**：用户关注关系表（关注/粉丝）

**关联接口**：Community/FollowOrUnfollow、ListOfPosts(Type=3)

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `FollowId` | uniqueidentifier |  | 否 | (newid()) | **PK** |  |
| `FollowerPhone` | varchar | 11 | 否 |  |  |  |
| `FollowingPhone` | varchar | 11 | 否 |  |  |  |
| `IpAddress` | varchar | 40 | 否 |  |  |  |
| `IPLocation` | nvarchar | 100 | 否 |  |  |  |
| `FollowTime` | datetime |  | 是 | (getdate()) |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| IX_UserFollows_FollowerPhone_FollowingPhone | NONCLUSTERED | 否 | FollowerPhone,FollowingPhone |
| IX_UserFollows_FollowerPhone | NONCLUSTERED | 否 | FollowerPhone |
| IX_UserFollows_FollowingPhone_FollowerPhone | NONCLUSTERED | 否 | FollowingPhone,FollowerPhone |
| IX_UserFollows_Follower_Following | NONCLUSTERED | 否 | FollowerPhone,FollowingPhone |
| IX_UserFollows_Following_Follower | NONCLUSTERED | 否 | FollowingPhone,FollowerPhone |

### 9. ExhibitorFollows

**库**：`hrflagwxsp`　**行数**：68,867　**字段数**：9

**用途**：展商关注关系表，影响推荐流排序

**关联接口**：Community/ListOfPosts

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `FollowId` | uniqueidentifier |  | 否 | (newid()) | **PK** |  |
| `FollowerOpenId` | nvarchar | 200 | 是 | ('') |  |  |
| `FollowingOpenId` | nvarchar | 200 | 是 | ('') |  |  |
| `CompanyId` | nvarchar | 100 | 否 |  |  |  |
| `FollowerPhone` | varchar | 11 | 否 |  |  |  |
| `FollowingPhone` | varchar | 11 | 否 |  |  |  |
| `IpAddress` | varchar | 40 | 否 |  |  |  |
| `IPLocation` | nvarchar | 100 | 否 |  |  |  |
| `FollowTime` | datetime |  | 是 | (getdate()) |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| IX_ExhibitorFollows_FollowerPhone_CompanyId | NONCLUSTERED | 否 | FollowerPhone,CompanyId |
| IX_ExhibitorFollows_Follower_Company | NONCLUSTERED | 否 | FollowerPhone,CompanyId |

### 10. ExhibitorHomePage

**库**：`hrflagwxsp`　**行数**：201　**字段数**：5

**用途**：展商主页配置表，列表卡片展示展商信息

**关联接口**：Community/ListOfPosts、GetMainConmmentTable

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `CompanyId` | nvarchar | 100 | 否 |  | **PK** |  |
| `VermicelliCount` | int |  | 是 | ((0)) |  |  |
| `FollowCount` | int |  | 是 | ((0)) |  |  |
| `IPGeolocation` | nvarchar | 20 | 是 | ('未知') |  |  |
| `CreateTime` | datetime |  | 是 | (getdate()) |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| idx_CompanyId | NONCLUSTERED | 否 | CompanyId |
| IX_ExhibitorHomePage_Company | NONCLUSTERED | 否 | CompanyId |

### 11. HRUserInfo

**库**：`hrflagwxsp`　**行数**：102,800　**字段数**：32

**用途**：人脉用户主表，帖子作者名片来源

**关联接口**：Community/ListOfPosts、GetMainConmmentTable

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `OpenId` | nvarchar | 200 | 否 |  | **PK** |  |
| `UnionID` | nvarchar | 200 | 是 |  |  |  |
| `Image` | nvarchar | 1000 | 是 |  |  |  |
| `PhoneNo` | nvarchar | 11 | 是 |  |  |  |
| `PhonePlace` | nvarchar | 20 | 是 | (N'') |  |  |
| `Name` | nvarchar | 50 | 是 |  |  |  |
| `NameNumber` | nvarchar | 100 | 是 |  |  |  |
| `Company` | nvarchar | 200 | 是 |  |  |  |
| `CompanyLogo` | nvarchar | 200 | 是 |  |  |  |
| `TradName` | nvarchar | 200 | 是 |  |  |  |
| `Department` | nvarchar | 200 | 是 |  |  |  |
| `Position` | nvarchar | 200 | 是 |  |  |  |
| `Email` | nvarchar | 100 | 是 |  |  |  |
| `Place` | nvarchar | 100 | 是 |  |  |  |
| `Address` | nvarchar | 300 | 是 |  |  |  |
| `TelePhone` | nvarchar | 50 | 是 |  |  |  |
| `WxCode` | nvarchar | 200 | 是 |  |  |  |
| `IsCreate` | bit |  | 是 |  |  |  |
| `Status` | int |  | 是 | ((1)) |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `UpdateTime` | datetime |  | 是 |  |  |  |
| `IsDelete` | int |  | 是 | ((0)) |  |  |
| `IsShow` | int |  | 是 | ((0)) |  | 0显示   1不显示 |
| `IsDisplay` | int |  | 是 | ((0)) |  | 0显示 1不显示 |
| `Reamrks` | nvarchar | 100 | 是 |  |  |  |
| `BusinessColour` | nvarchar | 50 | 是 | (N'blue') |  |  |
| `Privacybool` | bit |  | 是 | ((0)) |  |  |
| `Relationbool` | bit |  | 是 | ((1)) |  |  |
| `IPAddress` | nvarchar | 50 | 是 |  |  |  |
| `IPAttach` | nvarchar | 50 | 是 |  |  |  |
| `IsRestrict` | int |  | 是 |  |  | 是否限制(0:未限制 1:已限制) |
| `RestrictTime` | datetime |  | 是 |  |  | 限制时间 |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| HRUserInfo_Index | NONCLUSTERED | 否 | PhoneNo,CreateTime,UpdateTime,Status,IsCreate,IsDelete |
| IX_HRUserInfo_PhoneNo | NONCLUSTERED | 否 | PhoneNo |
| IX_HRUserInfo_Phone | NONCLUSTERED | 否 | PhoneNo |
| IX_HRUserInfo_Phone_Delete | NONCLUSTERED | 否 | PhoneNo,IsDelete,IsCreate |
| IX_HRUserInfo_PhoneNo_Filter | NONCLUSTERED | 否 | PhoneNo |
| IX_HRUserInfo_Phone_ValidUser | NONCLUSTERED | 否 | PhoneNo,IsDelete,IsCreate,CreateTime |

### 12. TwitterClass

**库**：`hrflag`　**行数**：8　**字段数**：5

**用途**：快讯分类字典（ClassName）

**关联接口**：Twitter/GetTwitterClass、GetHrflagTwitter

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `ClassId` | nvarchar | 50 | 否 |  |  |  |
| `ClassName` | nvarchar | 50 | 是 |  |  |  |
| `SeqNo` | int |  | 是 |  |  |  |
| `IsDelete` | int |  | 是 | ((0)) |  |  |
| `ClassIdV50` | varchar | 50 | 是 |  |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| IX_TwitterClass_ClassId | NONCLUSTERED | 否 | ClassId |
| IX_TwitterClass_ClassIdV50 | NONCLUSTERED | 否 | ClassIdV50 |

### 13. Twitter

**库**：`hrflag`　**行数**：8,150　**字段数**：20

**用途**：快讯主表，社区详情页"最新快讯"与快讯点赞/分享使用

**关联接口**：Twitter/GetHrflagHighTwitter、AddTwitterView

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Guid` | nvarchar | 100 | 否 |  | **PK** |  |
| `TName` | nvarchar | 200 | 是 |  |  |  |
| `TContent` | ntext |  | 是 |  |  |  |
| `BTContent` | text |  | 是 |  |  |  |
| `TImage` | nvarchar | 200 | 是 |  |  |  |
| `TPubName` | nvarchar | 100 | 是 |  |  |  |
| `TClass` | nvarchar | 100 | 是 |  |  |  |
| `TWebSite` | nvarchar | max | 是 |  |  |  |
| `PageView` | int |  | 是 | ((0)) |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `SeqNo` | int |  | 是 | ((0)) |  |  |
| `Status` | int |  | 是 | ((0)) |  |  |
| `IsDelete` | int |  | 是 | ((0)) |  |  |
| `Advertising` | int |  | 是 | ((1)) |  |  |
| `AdvertisingType` | int |  | 是 | ((3)) |  |  |
| `AdvertisingContent` | nvarchar | max | 是 | ('') |  |  |
| `VideoLinkId` | nvarchar | 200 | 是 |  |  |  |
| `VideoName` | nvarchar | max | 是 |  |  |  |
| `InfoGraphicsId` | nvarchar | 100 | 是 | ('') |  |  |
| `ExpireTime` | datetime |  | 是 |  |  |  |

### 14. TwitterImage

**库**：`hrflag`　**行数**：5,090　**字段数**：6

**用途**：快讯图片表，查看大图时按 Guid 取图

**关联接口**：Twitter/GetTwitterByid

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `ImgId` | int |  | 否 |  | **PK** | 自增 |
| `Guid` | nvarchar | 100 | 否 |  | **PK** |  |
| `BigImage` | nvarchar | 200 | 是 |  |  |  |
| `SmallImage` | nvarchar | 200 | 是 |  |  |  |
| `OrderNo` | int |  | 是 |  |  |  |
| `IsDelete` | int |  | 是 | ((0)) |  |  |

### 15. TwitterShare

**库**：`hrflag`　**行数**：512　**字段数**：3

**用途**：快讯分享记录

**关联接口**：Twitter/AddTwitterShare、GetUserShares

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Guid` | nvarchar | 100 | 是 |  |  |  |
| `UserId` | nvarchar | 100 | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |

### 16. TwitterUserLike

**库**：`hrflag`　**行数**：23,568　**字段数**：3

**用途**：快讯点赞记录

**关联接口**：Twitter/AddTwitterLike、GetUserLike

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Guid` | nvarchar | 100 | 是 |  |  |  |
| `UserId` | nvarchar | 100 | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |

### 17. Company

**库**：`hrflag`　**行数**：3,747　**字段数**：15

**用途**：公司主表，快讯发布公司关联

**关联接口**：Twitter/GetHrflagHighTwitter、GetHrflagTwitter

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `ComId` | nvarchar | 100 | 否 |  | **PK** |  |
| `ComName` | nvarchar | 100 | 是 |  |  |  |
| `ComEng` | nvarchar | 100 | 是 |  |  |  |
| `Image` | nvarchar | 100 | 是 |  |  |  |
| `CTId` | nvarchar | 50 | 是 |  |  |  |
| `Describtion` | nvarchar | 2000 | 是 |  |  |  |
| `PhoneNumber` | nvarchar | 100 | 是 |  |  |  |
| `Email` | nvarchar | 100 | 是 |  |  |  |
| `Website` | nvarchar | 100 | 是 |  |  |  |
| `UpdateTime` | datetime |  | 是 |  |  |  |
| `UpdateUser` | nvarchar | 100 | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `CreateUser` | nvarchar | 100 | 是 |  |  |  |
| `IsDelete` | bit |  | 是 |  |  |  |
| `Remark` | nvarchar | 200 | 是 |  |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| Index_All | NONCLUSTERED | 否 | ComName |

### 18. CapTrueValue

**库**：`hrflag`　**行数**：14,786　**字段数**：26

**用途**：资讯主表（已审核 CheckStatus=2），侧栏"最热新闻"数据源

**关联接口**：News/GetHotNews

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `NId` | nvarchar | 100 | 否 |  | **PK** |  |
| `Title` | nvarchar | 200 | 是 |  |  |  |
| `ReadCount` | int |  | 是 |  |  |  |
| `PubName` | nvarchar | 200 | 否 |  |  |  |
| `PubId` | int |  | 是 |  |  |  |
| `MainBody` | nvarchar | max | 是 |  |  |  |
| `BMainBody` | nvarchar | max | 是 |  |  |  |
| `ImagePath` | nvarchar | 100 | 是 |  |  |  |
| `SmallImage` | nvarchar | 500 | 是 |  |  |  |
| `NTId` | nvarchar | 100 | 是 |  |  |  |
| `NSource` | nvarchar | 500 | 是 |  |  |  |
| `Catenate` | nvarchar | 1000 | 是 |  |  |  |
| `NWebsite` | nvarchar | 500 | 是 |  |  |  |
| `state` | int |  | 是 |  |  |  |
| `issue` | int |  | 是 |  |  |  |
| `CheckStatus` | int |  | 是 |  |  |  |
| `IsCarouse` | int |  | 是 |  |  |  |
| `NOrigin` | int |  | 是 |  |  |  |
| `PageView` | int |  | 是 |  |  |  |
| `SeqNo` | int |  | 是 |  |  |  |
| `UpdateUser` | nvarchar | 200 | 是 |  |  |  |
| `UpdateTime` | datetime |  | 是 |  |  |  |
| `CreateUser` | nvarchar | 200 | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `IsDelete` | bit |  | 是 |  |  |  |
| `Remark` | nvarchar | 200 | 是 |  |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| Index_All | NONCLUSTERED | 否 | CheckStatus,CreateTime,IsDelete |

---

## 3. 表关系与联调要点

### 3.1 主链路

```
HRUserInfo(作者, OpenId)
        ↓
PostInfo(帖子, Id=Guid)
 ├── PostLikes(帖子点赞)
 ├── PostViews(浏览记录, ViewsImage 头像堆叠)
 ├── MainComments(主评论) ── MainCommentsControlsInfos(审核/屏蔽)
 ├── PostLongIdToShortId(短 ID, 供小程序评论场景值)
 └── SystemNotifications(点赞/关注通知)

UserFollows / ExhibitorFollows(影响 Type=2 好友流、Type=3 关注流)
快讯侧栏：Twitter + TwitterClass + Company，互动落 TwitterUserLike / TwitterShare
最热新闻：CapTrueValue(CheckStatus=2)
```

- **列表口径**：`ListOfPosts` 只取 `PostInfo` 中审核通过、未删除的帖子，`Type=1/2/3` 分别对应推荐、好友、关注；作者信息从 `HRUserInfo` 取，浏览人头像来自 `PostViews`。
- **点赞双通道**：登录用户写 `PostLikes` + `SystemNotifications`；游客只改计数（`IsNotLoggedPostLike`），不落 `PostLikes`。
- **长短期 ID**：`PostLongIdToShortId` 仅用于生成小程序评论码，PC 端跳转始终用 `PostInfo.Id`（GUID）。
- **快讯与帖子是两套体系**：`Twitter*` 表属主站快讯（编辑发布），`PostInfo` 属用户社区（UGC），互不关联；社区详情页的"最新快讯"读的是 `Twitter`。

### 3.2 性能与索引提示

- `PostInfo` 按 `CreateTime DESC` 排序分页，需有 `(IsDelete, CheckStatus, CreateTime)` 复合索引支撑。
- `PostViews` 每次列表渲染都会批量写入（每条帖子一次），是高频写表，注意锁竞争。
- `MainComments` 按帖子分页查询，需 `PostId + CreateTime` 索引。

### 3.3 字段陷阱

- `PostInfo.Image`、`ImageandVideo` 为**字符串化 JSON**（见接口文档 2.5 节），不是关联表，无法用 SQL 直接拆解，统计图片数量需在应用层解析。
- `PostInfo.ViewsImage` 为逗号分隔的头像 URL，长度随浏览人数增长，超长时会被截断（注意列长度）。
- `CapTrueValue.CheckStatus` 的取值：2 表示审核通过，查询必须带此条件，否则会读到草稿与未审稿件。
