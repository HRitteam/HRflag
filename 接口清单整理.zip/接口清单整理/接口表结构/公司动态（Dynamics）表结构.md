# 公司动态（Dynamics）模块表结构

本表结构由源码调用链定位：NewsController.GetIssueNews → NewsHelper.GetIssueNews → CapTrueValue / NewsType / ImageBase，另含公共框架的广告与头像表。

| 项目 | 内容 |
|---|---|
| 数据库 | `hrflag`（主站）、`hrflagwxsp`（人脉/社区）、`hrflagactivities`（活动） |
| 实例 | `rm-bp1qz3lr4bu51dy5eso.sqlserver.rds.aliyuncs.com`（SQL Server 2012，只读查询） |
| 表数量 | 8 张 |
| 采集时间 | 2026-11-17 |
| 采集方式 | 直接读取 `sys.columns` / `sys.indexes` / `sys.foreign_keys` / `sys.extended_properties` |

## 1. 表清单

| # | 库 | 表名 | 行数 | 字段数 | 用途 | 关联接口 |
|---|---|---|---|---|---|---|
| 1 | hrflag | CapTrueValue | 14,786 | 26 | 资讯主表，公司动态列表数据源；按 TypeName 匹配栏目、CheckStatus=2 只取已审核 | News/GetIssueNews |
| 2 | hrflag | NewsType | 9 | 9 | 资讯栏目字典表，按 TypeName 过滤"公司动态"等栏目 | News/GetIssueNews |
| 3 | hrflag | ImageBase | 1,890 | 5 | 资讯图片 base64 兜底表，SmallImage 为空时按 NId 取图并落盘 | News/GetIssueNews（封面兜底） |
| 4 | hrflag | TopAD | 41 | 12 | 顶部通栏广告表（公共布局） | Advertising/IGetTopAD |
| 5 | hrflag | TopADClickRecord | 1,219 | 3 | 顶部广告点击流水（公共布局） | Advertising/IAddTopADClickRecord |
| 6 | hrflag | User | 248,143 | 23 | 主站账号主表（登录态与头像） | UserInfo/GetUserById |
| 7 | hrflag | UserPhoto | 124 | 4 | 用户头像表（公共布局） | UserInfo/GetUserById |
| 8 | hrflagwxsp | HRUserInfo | 102,800 | 32 | 人脉用户主表（头像优先来源） | UserInfo/GetUserById |

## 2. 表结构详情

### 1. CapTrueValue

**库**：`hrflag`　**行数**：14,786　**字段数**：26

**用途**：资讯主表，公司动态列表数据源；按 TypeName 匹配栏目、CheckStatus=2 只取已审核

**关联接口**：News/GetIssueNews

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `NId` | nvarchar | 100 | 否 |  | **PK** |  |
| `Title` | nvarchar | 200 | 是 |  |  |  |
| `ReadCount` | int |  | 是 |  |  |  |
| `PubName` | nvarchar | 200 | 否 |  |  |  |
| `PubId` | int |  | 是 |  |  |  |
| `MainBody` | nvarchar | max | 是 |  |  |  |
| `BMainBody` | nvarchar | max | 是 |  |  |  |
| `ImagePath` | nvarchar | 100 | 是 |  |  |  |
| `SmallImage` | nvarchar | 500 | 是 |  |  |  |
| `NTId` | nvarchar | 100 | 是 |  |  |  |
| `NSource` | nvarchar | 500 | 是 |  |  |  |
| `Catenate` | nvarchar | 1000 | 是 |  |  |  |
| `NWebsite` | nvarchar | 500 | 是 |  |  |  |
| `state` | int |  | 是 |  |  |  |
| `issue` | int |  | 是 |  |  |  |
| `CheckStatus` | int |  | 是 |  |  |  |
| `IsCarouse` | int |  | 是 |  |  |  |
| `NOrigin` | int |  | 是 |  |  |  |
| `PageView` | int |  | 是 |  |  |  |
| `SeqNo` | int |  | 是 |  |  |  |
| `UpdateUser` | nvarchar | 200 | 是 |  |  |  |
| `UpdateTime` | datetime |  | 是 |  |  |  |
| `CreateUser` | nvarchar | 200 | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `IsDelete` | bit |  | 是 |  |  |  |
| `Remark` | nvarchar | 200 | 是 |  |  |  |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| Index_All | NONCLUSTERED | 否 | CheckStatus,CreateTime,IsDelete |

### 2. NewsType

**库**：`hrflag`　**行数**：9　**字段数**：9

**用途**：资讯栏目字典表，按 TypeName 过滤"公司动态"等栏目

**关联接口**：News/GetIssueNews

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `NTId` | nvarchar | 100 | 否 |  | **PK** |  |
| `TypeName` | nvarchar | 200 | 是 |  |  |  |
| `UpdateUser` | nvarchar | 100 | 是 |  |  |  |
| `UpdateTime` | datetime |  | 是 |  |  |  |
| `CreateUser` | nvarchar | 100 | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `SeqNo` | int |  | 是 |  |  |  |
| `IsDelete` | bit |  | 是 |  |  |  |
| `Remark` | nvarchar | 200 | 是 |  |  |  |

### 3. ImageBase

**库**：`hrflag`　**行数**：1,890　**字段数**：5

**用途**：资讯图片 base64 兜底表，SmallImage 为空时按 NId 取图并落盘

**关联接口**：News/GetIssueNews（封面兜底）

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Id` | int |  | 否 |  | **PK** | 自增 |
| `GUID` | nvarchar | 100 | 是 |  |  |  |
| `Imgbase64` | nvarchar | max | 是 |  |  |  |
| `Createtime` | datetime |  | 是 |  |  |  |
| `Remark` | nvarchar | 100 | 是 |  |  |  |

### 4. TopAD

**库**：`hrflag`　**行数**：41　**字段数**：12

**用途**：顶部通栏广告表（公共布局）

**关联接口**：Advertising/IGetTopAD

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Id` | int |  | 否 |  | **PK** | 自增 |
| `Name` | nvarchar | 500 | 是 |  |  |  |
| `ImagePath` | nvarchar | 500 | 是 |  |  |  |
| `Interlinkage` | nvarchar | 500 | 是 |  |  |  |
| `Random` | nvarchar | 300 | 是 |  |  |  |
| `ShowNum` | int |  | 是 |  |  |  |
| `ClickNum` | int |  | 是 |  |  |  |
| `State` | int |  | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `IsDelete` | bit |  | 是 |  |  |  |
| `PastDue` | datetime |  | 是 |  |  |  |
| `Remark` | nvarchar | 100 | 是 |  |  |  |

### 5. TopADClickRecord

**库**：`hrflag`　**行数**：1,219　**字段数**：3

**用途**：顶部广告点击流水（公共布局）

**关联接口**：Advertising/IAddTopADClickRecord

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `UserId` | nvarchar | 100 | 是 |  |  |  |
| `ADId` | int |  | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |

### 6. User

**库**：`hrflag`　**行数**：248,143　**字段数**：23

**用途**：主站账号主表（登录态与头像）

**关联接口**：UserInfo/GetUserById

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `UserId` | nvarchar | 100 | 否 |  | **PK** |  |
| `Name` | nvarchar | 100 | 是 |  |  |  |
| `Sex` | nvarchar | 50 | 是 |  |  |  |
| `PhoneNumber` | nvarchar | 100 | 是 |  |  |  |
| `PhonePlace` | nvarchar | 100 | 是 | ('') |  |  |
| `Email` | nvarchar | 200 | 是 |  |  |  |
| `Company` | nvarchar | 100 | 是 |  |  |  |
| `TradName` | nvarchar | 200 | 是 |  |  |  |
| `Department` | nvarchar | 200 | 是 |  |  |  |
| `Position` | nvarchar | 100 | 是 |  |  |  |
| `Comefrom` | nvarchar | 100 | 是 |  |  |  |
| `IPAddress` | nvarchar | 50 | 是 | ('') |  |  |
| `IPAttach` | nvarchar | 50 | 是 | ('') |  |  |
| `ExTypeNumber` | int |  | 是 |  |  |  |
| `ActTypeNumber` | int |  | 是 |  |  |  |
| `UpdateTime` | datetime |  | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `IsBlackList` | int |  | 是 |  |  |  |
| `IsDelete` | bit |  | 是 | ((0)) |  |  |
| `CheckStatus` | int |  | 是 | ((1)) |  |  |
| `Remark` | nvarchar | 200 | 是 |  |  |  |
| `UserRemark` | nvarchar | 200 | 是 |  |  |  |
| `BatchId` | uniqueidentifier |  | 是 | ('00000000-0000-0000-0000-000000000000') |  | 导入excel批次id |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| User_Index | NONCLUSTERED | 否 | CreateTime,UpdateTime,PhoneNumber |
| <Name of Missing Index, sysname,> | NONCLUSTERED | 否 | PhoneNumber |
| IX_User_PhoneNumber | NONCLUSTERED | 否 | PhoneNumber |

### 7. UserPhoto

**库**：`hrflag`　**行数**：124　**字段数**：4

**用途**：用户头像表（公共布局）

**关联接口**：UserInfo/GetUserById

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `UserPhoneNo` | nvarchar | 11 | 否 |  | **PK** |  |
| `UserPhotoUrl` | nvarchar | 500 | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `UpdateTime` | datetime |  | 是 |  |  |  |

### 8. HRUserInfo

**库**：`hrflagwxsp`　**行数**：102,800　**字段数**：32

**用途**：人脉用户主表（头像优先来源）

**关联接口**：UserInfo/GetUserById

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `OpenId` | nvarchar | 200 | 否 |  | **PK** |  |
| `UnionID` | nvarchar | 200 | 是 |  |  |  |
| `Image` | nvarchar | 1000 | 是 |  |  |  |
| `PhoneNo` | nvarchar | 11 | 是 |  |  |  |
| `PhonePlace` | nvarchar | 20 | 是 | (N'') |  |  |
| `Name` | nvarchar | 50 | 是 |  |  |  |
| `NameNumber` | nvarchar | 100 | 是 |  |  |  |
| `Company` | nvarchar | 200 | 是 |  |  |  |
| `CompanyLogo` | nvarchar | 200 | 是 |  |  |  |
| `TradName` | nvarchar | 200 | 是 |  |  |  |
| `Department` | nvarchar | 200 | 是 |  |  |  |
| `Position` | nvarchar | 200 | 是 |  |  |  |
| `Email` | nvarchar | 100 | 是 |  |  |  |
| `Place` | nvarchar | 100 | 是 |  |  |  |
| `Address` | nvarchar | 300 | 是 |  |  |  |
| `TelePhone` | nvarchar | 50 | 是 |  |  |  |
| `WxCode` | nvarchar | 200 | 是 |  |  |  |
| `IsCreate` | bit |  | 是 |  |  |  |
| `Status` | int |  | 是 | ((1)) |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `UpdateTime` | datetime |  | 是 |  |  |  |
| `IsDelete` | int |  | 是 | ((0)) |  |  |
| `IsShow` | int |  | 是 | ((0)) |  | 0显示   1不显示 |
| `IsDisplay` | int |  | 是 | ((0)) |  | 0显示 1不显示 |
| `Reamrks` | nvarchar | 100 | 是 |  |  |  |
| `BusinessColour` | nvarchar | 50 | 是 | (N'blue') |  |  |
| `Privacybool` | bit |  | 是 | ((0)) |  |  |
| `Relationbool` | bit |  | 是 | ((1)) |  |  |
| `IPAddress` | nvarchar | 50 | 是 |  |  |  |
| `IPAttach` | nvarchar | 50 | 是 |  |  |  |
| `IsRestrict` | int |  | 是 |  |  | 是否限制(0:未限制 1:已限制) |
| `RestrictTime` | datetime |  | 是 |  |  | 限制时间 |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| HRUserInfo_Index | NONCLUSTERED | 否 | PhoneNo,CreateTime,UpdateTime,Status,IsCreate,IsDelete |
| IX_HRUserInfo_PhoneNo | NONCLUSTERED | 否 | PhoneNo |
| IX_HRUserInfo_Phone | NONCLUSTERED | 否 | PhoneNo |
| IX_HRUserInfo_Phone_Delete | NONCLUSTERED | 否 | PhoneNo,IsDelete,IsCreate |
| IX_HRUserInfo_PhoneNo_Filter | NONCLUSTERED | 否 | PhoneNo |
| IX_HRUserInfo_Phone_ValidUser | NONCLUSTERED | 否 | PhoneNo,IsDelete,IsCreate,CreateTime |

---

## 3. 表关系与联调要点

### 3.1 主链路

```
CapTrueValue(资讯主表, NId)
 ├── NewsType(NTId) → TypeName 栏目（"公司动态"等）
 └── ImageBase(GUID=NId) → SmallImage 为空时取 base64 图并落盘生成缩略图

公共框架：TopAD / TopADClickRecord（顶部广告）
          User / UserPhoto / HRUserInfo（登录头像）
```

- **栏目过滤**：`GetIssueNews` 用 `[TypeName] LIKE '%公司动态%'`，属模糊匹配——传入"动态"会同时命中多个栏目，传空串则返回全部栏目。
- **只取已审核**：`WHERE [IsDelete]='0' AND [CheckStatus]='2'`，`CheckStatus` 为 2 才对外可见。
- **排序与分页**：`ROW_NUMBER() OVER (ORDER BY CreateTime DESC)`，`TOP limit` + `RowNumber >= 1 + limit*(page-1)`；`page/limit` 缺失时会变成 `TOP 0`，前端必须传值。
- **封面兜底**：`SmallImage` 为空 → `ImagePath` → `ImageBase` 中的 base64（`ImageHelper.SaveCapTrueBase64Img` 落盘后回写路径），因此新品资讯的封面可能是动态生成的。

### 3.2 数据陷阱

- **浏览量被人为放大**：`PageView = 库中值 + 9341`（`NewsHelper.cs:337`），页面展示值不能直接用于数据分析。
- **SQL 注入**：`title`、`typename` 直接拼进 `LIKE '%...%'`，前端 `?name=` 可构造注入，建议参数化（详见源码文档第 4.1 节）。
- `CapTrueValue` 同时被"最热新闻"（`GetHotNews`）与"公司动态"（`GetIssueNews`）复用，二者差异只在栏目与排序，改查询时需同时回归两个页面。
- `NewsType` 是栏目字典，`CapTrueValue.NTId` 存的是 `NTId`，而列表 SQL 把 `TypeName` 别名为 `NTId` 返回，**返回值中的 NTId 实际是栏目名称而非 ID**，前端不可当 ID 使用。
