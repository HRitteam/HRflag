# 趋势与洞察（Awards）模块表结构

本模块榜单条目为静态页面内容，无业务表；下列表为页面公共框架（顶部广告、合作方 Logo 墙、登录头像）所依赖的表与视图。

| 项目 | 内容 |
|---|---|
| 数据库 | `hrflag`（主站）、`hrflagwxsp`（人脉/社区）、`hrflagactivities`（活动） |
| 实例 | `rm-bp1qz3lr4bu51dy5eso.sqlserver.rds.aliyuncs.com`（SQL Server 2012，只读查询） |
| 表数量 | 6 张 |
| 采集时间 | 2026-11-17 |
| 采集方式 | 直接读取 `sys.columns` / `sys.indexes` / `sys.foreign_keys` / `sys.extended_properties` |

## 1. 表清单

| # | 库 | 表名 | 行数 | 字段数 | 用途 | 关联接口 |
|---|---|---|---|---|---|---|
| 1 | hrflag | TopAD | 41 | 12 | 顶部通栏广告表，含 ImagePath、Interlinkage、ShowNum 曝光计数；IGetTopAD 随机取一条 | Advertising/IGetTopAD |
| 2 | hrflag | TopADClickRecord | 1,219 | 3 | 顶部广告点击流水，按 UserId + ADId 记录 | Advertising/IAddTopADClickRecord |
| 3 | hrflag | User | 248,143 | 23 | 主站账号主表，GetUserById 按 UserId 取姓名/公司/职位/邮箱 | UserInfo/GetUserById |
| 4 | hrflag | UserPhoto | 124 | 4 | 用户头像表，按手机号关联，提供 UserPhotoUrl | UserInfo/GetUserById（头像兜底） |
| 5 | hrflagwxsp | HRUserInfo | 102,800 | 32 | 人脉用户主表，提供 Image（人脉头像）、OpenId、CompanyLogo | UserInfo/GetUserById（优先头像来源） |
| 6 | hrflag | GetHomeActivitieADUP | 49 | 12 | 数据库视图，顶部合作方 Logo 墙数据源，后端已过滤 IsDelete=0 且 State=1 | Advertising/HomeADUP |

## 2. 表结构详情

### 1. TopAD

**库**：`hrflag`　**行数**：41　**字段数**：12

**用途**：顶部通栏广告表，含 ImagePath、Interlinkage、ShowNum 曝光计数；IGetTopAD 随机取一条

**关联接口**：Advertising/IGetTopAD

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Id` | int |  | 否 |  | **PK** | 自增 |
| `Name` | nvarchar | 500 | 是 |  |  |  |
| `ImagePath` | nvarchar | 500 | 是 |  |  |  |
| `Interlinkage` | nvarchar | 500 | 是 |  |  |  |
| `Random` | nvarchar | 300 | 是 |  |  |  |
| `ShowNum` | int |  | 是 |  |  |  |
| `ClickNum` | int |  | 是 |  |  |  |
| `State` | int |  | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `IsDelete` | bit |  | 是 |  |  |  |
| `PastDue` | datetime |  | 是 |  |  |  |
| `Remark` | nvarchar | 100 | 是 |  |  |  |

### 2. TopADClickRecord

**库**：`hrflag`　**行数**：1,219　**字段数**：3

**用途**：顶部广告点击流水，按 UserId + ADId 记录

**关联接口**：Advertising/IAddTopADClickRecord

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `UserId` | nvarchar | 100 | 是 |  |  |  |
| `ADId` | int |  | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |

### 3. User

**库**：`hrflag`　**行数**：248,143　**字段数**：23

**用途**：主站账号主表，GetUserById 按 UserId 取姓名/公司/职位/邮箱

**关联接口**：UserInfo/GetUserById

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `UserId` | nvarchar | 100 | 否 |  | **PK** |  |
| `Name` | nvarchar | 100 | 是 |  |  |  |
| `Sex` | nvarchar | 50 | 是 |  |  |  |
| `PhoneNumber` | nvarchar | 100 | 是 |  |  |  |
| `PhonePlace` | nvarchar | 100 | 是 | ('') |  |  |
| `Email` | nvarchar | 200 | 是 |  |  |  |
| `Company` | nvarchar | 100 | 是 |  |  |  |
| `TradName` | nvarchar | 200 | 是 |  |  |  |
| `Department` | nvarchar | 200 | 是 |  |  |  |
| `Position` | nvarchar | 100 | 是 |  |  |  |
| `Comefrom` | nvarchar | 100 | 是 |  |  |  |
| `IPAddress` | nvarchar | 50 | 是 | ('') |  |  |
| `IPAttach` | nvarchar | 50 | 是 | ('') |  |  |
| `ExTypeNumber` | int |  | 是 |  |  |  |
| `ActTypeNumber` | int |  | 是 |  |  |  |
| `UpdateTime` | datetime |  | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `IsBlackList` | int |  | 是 |  |  |  |
| `IsDelete` | bit |  | 是 | ((0)) |  |  |
| `CheckStatus` | int |  | 是 | ((1)) |  |  |
| `Remark` | nvarchar | 200 | 是 |  |  |  |
| `UserRemark` | nvarchar | 200 | 是 |  |  |  |
| `BatchId` | uniqueidentifier |  | 是 | ('00000000-0000-0000-0000-000000000000') |  | 导入excel批次id |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| User_Index | NONCLUSTERED | 否 | CreateTime,UpdateTime,PhoneNumber |
| <Name of Missing Index, sysname,> | NONCLUSTERED | 否 | PhoneNumber |
| IX_User_PhoneNumber | NONCLUSTERED | 否 | PhoneNumber |

### 4. UserPhoto

**库**：`hrflag`　**行数**：124　**字段数**：4

**用途**：用户头像表，按手机号关联，提供 UserPhotoUrl

**关联接口**：UserInfo/GetUserById（头像兜底）

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `UserPhoneNo` | nvarchar | 11 | 否 |  | **PK** |  |
| `UserPhotoUrl` | nvarchar | 500 | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `UpdateTime` | datetime |  | 是 |  |  |  |

### 5. HRUserInfo

**库**：`hrflagwxsp`　**行数**：102,800　**字段数**：32

**用途**：人脉用户主表，提供 Image（人脉头像）、OpenId、CompanyLogo

**关联接口**：UserInfo/GetUserById（优先头像来源）

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `OpenId` | nvarchar | 200 | 否 |  | **PK** |  |
| `UnionID` | nvarchar | 200 | 是 |  |  |  |
| `Image` | nvarchar | 1000 | 是 |  |  |  |
| `PhoneNo` | nvarchar | 11 | 是 |  |  |  |
| `PhonePlace` | nvarchar | 20 | 是 | (N'') |  |  |
| `Name` | nvarchar | 50 | 是 |  |  |  |
| `NameNumber` | nvarchar | 100 | 是 |  |  |  |
| `Company` | nvarchar | 200 | 是 |  |  |  |
| `CompanyLogo` | nvarchar | 200 | 是 |  |  |  |
| `TradName` | nvarchar | 200 | 是 |  |  |  |
| `Department` | nvarchar | 200 | 是 |  |  |  |
| `Position` | nvarchar | 200 | 是 |  |  |  |
| `Email` | nvarchar | 100 | 是 |  |  |  |
| `Place` | nvarchar | 100 | 是 |  |  |  |
| `Address` | nvarchar | 300 | 是 |  |  |  |
| `TelePhone` | nvarchar | 50 | 是 |  |  |  |
| `WxCode` | nvarchar | 200 | 是 |  |  |  |
| `IsCreate` | bit |  | 是 |  |  |  |
| `Status` | int |  | 是 | ((1)) |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `UpdateTime` | datetime |  | 是 |  |  |  |
| `IsDelete` | int |  | 是 | ((0)) |  |  |
| `IsShow` | int |  | 是 | ((0)) |  | 0显示   1不显示 |
| `IsDisplay` | int |  | 是 | ((0)) |  | 0显示 1不显示 |
| `Reamrks` | nvarchar | 100 | 是 |  |  |  |
| `BusinessColour` | nvarchar | 50 | 是 | (N'blue') |  |  |
| `Privacybool` | bit |  | 是 | ((0)) |  |  |
| `Relationbool` | bit |  | 是 | ((1)) |  |  |
| `IPAddress` | nvarchar | 50 | 是 |  |  |  |
| `IPAttach` | nvarchar | 50 | 是 |  |  |  |
| `IsRestrict` | int |  | 是 |  |  | 是否限制(0:未限制 1:已限制) |
| `RestrictTime` | datetime |  | 是 |  |  | 限制时间 |

**索引**

| 索引名 | 类型 | 唯一 | 字段 |
|---|---|---|---|
| HRUserInfo_Index | NONCLUSTERED | 否 | PhoneNo,CreateTime,UpdateTime,Status,IsCreate,IsDelete |
| IX_HRUserInfo_PhoneNo | NONCLUSTERED | 否 | PhoneNo |
| IX_HRUserInfo_Phone | NONCLUSTERED | 否 | PhoneNo |
| IX_HRUserInfo_Phone_Delete | NONCLUSTERED | 否 | PhoneNo,IsDelete,IsCreate |
| IX_HRUserInfo_PhoneNo_Filter | NONCLUSTERED | 否 | PhoneNo |
| IX_HRUserInfo_Phone_ValidUser | NONCLUSTERED | 否 | PhoneNo,IsDelete,IsCreate,CreateTime |

### 6. GetHomeActivitieADUP

**库**：`hrflag`　**行数**：49　**字段数**：12

**用途**：数据库视图，顶部合作方 Logo 墙数据源，后端已过滤 IsDelete=0 且 State=1

**关联接口**：Advertising/HomeADUP

| 字段 | 类型 | 长度/精度 | 可空 | 默认值 | 主键 | 说明 |
|---|---|---|---|---|---|---|
| `Id` | int |  | 否 |  | **PK** | 自增 |
| `Name` | nvarchar | 50 | 是 |  |  |  |
| `ImagePath` | nvarchar | 100 | 是 |  |  |  |
| `InterLinkage` | nvarchar | 100 | 是 |  |  |  |
| `Random` | nvarchar | 100 | 是 |  |  |  |
| `ShowNum` | int |  | 是 |  |  |  |
| `ClickNum` | int |  | 是 |  |  |  |
| `State` | int |  | 是 |  |  |  |
| `CreateTime` | datetime |  | 是 |  |  |  |
| `IsDelete` | bit |  | 是 |  |  |  |
| `PastDue` | datetime |  | 是 |  |  |  |
| `SeqNo` | nvarchar | 100 | 是 |  |  |  |

---

## 3. 表关系与联调要点

### 3.1 主链路

```
TopAD(顶部广告, State=1 有效)
 ├── ShowNum：每次 IGetTopAD 自增（曝光）
 └── TopADClickRecord(UserId + ADId)：点击流水

GetHomeActivitieADUP(视图)：合作方 Logo 墙，已过滤 IsDelete=0 AND State=1
User(hrflag) ──PhoneNumber── UserPhoto(主站头像)
      └── HRUserInfo(hrflagwxsp, Image 优先头像, OpenId, CompanyLogo)
```

- **广告取数**：`IGetTopAD` 从 `TopAD` 全量有效记录中**随机**取一条，同时 `ShowNum+1`；因此曝光数与页面刷新次数成正比，不是去重 UV。
- **Logo 墙**：视图已做 `State=1` 过滤且无排序，前端必须按 `SeqNo` 升序渲染；`SeqNo` 字段来自视图定义（见 `sp_helptext 'GetHomeActivitieADUP'`）。
- **头像优先级**：`HRUserInfo.Image`（人脉头像）> `UserPhoto.UserPhotoUrl`（主站上传）> 默认头像；`Image` 为完整 URL 或相对路径，需按前缀判断。
- 榜单内容本身**不落库**，全部硬编码在 `Awards.cshtml`，因此本模块无榜单表。

### 3.2 字段陷阱

- `TopAD.State`/`IsDelete` 为 `int` 而非 `bit`，写 SQL 时不要用 `= TRUE`。
- `TopADClickRecord` 只记录 `UserId + ADId + CreateTime`，未登录用户 `UserId` 为空串，会丢失归因。
- `GetUserById` 的 SQL 用 `'{strUserId}'` 字符串拼接，传入非法值存在注入风险（来源为 Cookie）。
